# StoreSnap — Engineering Blueprint & Agent Guide

> Single source of truth for building StoreSnap. Agents (and humans) working in this repo
> should treat this document as the authoritative plan and keep it updated as phases land.

---

## 1. What this is

**StoreSnap** is an online storefront platform for Kenyan social sellers — a "Shopify for
social sellers" where every seller gets their own independent, media-first storefront.

- **Positioning**: infrastructure company giving each seller their own branded digital
  storefront (their catalog, their orders, their customers). We are the plumbing, not a
  marketplace that owns the customer relationship.
- **Target sellers**: thrift clothes, new clothes, shoes/sneakers, wigs, perfume/beauty,
  general goods, sometimes electronics. Micro-sellers to established boutiques.
- **Core market behavior**: sellers sell primarily through WhatsApp groups / status posts.
  StoreSnap must fit into that behavior (shareable item links with rich previews), not
  fight it (no forced payment rails).
- **Scope discipline (v1 platform)**: we provide the **digital storefront only**.
  - ❌ No delivery/courier integrations.
  - ❌ No payment processing/columns of money. Buyers pay sellers directly (seller's own
    M-Pesa/Pochi/Paybill, cash, WhatsApp-settled). Orders can be *recorded* in our inbox
    with payment method as an annotation only.
  - Subscription billing for the platform is the only money flow through us (M-Pesa STK
    push for invoices) — that is platform revenue, not seller sales handling.

## 2. Product model — the three sides, one workflow

```
BUYER     discovery/feed → storefront → item page → order (platform)
             OR WhatsApp handoff (free forever)
                │ order recorded
SELLER    order inbox → confirm/schedule → Sale recorded
          catalog grid → item editor → share sheet / post packs
             │ sees ROI (views→taps→orders) → upgrades tier / buys boosts
PLATFORM  admin console: rate card → usage invoices → STK collect
          moderation, feature flags, feed curation, support tooling
             │ better tools → better storefronts → buyers convert better  ⟲ loop
```

Three surfaces, one auth model (`buyer` / `seller` / `platform_owner`), one REST API:

1. **Buyer storefront** — mobile-first public pages at `{store}.shops.storesnap.co.ke`,
   custom domains, and collection/item share links. Masonry media-first feed (the
   aesthetic from `index.html` mockup: Inter + Cormorant, `lux` cream/gold light theme +
   dark theme, stock scarcity badges, variant selectors, WhatsApp checkout document).
2. **Seller dashboard** (`/dashboard`) — onboarding wizard, catalog grid, item editor,
   share kits, order inbox, analytics, billing.
3. **Platform admin console** (`/admin`) — owner-grade management of everything.

## 3. Tech stack & monorepo layout

| Layer | Choice | Rationale |
|---|---|---|
| Frontend | React 19 + Vite + TypeScript + Tailwind v4 | speed; tokens from mockup seed the design system |
| State | TanStack Query (server) + Zustand (cart/theme/settings) | predictable, small |
| Backend | Express 5 + TypeScript, layered `routes → controllers → services → repositories` | modular REST |
| Validation | Zod schemas in `packages/shared` (client+server share types) | one contract |
| DB | PostgreSQL, **schema-per-module**, Prisma ORM + migrations | modular but one instance |
| Jobs/queue | pg-boss (Postgres-backed queue) | one less container; swap to Redis later if scale demands |
| Object storage | S3 SDK behind a `MediaProvider` interface; **RustFS in dev** (MinIO community images were pulled from Docker Hub in 2026), AWS S3 / Backblaze B2 in prod | modular buckets, swap via env |
| Image/video | sharp worker (image variants + share-card/OG compositing), ffmpeg (video renditions) | in worker container |
| Auth | JWT access (15min) + rotating refresh cookie, argon2 hashes, RBAC middleware | standard |
| Emails/notify | minimal v1 (email via Resend cheap tier); SMS/WhatsApp Business notifications parked post-v1 | cost |
| Deploy | Docker Compose everywhere; Traefik + TLS in prod; GitHub Actions CI | single VPS |

**Monorepo layout:**

```
/apps/web            React SPA (storefront + /dashboard + /admin zones)
/apps/api            Express REST API + SSR-lite OG routes + host middleware
/packages/shared     Zod schemas: API DTOs, theme schema, plan config, events
/infra               docker-compose*.yml, Traefik config, deploy/backup scripts
/docs                architecture notes, runbooks (AGENTS.md is the index)
index.html, *.png    mockups — READ ONLY reference (design source of truth)
```

## 4. Architecture

```
Browser (React PWA, mobile-first)
   │ REST /api/v1/* · SSR-lite for bots (OG unfurls)
Express API ── modules: identity · stores · catalog · media · share · orders ·
                   billing · platform
   │                    │
Prisma → Postgres     MediaProvider → S3/MinIO (presigned uploads browser→bucket;
(schema per module)   worker generates webp variants + OG cards + posters)
pg-boss worker: image/video jobs, domain verification, usage aggregation
Docker: api · web · worker · postgres · minio · traefik
```

**Delivery shape**: the SPA is fine for humans; item/store URLs get a bot-specific
server render (see §8) because WhatsApp/Telegram scrapers don't run JS.

## 5. Data model (Postgres modules)

One instance, `CREATE SCHEMA` per module; each module owns its tables/migrations;
cross-module access only via service APIs inside the app.

- **identity** — `users(role, login, status)`, `sessions(rotating refresh)`, `otps`
- **stores** (tenant module) —
  `stores(slug, name, logo, cover, whatsapp_number, location, theme jsonb, plan, status)`,
  `domains(customDomain, store_id, status: pending|dns_pending|active)`,
  `store_followers`
- **catalog** — `categories(shared taxonomy)`, `products(store_id, title, description,
  price, compare_at_price, condition new|thrift, condition_grade, stock, status
  draft|active|paused|sold_out|archived, auto_badge source)`,
  `variants(size, color, sku, stock, price_delta)`, `product_media(order, type
  image|video|360)`, `collections(store, items)` (for drop links), `drops`
- **media** — `uploads(key, mime, dims, variants map, owner)`, orphan GC
- **share** — `share_links(item|collection, short_id, channel_tag, created_at)`,
  `share_events(url, view|tap|order_signal)` (attribution telemetry)
- **orders** — `orders(store_id, buyer{name, phone, location}, fulfillment
  pickup|delivery, payment_method annotate only, status
  pending→confirmed→out→fulfilled|cancelled, source web|whatsapp|self_report)`,
  `order_items(price snapshot at purchase time)`, `holds(15-min reservations, Pro)`
- **billing** — `plans`, `subscriptions(store_id, status, period)`, `boost_purchases`,
  `usage_events` (append-only), `usage_periods`, `usage_invoices(status
  draft|issued|paid|overdue|void)`, `payments` (STK push transaction records),
  `rate_card` (per-tier fee config — admin-editable config, not code)
- **platform** — `moderation_flags`, `audit_log(immutable)`, `feature_flags`,
  `metrics_daily`

**Invariants**: every money-adjacent figure is a price snapshot; stock decrements are
transactional; usage_events are immutable (adjustments happen on invoices, never ledgers).

## 6. REST API surface (v1)

```
AUTH      POST /auth/register|login|refresh|logout
PUBLIC    GET  /stores/:slug                 (branding + merged theme)
          GET  /stores/:slug/products?category=&condition=&q=&sort=&page=
          GET  /products/:id  ·  GET /categories
ORDERS    POST /orders       (validate stock → snapshot prices → decrement →
                             creates order → returns order + WhatsApp payload link)
          GET  /orders/:token                 (buyer tracking link)
SHARE     GET  /p/:shortId                    (share link router; bot vs human)
SELLER    /seller/products CRUD + variants + media · presign /seller/media/upload
          /seller/orders  ·  /seller/collections (drops)
          /seller/share (captions, posters, post-packs, channel tags)
          /seller/analytics  ·  /seller/store + theme draft/publish
          /seller/plan + billing
ADMIN     /admin/stores|users|subscriptions|usage(+rate_card)|content|moderation|
          feature_flags|platform_metrics
WEBHOOK   POST /webhooks/mpesa               (STK callbacks for invoices)
```

## 7. Design system & theming (swappable per store, cannot fall apart)

**Rules (mandatory):**

1. **Tokens only.** The storefront renders exclusively via CSS custom properties
   (`--surface`, `--card`, `--border`, `--text`, `--muted`, `--accent`, `--accent-hover`,
   `--accent-contrast`, `--radius`, hero/layout flags). Components contain **zero
   hard-coded colors** — enforced by a lint/grep CI rule. The `lux` + dark palettes in
   `index.html` are the seed tokens.
2. **Theme = validated data.** `packages/shared/theme-schema.ts`:
   `ThemeSpec { schemaVersion, preset, overrides{colors?, fonts?, radius?, hero?} }`.
   Server deep-merges `preset defaults ← overrides` and Zod-validates **before** it
   reaches any client. Corrupt/legacy themes snap back to preset, never break the UI.
3. **Server-delivered CSS.** `GET /stores/:slug` returns the merged theme; the storefront
   route injects it as a pre-rendered `<style>:root{...}</style>` before the app mounts.
   No runtime theme JS, no flash. ETag-cached per host.
4. **Fallbacks baked in**: every token has a global default — degradation, not breakage.
5. **Versioned migrations**: theme schema evolves via `schemaVersion` migration functions.
6. **Draft → preview → publish**: drafts stored on the store, preview at
   `/s/{slug}?preview=draft` (owner-only, the API silently serves the published theme to
   everyone else), atomic publish, previous theme kept for rollback.

**Customization is generous, tiered by depth** (easy → given):

| Tier | Customization |
|---|---|
| Grow | Full color palette, fonts, radius, hero/banner layout, category order, logo, cover, card density, light/dark presets |
| Commerce | + advanced sections (story blocks, badges), page composition, draft/publish workflow |
| Business | + custom domain, token-aware sanitized custom CSS, multiple page templates |

Code-level (Liquid-style) custom storefronts: deliberately out of scope for v1.

## 8. Share & OG pipeline (growth core — every item is postable)

Sellers sell inside WhatsApp groups today with camera photos + "price = KSh X".
Our job: made-for-them media assets that outperform that, one tap away.

**Links**
- Every item gets a canonical short link `{store}.shops.storesnap.co.ke/p/{short_id}`
  that never changes (canonical), plus channel-tagged variants (`?r=wa-group2` or
  seller-named tags) for attribution.
- **Link resilience**: sold-out/deleted items redirect to a "Sold — see what's left"
  state of the store. Group posts must never show dead links.
- Collection/“drop” links: a shareable masonry feed of selected items (one post in the
  group instead of twenty).
- Platform shortener (`snap.sr/xxx`) post-v1.

**Unfurls (the hard engineering)**
- WhatsApp/Telegram/Facebook don't execute JS. `GET /p/:shortId` detects scraper
  user-agents (`WhatsApp`, `facebookexternalhit`, `TelegramBot`, `Slack`) and serves a
  tiny SSR HTML with `og:title` (item name; long → truncate deliberately),
  `og:description` (price + condition + store), `og:image` (generated card),
  `og:site_name` (store). Humans get the SPA. Same URL, two shapes.
- WhatsApp caches unfurls aggressively: when an item changes, its `og:image` URL gains a
  version suffix (`?v=timestamp`). Dashboard "Refresh preview" tool included.

**Generated media (sharp worker, from S3 originals + theme tokens)**
- **1200×630 landscape card** for group unfurls: product photo, price badge in store
  accent color, store name + verified dot, scarcity text.
- **1080×1920 status poster (9:16)** for Instagram/WhatsApp status: full-bleed photo,
  styled price tag, store QR/logo — the auto-generated version of their hand-made Canva posters.

**Share sheet & grid posting (seller side, first-class)**
- Share sheet on **every item** (item editor AND grid card hover/update actions):
  copy caption (auto-composed + editable), copy link, copy card image, download poster,
  open WhatsApp (`whatsapp://send?text=`). Available at the end of the upload wizard —
  post once, momentum kept. Zero login/confirmation friction, logged out works.
- **Post from the catalog grid**: multi-select items in the grid → *Create post pack* —
  choose channel tag, generate a batch of single-item cards/captions or one **collection
  drop card** → send to WhatsApp / copy / download in bulk.
- Attribution: `?r=` tags log view → tap → order signal into `share_events`; surfaces as
  "which groups are selling" in seller analytics — the booster/upgrade narrative and the
  boost-effectiveness proof.

## 9. Seller surfaces

**Item editor (great seller interface, non-negotiable quality bar):**
- Media manager: drag/drop multi-upload (presigned, direct to bucket), reorder,
  set hero, per-image variant previews; video/360 gated by tier.
- Variants matrix: size × color rows with per-variant stock/sku/price delta.
- Pricing: price, compare-at (auto strike-through + discount %).
- Condition chip: `new` / `thrift` + thrift condition grade.
- Status controls: draft → live → paused → sold → archived (grid shows state).
- Inline share strip (see §8) + per-item mini stats (views/taps/orders, boost state).
- **Upload UX principle**: minimum path is photos + price + condition; everything else
  defaults. Cataloging speed decides adoption.

**Catalog grid (the working desktop):**
- Masonry/table hybrid grid mirroring the storefront aesthetic; bulk multi-select;
  inline price/stock edits; filters (category/condition/status/quota warnings);
  badge/state indicators; "uploads needing info" triage view.

**Dashboard zones:** onboarding wizard → catalog grid → item editor → order inbox →
analytics → billing/plan → theme editor.

## 10. Platform admin console (`/admin`)

`platform_owner` role (+ staff roles via audit-logged capabilities later):

| Area | Function |
|---|---|
| Overview | MRR, boost + usage revenue, active stores, signups, recorded sales volume, infra health (jobs, DB, storage, domain queue) |
| Stores | Inspect, view-as-seller, plan change, quota overrides, suspend/restore, usage ledger |
| Billing | Invoices issued/paid/overdue, retry queues, adjustments, plan history |
| Usage & rate card | Per-tier fees toggles/rates (config, not code); draft usage invoices before release |
| Content | Category taxonomy, boost product definitions, storefront presets, discovery-feed curation |
| Moderation | Report queue (counterfeit electronics, stolen media), takedown + seller notification + appeal trail |
| Support | Time-boxed impersonate-seller with mandatory audit log |
| Flags & rollout | Per-tier/store feature toggles, cohort % |
| Audit log | Immutable record of every admin action |

## 11. Revenue model (final — but parked until demand)

**Scope decision (2026-10-17, seller-owned):** no money flows through the platform until
sellers have verified interest and trust. Phase 4's billing engine exists in the codebase
but stays **dormant**: M-Pesa runs in stub mode, no seller-facing money UX is promoted,
and seller-facing money-adjacent work (billing polish, boost funnels, dunning UX) is
deferred until discovery validates the tiers below. Storefront + sharing remain the
build priorities.

| Tier | Price | Gets |
|---|---|---|
| **Grow** | KSh 0 forever | 25 active listings (unlimited drafts/archive), full storefront + generous customization, WhatsApp dispatch, order inbox, Sale Recorder |
| **Boost** (underlay, any tier) | KSh 30–200/action, KSh 500 7-day pop-up packs | Item feature placement 48–72h, extra story slots, seasonal access packs |
| **Commerce** | KSh 999/mo · KSh 300/week · KSh 8,500/quarter | Unlimited items, video/360°, 15-min hold timers, custom subdomain extras, full theme editor, full analytics, share kit, 2 staff seats |
| **Business** | KSh 2,999/mo | + custom domain, custom CSS, advanced analytics/exports, discovery-feed placement, 5–10 staff seats, API/webhooks |
| **Usage charge** (optional per tier, rate-card config) | default: Business tier accrues a fee on platform-recorded sales (e.g. ~1%) | Billed monthly from the meter |

**Metering engine (bill-on-record, no payment rails):**

```
sale recorded (order confirmed / Sale Recorder self-report)
→ usage_events (immutable ledger per store)
→ nightly aggregation → usage_periods
→ cycle end → fee from admin rate card → usage_invoices (draft → release)
→ M-Pesa STK push → paid / retry / dunning
```

- Seller-facing transparent ledger ("48 sales · KSh 182,400 recorded · KSh 1,824 accrued").
- Enforcement levers, proportionate: unpaid → 7d grace → boost/usage tools pause →
  downgrade. **Never deletes a seller's catalog; storefront stays alive.**
- Honest limitation: WhatsApp-handoff sales not logged by the seller are invisible —
  covered by making the Sale Recorder useful (it doubles as their CRM book), not by
  policing. If abuse shows up, a "recording fee" lever exists later.
- Boost revenue starts ~month 3, subscriptions ~month 4, usage fees once metered volume
  justifies it. Break-even at a handful of paid stores vs ~$15–25/mo infra.

## 12. Custom domains (Cloudflare)

- Product: **Cloudflare for SaaS (Custom Hostnames)** on the `storesnap.co.ke` zone
  (~100 hostnames included, then ~$0.10/hostname/mo — cheap enough to include with tier).
- Flow: seller adds domain in dashboard → `domains` row (`pending`) →
  UI shows exact CNAME records (or 1-click if their domain is Cloudflare-managed) →
  pg-boss job verifies via DoH every 15min → register custom hostname via CF API →
  CF provisions TLS per hostname → `active`. Transparent states in UI, no silent fails.
- Request flow: customer domain → CF edge (per-hostname cert; fallback origin
  `app.storesnap.co.ke` → our VPS) → **host-resolution middleware in Express** (top-UX
  from Phase 1, doubles as subdomain router): `shops.storesnap.co.ke` wildcard → subdomain
  lookup; `domains.active` → custom domain → store; miss → branded "not found".
  Logic lives app-side, not proxy-side, so container/proxy choices can change freely.
- Rejected: DIY wildcard certs per customer domain via DNS-01 — brittle across customer
  registrars; CF handles issuance/validation/renewal.

## 13. Build phases (definitions of done)

Realistic solo full-time pacing; each phase ends demo-able and green in CI.

**Phase 0 — Foundations (wk 1)**
Monorepo scaffold; compose: `api/web/postgres/minio/worker/traefik`; Express skeleton
(config, structured logging, error envelope, health); Prisma wired; CI (lint, typecheck,
test, image builds); mockup tokens → Tailwind theme; token lint rule active.
✅ `docker compose up` boots whole system; env docs; CI green.

**Phase 1 — Identity, tenants, host routing (wk 2–3)**
JWT auth + roles + RBAC; seller signup → store wizard (slug, logo/cover, theme preset,
WhatsApp number, location); **host-resolution middleware + `*.shops.storesnap.co.ke`
wildcard**; minimal admin bootstrap command.
✅ Seller registers, creates store, gets live (empty) storefront URL.

**Phase 2 — Catalog, media pipeline, storefront, share v1 (wk 4–6)**
Taxonomy + product CRUD + variants; presigned uploads → worker webp variants (thumb/card
/full); drag-drop uploader; **theme module live** (presets + token CSS injection);
storefront feed/filters incl. condition/product modal (carousel, variants, stock badges)
rendering live data; **canonical `/p/:shortId` links + bot-vs-human SSR OG route + v1
landscape card + copy caption/link**; "share-ready at upload" in the wizard.
✅ Owner uploads an item with photos; buyer sees mockup-identical storefront; item link
unfurls richly in WhatsApp (test: curl with WhatsApp UA).

**Phase 3 — Orders, quota, Sale Recorder (wk 7–8) — MVP**
Buyer cart + checkout form (name/phone/delivery-pickup notes); **transactional order
creation** (stock validate → snapshot prices → decrement → WhatsApp payload deep link);
holds with 15-min timers (tier-gated); seller Order Inbox (status workflow); Sale
Recorder (self-report → usage_events); Free-tier 25-item quota enforcement.
✅ Complete buyer journey; seller manages orders; quota works end to end.

**Phase 4 — Monetization engine (wk 9–10) — BUILT, PARKED**
Implemented and committed (2026-10-17) but left dormant per the scope decision in §11:
the engine exists (plans/entitlements, M-Pesa STK stub/live, metering aggregation,
boosts, minimal admin console; 42 tests incl. billing suite). No seller-facing money
UX is promoted anywhere in the product surface. Before ANY activation with real money:
Daraja production credentials, seller opt-in flow, legal ToS, and an explicit go decision.
Plans/entitlements config matrix; M-Pesa Daraja STK (sandbox → prod) for subscription +
usage invoices; billing module (trials, retries, dunning); **metering engine** (aggregation
job, rate card, invoice drafts); boosts v1 (featured-item flag + expiry + STK purchase);
quota/feature gating; **minimal admin console** (stores + billing + rate card).
✅ Platform collects KSh from Boost + a subscription + an invoice path that works.

**Phase 5 — Business tools & domains (wk 11–13)**
Theme editor (draft/preview/publish); video/360° (ffmpeg → renditions → story player);
auto badges/scarcity; search/sort; wishlists; **Customer Book**, share-funnel analytics +
boost effectiveness; **full Share Kit**: 9:16 status posters, collection drop links,
channel tags UI, unfurl refresh, share sheet polish, **grid multi-select post packs**;
seller analytics; **custom domains** (CF-for-SaaS automation + verification job + UI);
Bio-link/subdomain extras.

*Landed so far (2026-10-17): item deep-link pages (`/stores/:slug`, `/stores/:slug/p/:code`,
any-host resolution), 9:16 status posters with theme accent + versioned cache keys,
channel-tag tap attribution through the human redirect, public browsing via `?storeSlug`,
the checkout contract fix (orders resolve share codes, not just raw ids), and the
**media library** (seller `/dashboard/media`: ledger-backed list with attachment info,
filters, raw-bucket prefix inventory; hard delete removes the upload row AND the bucket
objects - originals + deterministic variants - but is refused with `MEDIA_IN_USE` while a
non-archived listing still references the media; orphan GC with a 24h guard; admin
Storage console with live bucket scan + audit-logged global sweep).
Landed so far (2026-10-18): the **theme editor** (`/dashboard/theme`, draft →
owner-only preview → atomic publish → one-step rollback; fonts/radius/grid density joined
the token set), plus media serving modes (`MEDIA_SERVE_MODE=bucket|proxy`) that keep
unfurls working with a private bucket.
Pending: collection drop links, post packs, video, Customer Book,
seller analytics, custom domains.*

**Phase 6 — Recovery & notifications (wk 14–16) — ONLY IF DEMAND**
In-app storefront checkout is parked post-v1 by scope decision (digital storefront only).
This phase instead: retention kits (email receipts/order confirmations via email;
WhatsApp Business API notifications when seller opts in), PWA installability/offline
cart, feature hardening. Payment rails/delivery remain future extensions, not promises.

**Phase 7 — Production hardening & polish (wk 17–20)**
Test pyramid (Vitest: pricing/snapshot/stock/holds/metering logic; supertest API;
Playwright E2E: signup→upload→share→order, buyer journey, billing states); rate limiting,
Sentry, security audit; nightly `pg_dump` → S3 + restore drill; monitoring/uptime;
CI/CD staging→prod VPS; performance budget (image-first LCP ≤ 2.5s on 3G, Lighthouse ≥90
mobile); moderation + impersonation done; legal pages (Terms/Privacy/seller ToS);
**full admin console**; seller onboarding docs.
✅ **v1.0 production criteria:** real sellers onboarded and billing, 99.5% uptime over
2 weeks, backups verified restorable, <0.1% oversell, share unfurls validated in
WhatsApp/Telegram/Twitter, mobile Lighthouse ≥90.

## 14. Deployment & ops

- Dev: `docker compose up` (MinIO, Postgres, hot-reload).
- Prod: single VPS (Hetzner/DO ~$8–12/mo) + object storage (B2 ~$1–3/mo or S3);
  Traefik w/ ACME + origin shield via CF; GHCR images; `infra/scripts/deploy.sh`
  (build → push → ssh → compose pull → rollout → health check → rollback path).
- Backups: nightly `pg_dump` + bucket snapshot → S3/MinIO, restore drill in Phase 7.
- Envs pinned by `.env.example`; secrets never in repo.
- Cost target: infra **≈ $15–25/mo**; everything priced to break even at a few paid stores.

## 15. Engineering invariants (never violate)

1. **Prices are snapshotted** at order time — never re-read live price from product.
2. **Stock changes are transactional**; oversell is a bug class, not a corner case.
3. **Tier gating = server-enforced** (entitlement checks in the API; the SPA can't be
   the enforcement point).
4. **Tokens only** in storefront components (lint-enforced); themes are validated data
   with fallback defaults and schema versions.
5. **Share links never die** — redirect, don't 404/404.
6. **Add `Aggressive` bots** — a storefront unfurl is a product feature, on every page
   from Phase 2 onward; include bot-UA SSR in feature scope of any storefront change.
7. **usage_events are immutable**; corrections happen on invoices.
8. **No physical-ops features** (delivery, payment handling) creep in without a
   blueprint update — scope discipline is the moat and the discipline.
9. Every admin action lands in `audit_log`.
10. Mobile 3G performance is a feature, not a phase — image budget checked per phase.

## 16. Agent working notes

- Phase 2 infra note: MinIO published its last community images and removed them
  from Docker Hub (project archived Feb 2026). Dev object storage is now
  **RustFS** (`rustfs/rustfs:latest`, S3-compatible, Apache-2.0); buckets and the
  anonymous-download policy are provisioned in-process at boot
  (`ensureBucket()`), not by an `mc` init container. `S3_SIGN_ENDPOINT` exists
  because presigned PUTs must target a browser-reachable host while container
  internals keep using the compose service DNS name.
- Prisma `binaryTargets` includes `linux-musl-openssl-3.0.x`: host dev uses
  glibc, the compose containers run Alpine.
- Phase 4 infra note: the web dev container proxies `/api` via
  `VITE_API_PROXY` (dev compose: `http://api:4000`); the default target stays
  `http://localhost:4000` for host-run Vite. Vite inside a container MUST run
  with `--host 0.0.0.0` (pnpm's `--` eats the flag if passed after a script).
- Phase 4 auth note: `requireRole` parses auth itself rather than wrapping
  `requireAuth` with a continuation callback, because `next(new ApiError(...))`
  into that callback swallowed 401s and answered 403; the web client only
  auto-refreshes a session on real 401s.

- Phase 5 checkout contract: the storefront's public product shape only
  exposes the share `code` (never the raw id), so `POST /market/orders` and
  `GET /market/checkout/:listingId` resolve a listing by code OR id. The
  item routes (`/stores/:slug`, `/stores/:slug/p/:code`) work on any host;
  `?storeSlug=` is the public browsing override in `resolveStoreByHost`
  (explicit query beats host DNS).

- Phase 5 upload race: media confirm fires the variants job, which can
  finish BEFORE the listing media row exists, so the denormalised variant
  keys were lost (posters reported NO_HERO_PHOTO, storefront images stayed
  blank). Variant keys are deterministic (`variantKey(upload.key, v)`), so
  attach self-heals for uploads already `ready` at create/patch time.

- Phase 5 status poster: rendered inline (sharp + SVG overlay) in
  `POST /seller/share/poster` instead of via the queue: one 1080x1920
  composite takes well under a second; move it to the media-variants worker
  when posting volume demands it. Keys are versioned
  (`share/{listingId}/poster/{ts}.webp`) so each render re-scrapes.
- Phase 5 media deletion note: the uploads table is the source of truth for
  "what media exists" and bucket hard-deletes go through
  `deleteObjects()` (batch first, single-object fallback for providers
  without batch deletes). Deletion order: refuse if referenced by a
  non-archived listing, delete bucket objects, then DB rows. A missing
  bucket object never blocks the ledger delete; stragglers are swept by GC.
  If a media provider ever fails mid-delete, the sweep is the backstop -
  never leave the DB row pointing at files the UI already told the user
  were erased.

- Phase 5 share link contract: the seller-facing link that gets copied and
  posted is `${siteUrl}/p/{code}`. That route is the unfurl path: scraper UAs
  (WhatsApp/Telegram/Facebook) get SSR OG HTML, humans get a 302 into
  `/s/{slug}/p/{code}`. Copying the SPA path directly silently disables rich
  previews because scrapers do not run JS, so the phase 2 test asserts the
  copied URL pathname is exactly `/p/{code}`. Dev Vite proxies `/p/` to the
  API to mirror the prod nginx rule.

- Authorization boundary: the admin console is guarded server-side by
  `adminRouter.use(requireRole("platform_owner"))` (all routes) and
  client-side by `RequireOwner`, which confirms access against
  `GET /admin/overview` before rendering. `POST /auth/register` ignores any
  role in the body. `tests/authorization.integration.test.ts` parses the admin
  router source to enumerate its routes, so a new admin route that forgets the
  guard fails CI instead of shipping. End-to-end tour: `docs/walkthrough.md`.

- Phase 5 theme editor note (2026-10-18): the editor (`/dashboard/theme`) writes a
  **draft** (`stores.themeDraft`); the storefront only ever renders `stores.theme`.
  `PATCH /seller/store/theme` saves the draft, `POST /seller/store/theme/publish`
  promotes it atomically and parks the outgoing theme in `stores.themePrevious`,
  `/theme/discard` and `/theme/restore` cover the two escape hatches (restore *swaps*,
  so it toggles). Draft preview is opt-in and owner-only: `GET /market/current-store
  ?preview=draft` resolves through the new `optionalAuth` middleware and returns the
  draft only when the caller owns that store, so a shared preview link can never leak a
  draft. The theme spec grew three non-color tokens (curated font pairings, radius sets,
  grid density) emitted by `themeToCss` as `--st-font-*`, `--st-radius*` and
  `--st-card-gap`; `@theme inline` maps them so tenant CSS keeps working, and the same
  function renders the editor's scoped `#theme-preview` block. Fields are additive and
  optional, so no `schemaVersion` bump was needed and old themes stay valid.
- Tier gate decision (2026-10-18): plans.ts carries `themeEditor: "presets" | "full" |
  "advanced"` (grow = presets), while section 7 grants Grow "full color palette, fonts,
  radius". With monetization parked (section 11) the editor is deliberately **not**
  gated: a free seller can tune palette, fonts, radius and density. `advanced`
  (custom CSS) stays unbuilt and would be the first thing to gate. Say the word if Grow
  should be preset-only after all: it is one check in `stores/service.ts`.

- Phase 5 share kit note (2026-10-18): captions are composed server-side
  (`modules/share/caption.ts`) and returned by `GET /seller/share/links/:listingId`, so the
  upload wizard, the catalog grid and future bulk post packs all post identical text:
  title, price (with "was" when discounted), condition plus store and location, a scarcity
  line only at 3 or fewer, then `Order: {link}`. Plain text only, no emojis, no em-dashes,
  title truncated at 70 characters. Unfurl refresh: og:image carries `?v={version}` where
  the version is `max(updatedAt, ogVersion)` in base36, so ordinary edits invalidate
  WhatsApp's cache automatically and `POST /seller/share/refresh` forces a bump when a
  group holds a stale card. The column is `catalog.listings.ogVersion`.
- Phase 5 media serving note (2026-10-18): `MEDIA_SERVE_MODE` decides how
  derived renditions (webp variants, share posters) reach browsers. `bucket`
  (default) emits direct bucket/CDN URLs and needs anonymous read enabled on
  the bucket. `proxy` emits `{siteUrl}/media/{key}` and the API streams them
  (`modules/media/public.ts`, mounted at `/media`; web nginx and the Vite dev
  proxy forward `/media` there). iDriveE2 denies the bucket policy API and its
  console toggle is manual, so dev runs `proxy`. The proxy serves only derived
  `.webp` artifacts (thumb/card/full, posters), never raw originals, with
  immutable caching, which is what makes `og:image` unfurls work without
  exposing uploads. It is the same-origin URL builder either way, so switching
  modes is one env var.

- Node 22 LTS, pnpm workspaces. Planned commands: `pnpm dev`, `pnpm test`,
  `docker compose -f infra/docker-compose.dev.yml up`.
- Prod-shaped dev stack note (2026-10-17): dev runs "hybrid" - infra
  (postgres, rustfs) in Docker, api/worker/web as host processes because
  container root-owned file writes broke the host vite cache. The host
  processes load the root `.env` via `bash infra/scripts/restart-host-dev.sh`
  (and `apps/api/.env` is a symlink to the root file for dotenv/Prisma).
  Runtime config lives at the root `.env`: Neon Postgres
  (sslmode=require + uselibpqcompat=true; libpq 14+ rejects the pooler with
  only sslmode=require + channel_binding) and iDriveE2 S3 (bucket
  `storesnap`, eu-west-3, path-style, dedicated access key). Neon cannot be
  a TEST database: run the integration suites with the local dev DB,
  `DATABASE_URL=postgres://storesnap:storesnap@localhost:5434/storesnap`
  explicitly. Tests clean their own rows/slugs; never point RUN_DB_TESTS=1
  at production credentials unchecked.
- Mockup reference: `index.html` (+ `iphone_preview_mockup.png`, `iphone_preview_cart.png`)
  — the aesthetic contract: Inter/Cormorant, masonry feed, `lux` cream/gold light theme,
  dark slate theme, emerald/whatsapp CTA colors. Port this into the token system.
- Keep `AGENTS.md` updated when phase scope or invariants change; changes to invariants
  (§15) require calling it out explicitly in conversation before implementation.
