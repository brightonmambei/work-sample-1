# StoreSnap end-to-end walkthrough

Verified against the running dev system on 2026-10-18 (Express API on Neon Postgres,
media on the iDriveE2 `storesnap` bucket, React SPA on Vite).

This is the practical tour: how to boot it, what each of the three surfaces does today,
how the authorization boundaries are enforced, and what is deliberately not built yet.

---

## 1. Boot it

Current machine topology is the **hybrid dev stack**: Postgres and object storage are the
only external dependencies, app processes run on the host for instant HMR.

```bash
# env: runtime config lives in the gitignored root .env (Neon + iDriveE2)
bash infra/scripts/restart-host-dev.sh   # api (:4000) + worker, env sourced from .env
pnpm dev:web                             # SPA (:5173)
```

| Surface | URL |
|---|---|
| API health | `http://localhost:4000/api/v1/health` |
| SPA (storefront + dashboard + admin) | `http://localhost:5173` |
| Local test Postgres / storage | `pnpm up:infra` (docker: postgres :5434, rustfs :9000) |

Platform owner is seeded with `pnpm --filter @storesnap/api admin:bootstrap` using
`ADMIN_EMAIL` / `ADMIN_PASSWORD` from the environment (see `.env`). It is idempotent and
sets `role = platform_owner`.

URL map (the "slugs first" address model, AGENTS.md section 8):

| Path | Serves |
|---|---|
| `/` | Platform home (demo showcase until a tenant is resolved) |
| `/s/{slug}` | Seller storefront (masonry feed, category filter, theme tokens) |
| `/s/{slug}?preview=draft` | Storefront with the owner's unpublished theme (owner only) |
| `/s/{slug}/p/{code}` | Item page (carousel, variants, stock, WhatsApp CTA) |
| `/p/{code}` | Canonical share link: OG HTML to bots, 302 to the item page for humans |
| `/cart`, `/orders/{token}` | Buyer cart/checkout and order tracking |
| `/login`, `/register` | Seller identity |
| `/dashboard/**` | Seller surfaces |
| `/admin` | Platform console (owner only) |

Subdomains (`{slug}.shops.storesnap.co.ke`) and custom domains are upgrade paths; the
host-resolution middleware already maps both, the slug form is what is live today.

---

## 2. Buyer journey

1. **Storefront**: `/s/{slug}` renders the tenant theme (server-merged tokens injected as
   CSS custom properties, no theme JS, no flash) and the live feed with category pills.
   Platform home (`/`) shows the demo showcase while no tenant is resolved.
2. **Item page**: `/s/{slug}/p/{code}` shows photo carousel, price plus compare-at
   strike-through, condition badge, stock state, variant picks and the WhatsApp CTA.
3. **Share link**: `/p/{code}` is the one link a seller posts in a WhatsApp group.
   - scraper user agents (`WhatsApp`, `facebookexternalhit`, `TelegramBot`, `Slackbot`, ...)
     get a tiny SSR HTML with `og:title`, `og:description` (price, condition, store),
     `og:image` (generated card) and `og:site_name`;
   - humans get a 302 into `/s/{slug}/p/{code}`;
   - sold or archived items still resolve: the link redirects to the storefront instead of
     dying (invariant 5);
   - `?r={channel}` tags are recorded as `share_events` view/tap rows for attribution.
4. **Cart and checkout**: `/cart` collects name, phone, pickup/delivery, location and a
   payment *annotation* (M-Pesa, Pochi, cash, other) plus notes. `POST /market/orders`
   validates stock, snapshots item prices, decrements stock transactionally and returns
   the order plus a pre-composed WhatsApp deep link. Payment methods are annotations
   only: no money moves through StoreSnap (AGENTS.md section 11).
5. **Tracking**: `/orders/{token}` is the buyer's status page.

---

## 3. Seller journey

1. **Signup**: `/register` creates a `seller`. Creating a store (`POST /seller/store`)
   takes name, slug, theme preset, WhatsApp number and location, and the storefront is
   live immediately at `/s/{slug}`.
2. **Dashboard** (`/dashboard`) shows the storefront link (copy button), plan state and
   quick counters.
3. **Catalog grid** (`/dashboard/catalog`): masonry/table hybrid, bulk multi-select,
   inline price and stock edits, status/condition filters, and an "uploads needing info"
   triage view. Free tier (Grow) is capped at 25 live items, enforced server side.
4. **Item editor** (`/dashboard/catalog/new`): drag and drop multi-upload straight to the
   bucket with presigned PUTs, then price plus condition as the minimum path (everything
   else defaults), variants matrix (size/color with per-variant stock, SKU, price delta),
   compare-at pricing, status controls and the inline share strip.
5. **Media pipeline**: confirmed uploads enqueue a worker job that produces WebP variants
   (thumb 480w, card 960w, full 1600w, q80). Originals are never modified.
6. **Share kit** (partially built): `GET /seller/share/links/{listingId}` returns the
   canonical `/p/{code}` link plus a **ready-to-paste caption** composed server-side
   (title, price with "was" when discounted, condition, store and location, scarcity,
   `Order: {link}`), which the wizard shows as an editable box and the catalog grid copies
   in one tap. `POST /seller/share/poster` renders a 1080x1920 status poster in the store
   accent with versioned keys, and `POST /seller/share/refresh` bumps the unfurl version so
   WhatsApp re-scrapes a changed item. Post packs and collection drop links are pending.
7. **Orders** (`/dashboard/orders`): inbox with the status workflow
   `pending -> confirmed -> out -> fulfilled | cancelled`.
8. **Sale Recorder** (`/dashboard/sales`): self-reported sales that double as the seller's
   book and feed the (dormant) usage ledger.
9. **Media library** (`/dashboard/media`): every upload in the store, filters, and hard
   delete. Deleting removes the DB row **and** the bucket objects (original plus every
   deterministic variant). If a non-archived listing still references the media, deletion
   is refused with `MEDIA_IN_USE` so a live storefront can never lose its photos. A
   24-hour orphan guard protects in-flight uploads, and GC sweeps stragglers.
10. **Theme editor** (`/dashboard/theme`): preset, palette (accent, background, surface,
    text, muted, borders), curated font pairings, corner radius and grid density, with a
    live preview panel rendered from the same token function the storefront uses. Editing
    writes a **draft**: the storefront keeps serving the published theme until you press
    Publish, `?preview=draft` shows the draft to the owner only, and the previous theme is
    kept for one-click rollback. A shared preview link can never leak a draft.
11. **Billing** (`/dashboard/billing`): the engine exists but is dormant
    (`MPESA_MODE=stub`), no seller-facing money UX is promoted.

---

## 4. Platform console

`/admin` is gated twice:

- **Server (authoritative)**: `adminRouter.use(requireRole("platform_owner"))` covers all
  16 admin routes. Verified live: anonymous callers get 401, a plain seller gets 403 on
  both reads and mutations. Registration ignores any `role` supplied in the body, so role
  self-assignment is not possible, and a tampered access token is rejected by signature
  verification.
- **Client (defence in depth)**: `RequireOwner` confirms with `GET /admin/overview`
  before painting the console, so a stale or spoofed client-side role can never render it.

`apps/api/tests/authorization.integration.test.ts` locks this in: it enumerates the admin
surface **from source**, so a new admin route that forgets the guard fails CI.

Tabs today: Overview (MRR, stores, signups, infra checks), Stores (plan change,
suspend/restore, usage ledger), Billing (invoices: release, void, adjust), Usage and rate
card (admin-editable config, aggregation trigger), Storage (live bucket scan plus an
audit-logged global sweep), Audit log (immutable). Every admin action writes `audit_log`.

---

## 5. Not built yet (honest list)

- **Phase 5 remainder**: collection drop links, post packs from the grid, video/360
  renditions, Customer Book, seller analytics plus boost effectiveness, custom domains
  (Cloudflare for SaaS), share caption composer, unfurl "refresh preview", storefront
  search/sort.
- **Phase 6**: notifications (email receipts/order confirmations, WhatsApp Business when
  sellers opt in), PWA install/offline cart.
- **Phase 7**: E2E Playwright pyramid, rate limiting, Sentry, backups plus restore drill,
  moderation and impersonation flows, legal pages, full admin polish.
- **Monetization (Phase 4)**: built and committed, intentionally dormant. No M-Pesa
  production credentials, no seller opt-in, no ToS: nothing charges anyone.

---

## 6. Current constraints to know about

- **Bucket visibility is no longer blocking.** The iDriveE2 `storesnap` bucket is private and
  cannot be made public through the API (`PutBucketAcl` is not implemented,
  `PutBucketPolicy` is denied), so `MEDIA_SERVE_MODE=proxy` serves derived renditions from
  our own origin at `/media/{key}` instead. Storefront images, share posters and
  `og:image` unfurls all work with the bucket private; only thumb/card/full webp variants
  and posters are exposed, never raw uploads. Flip to `MEDIA_SERVE_MODE=bucket` after
  enabling anonymous read in the iDriveE2 console if you would rather browsers hit the
  bucket/CDN directly.
- **Docker daemon** is down on this machine at the moment, so the local-DB integration
  suites cannot run. Use `pnpm test:integration` (pins local Postgres :5434 and RustFS)
  once it is back. Tests must never point `RUN_DB_TESTS=1` at the Neon production-shaped
  database unchecked.
- **Data in Neon**: the platform owner plus the `kilimani-thrift-hub` store (Commerce
  plan, one live listing, three media items). Its media URLs point at the private bucket,
  so the storefront renders the layout but the photos stay blank until visibility flips.

---

## 7. Verification snippets

Rich unfurl (this is the growth feature, so check it after any storefront change):

```bash
# bot shape: OG HTML
curl -s -A "WhatsApp/2.23.20.0" http://localhost:4000/api/v1/p/<code> | grep -o 'og:[a-z_]*="[^"]*"'
# human shape: 302 into the slug item page
curl -s -o /dev/null -D - -A "Mozilla/5.0 Chrome/120" http://localhost:4000/api/v1/p/<code> | grep -i location
```

Guard checks: `pnpm test:integration` runs the full API suite including
`authorization.integration.test.ts` (admin surface 401/403, tampered token, cross-tenant
isolation) and the media management suite (delete in use, bucket hard delete, GC).
