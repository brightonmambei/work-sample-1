# Running StoreSnap: local machine and production

## TL;DR

| You want | Command |
|---|---|
| Everything in Docker (api/web/db/storage/worker) | `pnpm dev:stack` then open `http://localhost:5173` |
| Backing infra only (postgres + rustfs), app processes on host for fast HMR | `pnpm up:infra`, then `pnpm dev` |
| Stop anything | `pnpm stack:down` (dev stack), `pnpm stop:infra` |
| Production build | `docker compose -f infra/docker-compose.prod.yml --env-file .env up -d --build` |

## How the local setup works

The repo is a pnpm workspace, but it also runs fully inside Docker with the
source mounted into the containers, so file edits sent hot-reload just like on
the host. One thing bit us: containers write cache files into the shared
volume as **root**, which then broke host commands (`EACCES`). The dev compose
now runs the app containers as your own uid (`DEV_UID`/`DEV_GID` in
`.env`), so host and containers can both write.

Two ways to develop:

1. **Full Docker** (`docker compose -f infra/docker-compose.dev.yml up -d`):
   web on :5173, api on :4000. Vite runs inside the container; it needs
   `--host 0.0.0.0` to be reachable through the port map, which the compose
   command handles.
2. **Hybrid** (usually nicer): keep only postgres + rustfs in Docker
   (`pnpm up:infra`), then run `pnpm dev` on the host. Vite and tsx watch run
   natively, so HMR feels instant. DATABASE_URL for host processes comes from
   the shell or `.env`.

If `pnpm dev` ever fails with `EACCES: ... unlink ... .vite/...`, a container
wrote into the host's Vite cache as root. Fix in one line:

```
docker run --rm -v "$PWD":/x alpine chown -R 1000:"$(id -gn -d)" /x/apps/web/node_modules/.vite
```

## Production: one VPS, one compose file

The stack ships as code in `infra/docker-compose.prod.yml`:

```
Internet  →  Traefik (:80 → :443, Let's Encrypt)  →  web (nginx: SPA + reverse-proxy /api, /p)
                                                            → api (Express REST) → postgres
                                                            → worker (pg-boss: images, metering cron)
                                                            → rustfs (S3-compatible media bucket)
```

### Step by step

1. **Server**: any VPS with 2 vCPU/4 GB (Hetzner CX22/DO $12 droplet). Install
   Docker + compose plugin. Create a non-root user, add it to the docker
   group. `git clone` the repo (`--depth 1` of `main` suffices).
2. **Env**: `cp .env.example .env`, then fill:
   - `DATABASE_URL` pointing at `postgres://...@postgres:5432/storesnap` (the
     compose service name, not localhost)
   - a real `JWT_ACCESS_SECRET` (`openssl rand -base64 48`)
   - `CORS_ORIGIN=https://app.storesnap.co.ke`
   - `DOMAIN_APP=app.storesnap.co.ke`,
     `DOMAIN_WILDCARD_BASE=*.shops.storesnap.co.ke` (syntax: match the
     concrete VPS domain you bought),
     `ACME_EMAIL=you@...`
   - `S3_PUBLIC_BASE_URL=https://media.storesnap.co.ke` or the bucket URL as
     exposed through your CDN/proxy; browsers must be able to fetch images.
   - `MPESA_MODE=stub` (money is parked per AGENTS.md section 11)
3. **DNS**:
   - `A/AAAA @ → VPS IP` (or Cloudflare-proxied; see below)
   - wildcard `*.shops → VPS IP` so every seller store resolves
   - `media` (or your image host) → same IP
4. **Deploy**:
   ```
   ./infra/scripts/deploy.sh
   ```
   The script builds the images, applies Prisma migrations
   (`...prisma migrate deploy`), starts the stack, and health-checks both the
   container and the HTTP surface. Re-running it is safe; it is idempotent.
5. **Create the platform owner**:
   ```
   docker compose -f infra/docker-compose.prod.yml run --rm api \
     sh -lc "cd apps/api && pnpm admin:bootstrap"
   ```
   with `ADMIN_EMAIL`/`ADMIN_PASSWORD` in the environment or `.env`.
6. **Verify**: open `https://app.storesnap.co.ke` (dashboard), register a
   seller, create a store, check `https://<store-slug>.shops...` lands on the
   storefront, and share an item link with a curl bot UA test:
   `curl -A "WhatsApp/2..." https://<store>.shops.../p/<id>` should return the
   OG HTML, browsers should redirect to the item page.

### HTTPS details that actually matter

- **Cloudflare in front (recommended)**: orange-cloud the apex and the
  wildcard, set SSL/TLS = Full (strict) with an origin certificate, or leave
  Let's Encrypt HTTP-01 on (it works through CF as long as nothing blocks
  `/.well-known/acme-challenge`). CF absorbs the custom-domain TLS burden
  described in AGENTS.md section 12 (Cloudflare for SaaS).
- **Without CF**: Traefik requests a cert per hostname via HTTP-01. Fine for a
  handful of stores; a wildcard at LE requires DNS-01, not configured here.
- Custom seller domains: Phase 5/12 feature (Cloudflare for SaaS); the compose
  above only terminates the apex + storefront wildcard.

### Local smoke of the production wiring (verified 2026-10-17)

```
docker compose -p storesnap-smoke -f infra/docker-compose.prod.yml \
  --env-file infra/.env.prod \
  -f infra/docker-compose.prod.local-test.yml up -d --no-build
# deploy-migration step, then verify:
docker compose -p storesnap-smoke ... run --rm --no-deps api \
  sh -lc "cd apps/api && pnpm exec prisma migrate deploy"
```

Checked on http://localhost:8083: SPA `200` at `/` and SPA fallbacks;
`/api/v1/health` healthy (`env: production`); share link `/p/<code>` serves
the OG HTML to the WhatsApp bot UA and redirects humans (302) to the SPA item
route. Tear down after: `docker compose -p storesnap-smoke ... down -v`.

### Backups and operations

- Postgres data lives in the `pg_data` volume; media in `rustfs_data`.
- Fresh deploy: the deploy script runs `prisma migrate deploy` BEFORE starting
  the stack. A fresh database without migrations makes the API crash-loop at
  boot (`catalog.categories does not exist`) until that migration runs.
- Nightly dump (Phase 7 scope) is not in the compose yet: for now, cron a
  `pg_dump` against a read-only user into the rustfs bucket or offsite:
  `docker compose -f infra/docker-compose.prod.yml exec postgres pg_dump -U storesnap storesnap | gzip > storesnap-$(date +%F).sql.gz`
- Logs: `docker compose -f infra/docker-compose.prod.yml logs -f api web`.
- Money/monetization stays dormant (`MPESA_MODE=stub`); nothing collects a
  shilling and no code path charges sellers until you make that call.
