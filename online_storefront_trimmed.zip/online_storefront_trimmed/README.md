# StoreSnap

Online storefront platform for Kenyan social sellers. Each seller gets an independent,
media-first digital storefront; buyers browse and order through the storefront or a
WhatsApp handoff.

The engineering blueprint, phase plan, and engineering invariants live in
[AGENTS.md](./AGENTS.md). Read it before making changes.

## Stack

- **Web**: React 19 + Vite + TypeScript + Tailwind v4
- **API**: Express 5 + TypeScript, modular services, REST under `/api/v1`
- **DB**: PostgreSQL (schema-per-module, Prisma) · **Jobs**: pg-boss
- **Storage**: S3-compatible object storage (`MediaProvider` interface; MinIO in dev)
- **Deploy**: Docker Compose, Traefik + TLS in production

## Quickstart (development)

```bash
cp .env.example .env
pnpm install
pnpm dev:stack      # everything in Docker (postgres + rustfs + api + web + worker)
pnpm db:migrate     # only needed once against a fresh dev database
```

Or run the app processes on the host with only the backing infra in Docker:

```bash
pnpm up:infra       # postgres + rustfs only
pnpm dev            # tsx watch api on :4000, vite on :5173 (fast HMR)
```

- Storefront demo: http://localhost:5173
- API health: http://localhost:4000/api/v1/health
- Full runbook (local modes + production deploy): **docs/running.md**

## Repo layout

```
apps/api       Express REST API
apps/web       React storefront + dashboard + admin shells
packages/shared  Zod schemas, design tokens/theme presets, plan config
infra          Docker Compose files, deploy scripts
scripts        repo tooling (token-purity check)
```

## Current status

- [x] Phase 0 — Foundations (scaffold, tokens, masonry shell, API skeleton, CI)
- [x] Phase 1 — Identity, tenants, host routing
- [x] Phase 2 — Catalog, media pipeline, storefront, share v1
- [x] Phase 3 — Orders, quota, Sale Recorder (MVP)
- [x] Phase 4 — Monetization engine (dormant by decision)
- [ ] Phase 5 — Business tools and domains
  - [x] Item deep-link pages (`/stores/:slug`, `/stores/:slug/p/:code`, any host)
  - [x] 9:16 status posters (seller share strip)
  - [x] Channel-tag tap attribution (`?r=` through the human redirect)
  - [x] Public browsing of any store by slug from a non-tenant host
  - [ ] Theme editor (draft/preview/publish)
  - [ ] Collection drop links, grid post packs, video/360, Customer Book, domains
- [ ] Phase 6 — Notifications (only if demand)
- [ ] Phase 7 — Production hardening and polish
