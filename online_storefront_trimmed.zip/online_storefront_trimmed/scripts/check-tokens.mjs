/**
 * Engineering invariant #4 (AGENTS.md section 15):
 * The storefront renders ONLY via design tokens. Raw colors are illegal in
 * component code; tokens.css (and anything explicitly allow-listed) is the
 * single source of raw values.
 *
 * Usage: node scripts/check-tokens.mjs  (CI: same as pnpm lint)
 * Exits 1 with a report if a violation is found.
 */
import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const webSrc = path.join(root, "apps", "web", "src");

const ALLOWLIST = new Set([
  path.join(webSrc, "styles", "tokens.css"),
]);

/** Patterns that count as "raw color" usage. */
const VIOLATIONS = [
  /#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/,
  /rgba?\(\s*\d/,
];

const COLOR_CLASS = /\.(?:bg|text|border|fill|stroke|from|to|via)-(?:\[[^\]]+\]|slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose|white|black)\b/;

function hasViolation(content) {
  return VIOLATIONS.some((rx) => rx.test(content)) || COLOR_CLASS.test(content);
}

function collect(dir, files = []) {
  for (const name of readdirSync(dir)) {
    const full = path.join(dir, name);
    const s = statSync(full);
    if (s.isDirectory()) collect(full, files);
    else files.push(full);
  }
  return files;
}

const files = collect(webSrc).filter((f) =>
  /\.(tsx|ts|css)$/.test(f),
);

const offenders = [];
for (const file of files) {
  if (ALLOWLIST.has(file)) continue;
  const content = readFileSync(file, "utf8");
  if (hasViolation(content)) {
    const lines = content.split("\n");
    const bad = lines
      .map((l, i) => (hasViolation(l) ? i + 1 : null))
      .filter(Boolean);
    offenders.push({ file: path.relative(root, file), lines: bad.join(", ") });
  }
}

if (offenders.length > 0) {
  console.error("\nToken purity check FAILED. Design invariant #4 violated:\n");
  for (const o of offenders) {
    console.error(`  ${o.file} (lines: ${o.lines})`);
  }
  console.error(
    "\nComponents must use design tokens (--st-* / bg-surface etc)." +
      "\nRaw hex/rgba values and hard color classes belong in tokens.css only.\n",
  );
  process.exit(1);
}

console.log(`Token purity check passed (${files.length} files scanned).`);
