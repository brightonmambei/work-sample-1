#!/usr/bin/env bash
# Applies pending migrations against the dev stack database.
# Prereq: infra/docker-compose.dev.yml postgres service is up.
set -euo pipefail
cd "$(dirname "$0")/../../apps/api"
pnpm exec prisma migrate deploy
