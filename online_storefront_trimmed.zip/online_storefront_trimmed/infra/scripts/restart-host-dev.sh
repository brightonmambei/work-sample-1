#!/bin/bash
# Restart host dev processes with the root .env sourced (hybrid dev:
# infra in Docker, api + worker as hot-reload host processes).
# Usage: bash infra/scripts/restart-host-dev.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$ROOT/.env"

# Kill any previous host tsx watchers (patterns avoid self-matching).
pkill -f "cli[.]mjs watch" 2>/dev/null
pkill -f "loader[.]mjs src/index" 2>/dev/null
pkill -f "loader[.]mjs src/worker" 2>/dev/null
sleep 1

cd "$ROOT"
mkdir -p /tmp/opencode

(pnpm dev:api > /tmp/opencode/api-dev.log 2>&1) &
(pnpm --filter @storesnap/api exec tsx watch src/worker.ts > /tmp/opencode/worker-dev.log 2>&1) &
echo "api + worker restarting (logs: /tmp/opencode/{api,worker}-dev.log)"
