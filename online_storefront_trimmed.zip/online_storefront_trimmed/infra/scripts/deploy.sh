#!/bin/sh
# StoreSnap production deploy on a single VPS.
# Assumes the repo is cloned on the server and infra/.env.prod is filled in
# (copy .env.example server-side; secrets never leave the server).
#
#   ./infra/scripts/deploy.sh            # build + migrate + up (zero-downtime intent)
#   ./infra/scripts/deploy.sh --pull     # same, after fetching latest main
set -eu

cd "$(dirname "$0")/../.."

ENV_PATH="${STORESNAP_ENV:-infra/.env.prod}"
COMPOSE="docker compose --env-file .env -f infra/docker-compose.prod.yml"

if [ ! -f .env ]; then
  echo "Missing .env at the repo root. Copy .env.example, fill prod values, keep it server-side." >&2
  exit 1
fi

if [ "${1:-}" = "--pull" ]; then
  echo "==> Fetching latest code"
  git fetch origin && git reset --hard origin/main
fi

echo "==> Building images"
$COMPOSE build

echo "==> Applying database migrations"
$COMPOSE run --rm --no-deps api sh -lc "cd apps/api && DATABASE_URL='$DATABASE_URL' pnpm exec prisma migrate deploy"

echo "==> Starting services"
export COMPOSE_PROFILES=edge
$COMPOSE up -d

echo "==> Waiting for the API to go healthy"
ok=""
for i in $(seq 1 30); do
  if $COMPOSE ps api | grep -q "(healthy)"; then
    ok=1
    break
  fi
  sleep 2
done
if [ -z "$ok" ]; then
  echo "API did not report healthy; last logs:" >&2
  $COMPOSE logs --tail 50 api >&2
  exit 1
fi

echo "==> HTTP health check through the origin"
sleep 3
curl -fsS "http://localhost/api/v1/health" >/dev/null && echo "api ok"

echo "==> Cleaning dangling build cache"
docker image prune -f >/dev/null

echo "Deploy complete."
echo "Rollback note: images are built on the VPS; to roll back, rebuild from the"
echo "previous main (git reset --hard <commit> && ./infra/scripts/deploy.sh)."
