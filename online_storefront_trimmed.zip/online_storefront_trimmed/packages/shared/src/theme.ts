import { z } from "zod";

/**
 * Theming system.
 *
 * Rules (AGENTS.md section 7):
 * - Storefronts render ONLY via CSS custom properties. Components never use
 *   hard-coded colors (CI enforces with scripts/check-tokens.mjs).
 * - A store theme is validated data: preset + overrides, deep-merged and
 *   Zod-validated server-side before it ever reaches a client.
 * - Every token has a global fallback: degradation, never breakage.
 *
 * The CSS variables are named `--st-*` and must stay in sync with
 * apps/web/src/styles/tokens.css.
 */

export const paletteSchema = z
  .object({
    bg: z.string(),
    surface: z.string(),
    surfaceAlt: z.string(),
    border: z.string(),
    fg: z.string(),
    muted: z.string(),
    accent: z.string(),
    accentHover: z.string(),
    accentSoft: z.string(),
    onAccent: z.string(),
    success: z.string(),
    warning: z.string(),
    danger: z.string(),
    skeleton: z.string(),
  })
  .partial()
  .strict();

export const themeOverridesSchema = z
  .object({
    palette: paletteSchema.optional(),
    font: z.enum(["editorial", "clean", "classic", "system"]).optional(),
    radius: z.enum(["sharp", "soft", "round"]).optional(),
    density: z.enum(["comfy", "tight"]).optional(),
  })
  .strict()
  .default({});

export type ThemeFontId = NonNullable<z.infer<typeof themeOverridesSchema>["font"]>;
export type ThemeRadiusId = NonNullable<z.infer<typeof themeOverridesSchema>["radius"]>;
export type ThemeDensityId = NonNullable<z.infer<typeof themeOverridesSchema>["density"]>;

/**
 * Curated pairings only: a seller cannot paste an arbitrary font stack, and
 * every option degrades to a system fallback if a webfont fails to load.
 */
export const themeFonts: Record<ThemeFontId, { label: string; sans: string; display: string }> = {
  editorial: {
    label: "Editorial",
    sans: '"Inter", ui-sans-serif, system-ui, sans-serif',
    display: '"Cormorant Garamond", Georgia, "Times New Roman", serif',
  },
  clean: {
    label: "Clean",
    sans: '"Inter", ui-sans-serif, system-ui, sans-serif',
    display: '"Inter", ui-sans-serif, system-ui, sans-serif',
  },
  classic: {
    label: "Classic",
    sans: '"Inter", ui-sans-serif, system-ui, sans-serif',
    display: 'Georgia, "Times New Roman", serif',
  },
  system: {
    label: "System",
    sans: "ui-sans-serif, system-ui, -apple-system, sans-serif",
    display: "ui-serif, Georgia, serif",
  },
};

export const themeRadii: Record<ThemeRadiusId, { label: string; radius: string; radiusLg: string }> =
  {
    sharp: { label: "Sharp", radius: "4px", radiusLg: "6px" },
    soft: { label: "Soft", radius: "10px", radiusLg: "16px" },
    round: { label: "Round", radius: "18px", radiusLg: "26px" },
  };

export const themeDensities: Record<ThemeDensityId, { label: string; gap: string }> = {
  comfy: { label: "Comfy", gap: "14px" },
  tight: { label: "Tight", gap: "8px" },
};

export const themePresetIdSchema = z.enum([
  "pro-light",
  "pro-dark",
]);
export type ThemePresetId = z.infer<typeof themePresetIdSchema>;

export const themeSchemaSchema = z.literal(1);

export const themeSpecSchema = z
  .object({
    schemaVersion: themeSchemaSchema,
    preset: themePresetIdSchema,
    overrides: themeOverridesSchema,
  })
  .strict();
export type ThemeSpec = z.infer<typeof themeSpecSchema>;

export const defaultThemeSpec: ThemeSpec = {
  schemaVersion: 1,
  preset: "pro-light",
  overrides: {},
};

/**
 * Preset token values (professional, serious palette).
 * CSS variables `--st-*` are the single rendering contract.
 */
export type Palette = {
  bg: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  fg: string;
  muted: string;
  accent: string;
  accentHover: string;
  accentSoft: string;
  onAccent: string;
  success: string;
  warning: string;
  danger: string;
  skeleton: string;
};

export const themePresets: Record<ThemePresetId, Palette> = {
  // Professional light: cool neutral paper, graphite text, one deep-blue accent.
  "pro-light": {
    bg: "#F5F6F8",
    surface: "#FFFFFF",
    surfaceAlt: "#EDEFF3",
    border: "#E3E6EB",
    fg: "#101826",
    muted: "#5B6472",
    accent: "#1D4ED8",
    accentHover: "#1E40AF",
    accentSoft: "rgba(29, 78, 216, 0.08)",
    onAccent: "#FFFFFF",
    success: "#12805C",
    warning: "#A15C07",
    danger: "#B42318",
    skeleton: "#E7EAF0",
  },
  // Professional dark: deep blue-black, keep contrast generous, same accent hue.
  "pro-dark": {
    bg: "#0B0E14",
    surface: "#12161F",
    surfaceAlt: "#181E2A",
    border: "#232A36",
    fg: "#E7EAF0",
    muted: "#8A93A5",
    accent: "#4C7DF0",
    accentHover: "#6A92F5",
    accentSoft: "rgba(76, 125, 240, 0.12)",
    onAccent: "#FFFFFF",
    success: "#3FBF8A",
    warning: "#E0A34F",
    danger: "#EF6A5A",
    skeleton: "#1D2330",
  },
};

/** Ordered mapping literal types for the injection function. */
export const paletteKeys = Object.keys(themePresets["pro-light"]) as Array<
  keyof Palette
>;

/** Deep-merge a validated spec into a flat token record for CSS injection. */
export function resolveThemeTokens(spec: ThemeSpec): Palette {
  const base = themePresets[spec.preset];
  const merged: Palette = { ...base };
  const overrides = spec.overrides?.palette ?? {};
  for (const key of paletteKeys) {
    if (overrides[key]) {
      merged[key] = overrides[key] as string;
    }
  }
  return merged;
}

/** Render tokens as a CSS string (server-injectable, Phase 2+).
 *  The selector defaults to :root for the storefront; the theme editor
 *  reuses it scoped to a preview container. */
export function themeToCss(spec: ThemeSpec, selector = ":root"): string {
  const tokens = resolveThemeTokens(spec);
  const lines = paletteKeys.map(
    (k) => `--st-${k.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}: ${tokens[k]};`,
  );

  const font = themeFonts[spec.overrides?.font ?? "editorial"];
  lines.push(`--st-font-sans: ${font.sans};`);
  lines.push(`--st-font-display: ${font.display};`);

  const radius = themeRadii[spec.overrides?.radius ?? "soft"];
  lines.push(`--st-radius: ${radius.radius};`);
  lines.push(`--st-radius-lg: ${radius.radiusLg};`);

  const density = themeDensities[spec.overrides?.density ?? "comfy"];
  lines.push(`--st-card-gap: ${density.gap};`);

  return `${selector} {\n  ${lines.join("\n  ")}\n}`;
}
