import { z } from "zod";

/**
 * Plan configuration: the single source of truth for tier gating (AGENTS.md
 * section 11). Phase 4 moves this into the billing DB; code stays the reader.
 */

export const planTierSchema = z.enum(["grow", "commerce", "business"]);
export type PlanTier = z.infer<typeof planTierSchema>;

export type PlanConfig = {
  tier: PlanTier;
  label: string;
  priceKesMonthly: number;
  activeListings: number | null; // null = unlimited
  staffSeats: number;
  videoEnabled: boolean;
  holdTimers: boolean;
  themeEditor: "presets" | "full" | "advanced";
  customCss: boolean;
  analyticsLevel: "basic" | "full" | "advanced";
  boostPurchases: boolean;
};

export const tiers = [
  "grow",
  "commerce",
  "business",
] as const satisfies readonly PlanTier[];

/** Order of tiers, lowest first; used for entitlement ">= tier" checks. */
export const tierRank: Record<PlanTier, number> = {
  grow: 0,
  commerce: 1,
  business: 2,
};

export const plans: Record<PlanTier, PlanConfig> = {
  grow: {
    tier: "grow",
    label: "Grow",
    priceKesMonthly: 0,
    activeListings: 25,
    staffSeats: 1,
    videoEnabled: false,
    holdTimers: false,
    themeEditor: "presets",
    customCss: false,
    analyticsLevel: "basic",
    boostPurchases: true,
  },
  commerce: {
    tier: "commerce",
    label: "Commerce",
    priceKesMonthly: 999,
    activeListings: null,
    staffSeats: 2,
    videoEnabled: true,
    holdTimers: true,
    themeEditor: "full",
    customCss: false,
    analyticsLevel: "full",
    boostPurchases: true,
  },
  business: {
    tier: "business",
    label: "Business",
    priceKesMonthly: 2999,
    activeListings: null,
    staffSeats: 10,
    videoEnabled: true,
    holdTimers: true,
    themeEditor: "advanced",
    customCss: true,
    analyticsLevel: "advanced",
    boostPurchases: true,
  },
};

export function tierAtLeast(current: PlanTier, required: PlanTier): boolean {
  return tierRank[current] >= tierRank[required];
}
