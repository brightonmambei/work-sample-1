import { z } from "zod";

/**
 * Catalog contracts shared by API and web.
 * Money is always an integer amount of minor units? No: the market works in
 * whole KSh, so price fields are integers of major units (KSh, no cents).
 */

export const productStatusSchema = z.enum([
  "draft",
  "active",
  "paused",
  "sold_out",
  "archived",
]);
export type ProductStatus = z.infer<typeof productStatusSchema>;

export const productConditionSchema = z.enum(["new", "thrift"]);
export type ProductCondition = z.infer<typeof productConditionSchema>;

/** Shared platform taxonomy (Phase 2 seeds this from the DB, not code). */
export const CATEGORY_IDS = [
  "thrift-clothes",
  "clothes",
  "sneakers",
  "wigs",
  "perfumes",
  "bags",
  "accessories",
  "electronics",
  "general",
] as const;
export type CategoryId = (typeof CATEGORY_IDS)[number];

export const mediaRefSchema = z.object({
  id: z.string(),
  url: z.string().url(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
  kind: z.enum(["image", "video", "360"]).default("image"),
});
export type MediaRef = z.infer<typeof mediaRefSchema>;

export const productSummarySchema = z.object({
  id: z.string(),
  title: z.string().min(1).max(140),
  price: z.number().int().positive(),
  compareAtPrice: z.number().int().positive().nullable(),
  condition: productConditionSchema,
  stock: z.number().int().nonnegative(),
  status: productStatusSchema,
  badge: z.string().max(24).nullable(),
  category: z.string(),
  cover: mediaRefSchema,
});
export type ProductSummary = z.infer<typeof productSummarySchema>;

/** Stripe of a product shown buyer-side. */
export const storefrontBadgeSchema = z.enum([
  "trending",
  "new_arrival",
  "rare_find",
  "budget_pick",
]);
export type StorefrontBadge = z.infer<typeof storefrontBadgeSchema>;

export const apiErrorSchema = z.object({
  ok: z.literal(false),
  error: z.object({
    code: z.string(),
    message: z.string(),
  }),
});
