import { AppRouter } from "./components/AppRouter.js";
import "./index.css";

export default function App(): React.ReactElement {
  return <AppRouter />;
}
