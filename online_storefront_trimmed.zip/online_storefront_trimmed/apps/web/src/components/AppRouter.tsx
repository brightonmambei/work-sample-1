import { useEffect, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes, useParams } from "react-router-dom";
import { useAuthStore } from "../lib/auth.js";
import { api } from "../lib/api.js";
import { StorefrontHome } from "../pages/StorefrontHome.js";
import { ItemPage } from "../pages/ItemPage.js";
import { LoginPage, RegisterPage } from "../pages/AuthPages.js";
import { DashboardHome } from "../pages/DashboardHome.js";
import { CatalogPage } from "../pages/CatalogPage.js";
import { NewItemPage } from "../pages/NewItemPage.js";
import { CartPage, OrderTrackingPage } from "../pages/CartPage.js";
import { OrderInboxPage, SaleRecorderPage } from "../pages/OrdersPages.js";
import { BillingPage } from "../pages/BillingPage.js";
import { AdminConsolePage } from "../pages/AdminConsolePage.js";
import { MediaLibraryPage } from "../pages/MediaLibraryPage.js";
import { ThemeEditorPage } from "../pages/ThemeEditorPage.js";
import { CollectionPage } from "../pages/CollectionPage.js";
import { CollectionsPage } from "../pages/CollectionsPage.js";

function RequireAuth({ children }: { children: React.ReactNode }): React.ReactElement | null {
  const { user, status } = useAuthStore();

  if (status === "booting") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-muted">Loading...</p>
      </div>
    );
  }
  if (user === null) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

/**
 * Admin console: platform_owner only. The API enforces this on every route;
 * this gate additionally CONFIRMS with the server before rendering, so a
 * stale or spoofed client-side role can never paint the console.
 */
function RequireOwner({ children }: { children: React.ReactNode }): React.ReactElement | null {
  const { user, status } = useAuthStore();
  const [verified, setVerified] = useState<"pending" | "yes" | "no">("pending");

  useEffect(() => {
    if (status === "booting" || user === null) return;
    if (user.role !== "platform_owner") {
      setVerified("no");
      return;
    }
    let cancelled = false;
    void api
      .get("/admin/overview")
      .then(() => {
        if (!cancelled) setVerified("yes");
      })
      .catch(() => {
        if (!cancelled) setVerified("no");
      });
    return () => {
      cancelled = true;
    };
  }, [status, user]);

  if (status === "booting") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-muted">Loading...</p>
      </div>
    );
  }
  if (user === null) return <Navigate to="/login" replace />;
  if (user.role !== "platform_owner" || verified === "no") return <Navigate to="/dashboard" replace />;
  if (verified === "pending") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-muted">Checking access...</p>
      </div>
    );
  }
  return <>{children}</>;
}

function RedirectIfAuthed({ children }: { children: React.ReactNode }): React.ReactElement {
  const { user, status } = useAuthStore();
  if (status !== "booting" && user !== null) return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
}

function OrderTrackingRoute(): React.ReactElement {
  const { token } = useParams();
  return <OrderTrackingPage token={token ?? ""} />;
}

/** Storefront pages addressed by slug from any host (the /s model). */
function StoreSlugRoute(): React.ReactElement {
  const { slug } = useParams();
  return <StorefrontHome slug={slug} />;
}

export function AppRouter(): React.ReactElement {
  const bootstrap = useAuthStore((s) => s.bootstrap);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    void bootstrap().finally(() => setBooted(true));
  }, [bootstrap]);

  if (!booted) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-muted">Loading...</p>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<StorefrontHome />} />
        {/* Free tier: slug storefronts on the platform origin (/s). The
            /stores path stays as an alias so old links never die. */}
        <Route path="/s/:slug" element={<StoreSlugRoute />} />
        <Route path="/s/:slug/p/:code" element={<ItemPage />} />
        {/* Drop page: where a collection share link lands. */}
        <Route path="/s/:slug/c/:code" element={<CollectionPage />} />
        <Route path="/stores/:slug" element={<StoreSlugRoute />} />
        <Route path="/stores/:slug/p/:code" element={<ItemPage />} />
        <Route path="/stores/:slug/c/:code" element={<CollectionPage />} />

        {/* Seller drops: build and share a curated set in one place. */}
        <Route
          path="/dashboard/collections"
          element={
            <RequireAuth>
              <CollectionsPage />
            </RequireAuth>
          }
        />
        <Route path="/cart" element={<CartPage />} />
        <Route
          path="/orders/:token"
          element={<OrderTrackingRoute />}
        />
        <Route
          path="/login"
          element={
            <RedirectIfAuthed>
              <LoginPage />
            </RedirectIfAuthed>
          }
        />
        <Route
          path="/register"
          element={
            <RedirectIfAuthed>
              <RegisterPage />
            </RedirectIfAuthed>
          }
        />
        <Route
          path="/dashboard"
          element={
            <RequireAuth>
              <DashboardHome />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/catalog"
          element={
            <RequireAuth>
              <CatalogPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/catalog/new"
          element={
            <RequireAuth>
              <NewItemPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/orders"
          element={
            <RequireAuth>
              <OrderInboxPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/media"
          element={
            <RequireAuth>
              <MediaLibraryPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/theme"
          element={
            <RequireAuth>
              <ThemeEditorPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/sales"
          element={
            <RequireAuth>
              <SaleRecorderPage />
            </RequireAuth>
          }
        />
        <Route
          path="/dashboard/billing"
          element={
            <RequireAuth>
              <BillingPage />
            </RequireAuth>
          }
        />
        <Route
          path="/admin"
          element={
            <RequireOwner>
              <AdminConsolePage />
            </RequireOwner>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
