import { useEffect, useState } from "react";
import { IconBag, IconMoon, IconStore, IconSun } from "./icons.js";

type ThemeOption = "light" | "dark";

function readTheme(): ThemeOption {
  const attr = document.documentElement.getAttribute("data-theme");
  return attr === "dark" ? "dark" : "light";
}

export function Header(): React.ReactElement {
  const [theme, setTheme] = useState<ThemeOption>(readTheme);
  const [cartCount] = useState(0); // Phase 3 wires cart state

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.documentElement.style.colorScheme = theme;
    try {
      localStorage.setItem("storesnap.theme", theme);
    } catch {
      /* storage unavailable, theme still applies for the session */
    }
  }, [theme]);

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur supports-[backdrop-filter]:bg-surface/80">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <a
            href="/"
            className="flex items-center gap-2.5 text-fg"
            aria-label="StoreSnap home"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-token bg-accent text-on-accent">
              <IconStore size={18} />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">
                StoreSnap
              </span>
              <span className="text-[11px] font-medium text-muted">
                Demo storefront, Phase 0
              </span>
            </span>
          </a>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="flex items-center gap-2 rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-muted shadow-strip hover:text-fg"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
          >
            {theme === "dark" ? <IconSun size={15} /> : <IconMoon size={15} />}
            <span className="hidden sm:inline">
              {theme === "dark" ? "Light" : "Dark"}
            </span>
          </button>

          <button
            type="button"
            className="relative flex items-center gap-2 rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg shadow-strip"
            aria-label={`Shopping bag, ${cartCount} items`}
          >
            <IconBag size={16} />
            <span className="hidden sm:inline">Bag</span>
            <span className="absolute -right-1.5 -top-1.5 flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-semibold text-on-accent">
              {cartCount}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
