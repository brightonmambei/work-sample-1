import type { StorefrontCategory } from "../lib/catalog.js";

interface CategoryPillsProps {
  pills: StorefrontCategory[];
  active: string;
  onSelect: (id: string) => void;
}

export function CategoryPills({
  pills,
  active,
  onSelect,
}: CategoryPillsProps): React.ReactElement {
  return (
    <nav aria-label="Categories" className="mb-5">
      <div className="rail flex items-center gap-2 overflow-x-auto pb-1">
        {pills.map((cat) => {
          const isActive = cat.id === active;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelect(cat.id)}
              aria-pressed={isActive}
              className={
                "whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition " +
                (isActive
                  ? "bg-accent text-on-accent shadow-strip"
                  : "border border-border bg-surface text-muted hover:border-fg/20 hover:text-fg")
              }
            >
              {cat.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
