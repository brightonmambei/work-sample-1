/**
 * Storefront chrome shared by every buyer-facing page (home, item, drop):
 * tenant resolution, theme CSS injection and the top bar. Keeping it in one
 * place means a drop page is branded exactly like the feed it came from.
 */
import { useEffect, useState } from "react";
import { themeToCss, type ThemeSpec } from "@storesnap/shared";
import type { ThemeStore } from "../lib/catalog.js";
import { useCart } from "../lib/cart.js";
import { IconBag, IconMoon, IconStore, IconSun } from "../components/icons.js";

export interface CurrentStoreResponse {
  store: ThemeStore | null;
  mode: "tenant" | "platform";
  previewingDraft?: boolean;
  platform?: { name: string; storesDomain: string };
}

/** Varied aspect ratios make the masonry columns read properly. */
export const storefrontAspectClasses = [
  "aspect-[3/4]",
  "aspect-[2/3]",
  "aspect-[4/5]",
  "aspect-[1/1]",
  "aspect-[3/4]",
  "aspect-[4/5]",
  "aspect-[2/3]",
  "aspect-[1/1]",
];

/**
 * Resolve the store for this page. A slug-addressed page (item redirects,
 * seller profile links, drops) must work on any host, so ?storeSlug= is the
 * public override; draft preview stays owner-only and opt-in.
 */
export function useCurrentStore(slug?: string): CurrentStoreResponse | null {
  const [store, setStore] = useState<CurrentStoreResponse | null>(null);

  const slugQuery = slug ? `?storeSlug=${encodeURIComponent(slug)}` : "";
  const wantsPreview =
    typeof window !== "undefined" &&
    new URLSearchParams(window.location.search).get("preview") === "draft";
  const previewQuery = wantsPreview
    ? `/market/current-store${slugQuery}${slugQuery ? "&" : "?"}preview=draft`
    : null;

  useEffect(() => {
    let cancelled = false;
    void fetch(`/api/v1${previewQuery ?? `/market/current-store${slugQuery}`}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((body: { data?: CurrentStoreResponse } | null) => {
        if (!cancelled && body?.data) setStore(body.data);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [slugQuery, previewQuery]);

  return store;
}

/** One server-derived token block, injected before anything paints. */
export function useTenantTheme(theme: ThemeSpec | null | undefined): void {
  useEffect(() => {
    if (!theme) return;
    const el = document.createElement("style");
    el.id = "tenant-theme";
    el.textContent = themeToCss(theme);
    document.head.appendChild(el);
    return () => {
      el.remove();
    };
  }, [theme]);
}

export function StorefrontHeader({
  mode,
  store,
  homeHref,
}: {
  mode: "tenant" | "platform";
  store: CurrentStoreResponse | null;
  homeHref: string;
}): React.ReactElement {
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    const attr = document.documentElement.getAttribute("data-theme");
    return attr === "dark" ? "dark" : "light";
  });
  const cartCount = useCart((s) => s.items.reduce((n, i) => n + i.quantity, 0));

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.documentElement.style.colorScheme = theme;
    try {
      localStorage.setItem("storesnap.theme", theme);
    } catch {
      /* storage unavailable, theme still applies this session */
    }
  }, [theme]);

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur supports-[backdrop-filter]:bg-surface/80">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <a
          href={homeHref}
          className="flex min-w-0 items-center gap-2.5 text-fg"
          aria-label={mode === "tenant" && store?.store ? store.store.name : "StoreSnap home"}
        >
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-token bg-accent text-on-accent">
            <IconStore size={18} />
          </span>
          <span className="flex min-w-0 flex-col leading-tight">
            <span className="truncate font-display text-base font-semibold tracking-wide sm:text-lg">
              {mode === "tenant" && store?.store ? store.store.name : "StoreSnap"}
            </span>
            {/* The slug path is a technical address already visible in the
                browser bar: buyers get the store name, nothing else. */}
            {mode === "platform" && (
              <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted">
                Demo storefront
              </span>
            )}
          </span>
        </a>

        <div className="flex shrink-0 items-center gap-2">
          <a
            href="/cart"
            className="relative flex items-center gap-2 rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg shadow-strip hover:border-accent/40"
            aria-label="Open your bag"
          >
            <IconBag size={15} />
            <span className="hidden sm:inline">Bag</span>
            {cartCount > 0 && (
              <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-bold text-on-accent">
                {cartCount > 9 ? "9+" : cartCount}
              </span>
            )}
          </a>
          <a
            href="/dashboard"
            className="whitespace-nowrap rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg shadow-strip hover:border-accent/40"
          >
            <span className="hidden sm:inline">Sell on StoreSnap</span>
            <span className="sm:hidden">Sell</span>
          </a>
          <button
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="flex items-center gap-2 rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-muted shadow-strip hover:text-fg"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
          >
            {theme === "dark" ? <IconSun size={15} /> : <IconMoon size={15} />}
            <span className="hidden sm:inline">{theme === "dark" ? "Light" : "Dark"}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
