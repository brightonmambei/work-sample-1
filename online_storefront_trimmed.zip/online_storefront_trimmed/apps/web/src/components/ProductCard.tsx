import type { StorefrontProduct } from "../lib/catalog.js";
import { coverUrlOf } from "../lib/catalog.js";
import { IconEye } from "./icons.js";

interface ProductCardProps {
  product: StorefrontProduct;
  aspectClass: string;
  onOpen: (id: string) => void;
}

export function ProductCard({
  product,
  aspectClass,
  onOpen,
}: ProductCardProps): React.ReactElement {
  const isThrift = product.condition === "thrift";
  const discounted =
    product.compareAtKes !== null && product.compareAtKes > product.priceKes;
  const cover = coverUrlOf(product);

  return (
    <article className="masonry-item">
      <button
        type="button"
        onClick={() => onOpen(product.id)}
        className="group block w-full overflow-hidden rounded-token-lg border border-border bg-surface text-left shadow-strip transition hover:shadow-raised"
      >
        <div className={`relative overflow-hidden bg-skeleton ${aspectClass}`}>
          {cover !== null ? (
            <img
              src={cover}
              alt={product.title}
              loading="lazy"
              className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-surface-alt">
              <span className="text-[11px] font-medium uppercase tracking-wider text-muted">
                Photo coming
              </span>
            </div>
          )}

          {product.badgeText !== null && (
            <span className="absolute left-3 top-3 rounded-full bg-surface/95 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-fg shadow-strip">
              {product.badgeText}
            </span>
          )}

          <span className="absolute right-3 top-3 rounded-full bg-surface/95 px-2 py-1 text-[10px] font-medium text-muted shadow-strip">
            {isThrift ? "Thrift" : "New"}
          </span>

          {product.stock === 0 && (
            <span className="absolute inset-x-3 bottom-3 rounded-token bg-fg/85 px-2 py-1 text-center text-[10px] font-semibold uppercase tracking-wider text-surface">
              Sold out
            </span>
          )}

          {product.stock > 0 && (
            <span className="absolute bottom-3 right-3 flex h-8 w-8 translate-y-1 items-center justify-center rounded-full bg-surface/95 text-fg opacity-0 shadow-strip transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
              <IconEye size={14} />
            </span>
          )}
        </div>

        <div className="space-y-1.5 p-4">
          <h3 className="line-clamp-1 font-display text-base font-semibold leading-snug text-fg">
            {product.title}
          </h3>
          <div className="flex items-baseline justify-between">
            <span className="text-sm font-semibold tabular-nums text-fg">
              KSh {product.priceKes.toLocaleString("en-KE")}
            </span>
            {discounted && (
              <span className="text-xs tabular-nums text-muted line-through">
                KSh {product.compareAtKes!.toLocaleString("en-KE")}
              </span>
            )}
          </div>
          {product.stock > 0 && product.stock <= 2 && (
            <p className="text-[11px] font-medium tracking-wide text-warning">
              Only {product.stock} left
            </p>
          )}
        </div>
      </button>
    </article>
  );
}
