import { useMemo, useState } from "react";
import type { StorefrontProduct } from "../lib/catalog.js";
import { coverUrlOf } from "../lib/catalog.js";
import { useCart } from "../lib/cart.js";
import { IconBag, IconCheck } from "./icons.js";

interface ProductModalProps {
  product: StorefrontProduct | null;
  onClose: () => void;
  /** Tenant slug for checkout routing from a non-tenant host. */
  storeSlug?: string | null;
}

export function ProductModal({
  product,
  onClose,
  storeSlug = null,
}: ProductModalProps): React.ReactElement | null {
  const [sizeIdx, setSizeIdx] = useState(0);
  const [colorIdx, setColorIdx] = useState(0);
  const [added, setAdded] = useState(false);
  const add = useCart((s) => s.add);

  const size = useMemo(
    () => product?.sizes[sizeIdx] ?? "",
    [product, sizeIdx],
  );
  const color = useMemo(
    () => product?.colors[colorIdx] ?? "",
    [product, colorIdx],
  );

  if (product === null) return null;

  const cover = coverUrlOf(product);
  const soldOut = product.stock === 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={product.title}
      onClick={onClose}
    >
      <div
        className="my-auto w-full max-w-3xl overflow-hidden rounded-token-lg border border-border bg-surface shadow-raised"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col md:flex-row">
          <div className="relative flex min-h-[280px] flex-1 items-stretch bg-skeleton md:h-[460px]">
            {cover !== null ? (
              <img
                src={cover}
                alt={product.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-surface-alt">
                <span className="text-xs font-medium uppercase tracking-wider text-muted">
                  Photo coming
                </span>
              </div>
            )}
            <button
              type="button"
              onClick={onClose}
              className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-surface text-fg shadow-strip"
              aria-label="Close"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4" aria-hidden>
                <path d="M18 6 6 18M6 6l12 12" strokeLinecap="round" />
              </svg>
            </button>
          </div>

          <div className="flex w-full flex-col gap-4 p-6 md:w-[46%] md:justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-accent">
                  {product.badgeText ??
                    (product.condition === "thrift" ? "Thrift item" : "New item")}
                </span>
                <span className="text-[11px] text-muted">Ref {product.code}</span>
              </div>

              <div>
                <h2 className="font-display text-2xl font-semibold leading-snug text-fg">
                  {product.title}
                </h2>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="text-2xl font-semibold tabular-nums text-fg">
                    KSh {product.priceKes.toLocaleString("en-KE")}
                  </span>
                  {product.compareAtKes !== null &&
                    product.compareAtKes > product.priceKes && (
                      <span className="text-xs text-muted line-through">
                        KSh {product.compareAtKes.toLocaleString("en-KE")}
                      </span>
                    )}
                </div>
              </div>

              {product.description !== null && (
                <p className="text-xs leading-relaxed text-muted">
                  {product.description}
                </p>
              )}

              {product.sizes.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-muted">
                    Size
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((sz, i) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setSizeIdx(i)}
                        className={
                          "rounded-token px-3 py-1.5 text-xs font-medium transition " +
                          (i === sizeIdx
                            ? "bg-accent text-on-accent"
                            : "border border-border bg-surface-alt text-muted hover:text-fg")
                        }
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {product.colors.length > 0 && (
                <div className="space-y-2">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-muted">
                    Color
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.colors.map((c, i) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setColorIdx(i)}
                        className={
                          "rounded-token px-3 py-1.5 text-xs font-medium transition " +
                          (i === colorIdx
                            ? "bg-accent text-on-accent"
                            : "border border-border bg-surface-alt text-muted hover:text-fg")
                        }
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <p className="text-[11px] font-medium text-muted">
                {soldOut
                  ? "Currently sold out."
                  : product.condition === "thrift"
                    ? "Thrift condition, checked in person."
                    : "Brand new."}
              </p>
            </div>

            <div className="space-y-2 border-t border-border pt-4">
              <button
                type="button"
                disabled={soldOut}
                onClick={() => {
                  add({
                    listingId: product.id,
                    code: product.code,
                    title: product.title,
                    priceKes: product.priceKes,
                    condition: product.condition,
                    size: product.sizes.length > 0 ? (product.sizes[sizeIdx] ?? null) : null,
                    color: product.colors.length > 0 ? (product.colors[colorIdx] ?? null) : null,
                    thumbUrl: coverUrlOf(product),
                    storeSlug,
                  });
                  setAdded(true);
                  window.setTimeout(() => setAdded(false), 1200);
                }}
                className="w-full rounded-token bg-accent py-3 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
              >
                {added ? (
                  <span className="inline-flex items-center justify-center gap-2">
                    <IconCheck size={15} />
                    Added to bag
                  </span>
                ) : (
                  <span className="inline-flex items-center justify-center gap-2">
                    <IconBag size={15} />
                    Add to bag
                  </span>
                )}
              </button>
              <p className="text-center text-[10px] leading-relaxed text-muted">
                {product.sizes.length + product.colors.length > 0
                  ? `Size: ${size || "-"} / Color: ${color || "-"}. `
                  : ""}
                Checkout arranges hand-off with the seller; payment stays
                between you and the seller.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
