/**
 * Masonry grid: Pinterest-style columns (kept from the mockup design).
 * Column layout is CSS-driven in index.css; this component only sequences items.
 */
import type { ReactNode } from "react";

export function MasonryGrid({ children }: { children: ReactNode }): React.ReactElement {
  return <div className="masonry-grid">{children}</div>;
}
