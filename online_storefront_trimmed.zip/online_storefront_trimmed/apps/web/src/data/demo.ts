import type { ProductSummary } from "@storesnap/shared";
import type { StorefrontProduct } from "../lib/catalog.js";

/**
 * Phase 0 demo catalog. Static until Phase 2 wires the catalog API.
 * Cover assets are local studio placeholders (professional grade, no emoji).
 * Prices are integers in KSh.
 */

export interface DemoProduct extends ProductSummary {
  description: string;
  variantSizes: string[];
  variantColors: string[];
}

const placeholder = (n: number) => `/placeholders/product-${String(n).padStart(2, "0")}.svg`;

export const demoProducts: DemoProduct[] = [
  {
    id: "demo-1",
    title: "Leather Court Sneaker",
    price: 3800,
    compareAtPrice: 4500,
    condition: "new",
    stock: 3,
    status: "active",
    badge: "Trending",
    category: "sneakers",
    cover: { id: "p1", url: placeholder(1), kind: "image" },
    description:
      "Full grain leather upper with a corkbed midsole. Retailed with a two year resole program.",
    variantSizes: ["EU 40", "EU 41", "EU 42", "EU 43"],
    variantColors: ["Bone", "Espresso"],
  },
  {
    id: "demo-2",
    title: "Selvedge Utility Jacket",
    price: 2400,
    compareAtPrice: 3000,
    condition: "thrift",
    stock: 1,
    status: "active",
    badge: "Only 1 left",
    category: "thrift-clothes",
    cover: { id: "p2", url: placeholder(2), kind: "image" },
    description:
      "Authenticated 90s denim jacket. Double stitched, brass hardware, single owner.",
    variantSizes: ["M", "L", "XL"],
    variantColors: ["Indigo"],
  },
  {
    id: "demo-3",
    title: "Crossbody Satchel",
    price: 1800,
    compareAtPrice: 2200,
    condition: "new",
    stock: 5,
    status: "active",
    badge: "New arrival",
    category: "bags",
    cover: { id: "p3", url: placeholder(3), kind: "image" },
    description:
      "Vegetable tanned leather, interior organizer, adjustable strap. Artisan produced.",
    variantSizes: ["One size"],
    variantColors: ["Chestnut", "Slate"],
  },
  {
    id: "demo-4",
    title: "Merino Roll Neck",
    price: 2200,
    compareAtPrice: 2800,
    condition: "new",
    stock: 8,
    status: "active",
    badge: null,
    category: "clothes",
    cover: { id: "p4", url: placeholder(4), kind: "image" },
    description:
      "350 gsm brushed merino blend. Warm knit for cooler evenings, machine washable.",
    variantSizes: ["S", "M", "L"],
    variantColors: ["Olive", "Charcoal"],
  },
  {
    id: "demo-5",
    title: "Field Court High Top",
    price: 4900,
    compareAtPrice: 5800,
    condition: "thrift",
    stock: 1,
    status: "active",
    badge: "Rare find",
    category: "sneakers",
    cover: { id: "p5", url: placeholder(5), kind: "image" },
    description:
      "Original leather high top, premium edition. Verified as a true single-owner pair.",
    variantSizes: ["EU 42", "EU 43"],
    variantColors: ["Crimson"],
  },
  {
    id: "demo-6",
    title: "Acetate Frame Sunglasses",
    price: 950,
    compareAtPrice: 1400,
    condition: "new",
    stock: 12,
    status: "active",
    badge: "Budget pick",
    category: "accessories",
    cover: { id: "p6", url: placeholder(6), kind: "image" },
    description:
      "UV400 polarized lenses, hand polished acetate frame, comes with a hard case.",
    variantSizes: ["Standard"],
    variantColors: ["Black", "Tortoise"],
  },
];

export const demoCategories = [
  { id: "all", label: "All items" },
  { id: "sneakers", label: "Sneakers" },
  { id: "thrift-clothes", label: "Thrift" },
  { id: "bags", label: "Bags" },
  { id: "accessories", label: "Accessories" },
  { id: "clothes", label: "Clothes" },
] as const;

/** Adapt demo rows to the unified storefront shape (platform showcase mode). */
export const demoStorefrontProducts = demoProducts.map<StorefrontProduct>((p) => ({
  id: p.id,
  code: p.id.replace("demo-", "ref-"),
  title: p.title,
  description: p.description,
  priceKes: p.price,
  compareAtKes: p.compareAtPrice,
  condition: p.condition,
  conditionGrade: null,
  stock: p.stock,
  badgeText: p.badge,
  sizes: p.variantSizes,
  colors: p.variantColors,
  media: [
    {
      id: p.cover.id,
      thumbUrl: p.cover.url,
      cardUrl: p.cover.url,
      fullUrl: p.cover.url,
    },
  ],
}));

/** Category filter support for demo rows (code -> category id). */
export const demoCategoryByCode: Record<string, string> = Object.fromEntries(
  demoProducts.map((p) => [p.id.replace("demo-", "ref-"), p.category]),
);
