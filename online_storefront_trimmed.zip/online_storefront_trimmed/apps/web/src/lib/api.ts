/**
 * API client: JSON fetch wrapper aligned with the api response envelopes
 * { ok: true, data } / { ok: false, error }. Auth header comes from the
 * session store; a 401 triggers one refresh-and-retry round trip.
 */

export class ApiClientError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
    this.name = "ApiClientError";
  }
}

interface RequestOptions {
  method?: string;
  body?: unknown;
}

let onUnauthorized: (() => void) | null = null;

/** Bind a callback that runs when refresh also fails (clears the session). */
export function setUnauthorizedHandler(handler: () => void): void {
  onUnauthorized = handler;
}

let accessToken: string | null = null;

/** The session store calls this whenever the access token changes. */
export function setAccessToken(token: string | null): void {
  accessToken = token;
}

function authHeaders(): Record<string, string> {
  return accessToken ? { Authorization: `Bearer ${accessToken}` } : {};
}

export const api = {
  async request<T>(
    path: string,
    options: RequestOptions = {},
    attempt = 0,
  ): Promise<T> {
    const { method = "GET", body } = options;

    const res = await fetch(`/api/v1${path}`, {
      method,
      credentials: "include",
      headers: {
        ...authHeaders(),
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    });

    if (res.status === 401 && attempt < 1 && accessToken !== null) {
      const refreshed = await api.raw("/auth/refresh", { method: "POST" });
      if (refreshed.ok) {
        const payload = (await refreshed.json()) as { data?: { accessToken?: string } };
        if (payload.data?.accessToken) setAccessToken(payload.data.accessToken);
        return api.request<T>(path, options, attempt + 1);
      }
      onUnauthorized?.();
    }

    let payload: unknown;
    try {
      payload = await res.json();
    } catch {
      throw new ApiClientError(res.status, "EMPTY_RESPONSE", "Server returned no data.");
    }

    const envelope = payload as { ok?: boolean; data?: T; error?: { code: string; message: string } };

    if (!res.ok || envelope.ok !== true) {
      throw new ApiClientError(
        res.status,
        envelope.error?.code ?? "HTTP_ERROR",
        envelope.error?.message ?? "Request failed.",
      );
    }
    return envelope.data as T;
  },

  /** Raw pass-through used internally (no envelope unwrapping). */
  async raw(path: string, options: RequestOptions = {}): Promise<Response> {
    return fetch(`/api/v1${path}`, {
      method: options.method ?? "GET",
      credentials: "include",
      headers: {
        ...(options.body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      ...(options.body !== undefined ? { body: JSON.stringify(options.body) } : {}),
    });
  },

  get: <T>(path: string) => api.request<T>(path),
  post: <T>(path: string, body?: unknown) => api.request<T>(path, { method: "POST", body }),
  put: <T>(path: string, body?: unknown) => api.request<T>(path, { method: "PUT", body }),
  patch: <T>(path: string, body?: unknown) => api.request<T>(path, { method: "PATCH", body }),
  del: <T>(path: string, body?: unknown) => api.request<T>(path, { method: "DELETE", body }),
};
