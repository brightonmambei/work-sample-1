/**
 * Buyer cart (client-side state; stock truth stays server-side at checkout).
 * Persisted so a share-link browse that spans days survives tab closes.
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CartItem {
  listingId: string;
  code: string;
  title: string;
  priceKes: number;
  condition: string;
  quantity: number;
  size: string | null;
  color: string | null;
  thumbUrl: string | null;
  /** Store slug, so a checkout POSTed from any host lands on the right tenant. */
  storeSlug?: string | null;
}

interface CartState {
  items: CartItem[];
  add: (item: Omit<CartItem, "quantity"> & { quantity?: number }) => void;
  remove: (listingId: string, size: string | null, color: string | null) => void;
  setQuantity: (listingId: string, size: string | null, color: string | null, qty: number) => void;
  clear: () => void;
  count: () => number;
  total: () => number;
}

function sameItem(a: Pick<CartItem, "listingId" | "size" | "color">, b: CartItem): boolean {
  return a.listingId === b.listingId && a.size === b.size && a.color === b.color;
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: (item) =>
        set((state) => {
          const qty = item.quantity ?? 1;
          const existing = state.items.find((i) => sameItem(item, i));
          if (existing !== undefined) {
            return {
              items: state.items.map((i) =>
                sameItem(item, i) ? { ...i, quantity: Math.min(i.quantity + qty, 10) } : i,
              ),
            };
          }
          return { items: [...state.items, { ...item, quantity: qty }] };
        }),
      remove: (listingId, size, color) =>
        set((state) => ({
          items: state.items.filter(
            (i) => !sameItem({ listingId, size, color }, i),
          ),
        })),
      setQuantity: (listingId, size, color, qty) =>
        set((state) => ({
          items:
            qty <= 0
              ? state.items.filter((i) => !sameItem({ listingId, size, color }, i))
              : state.items.map((i) =>
                  sameItem({ listingId, size, color }, i)
                    ? { ...i, quantity: Math.min(qty, 10) }
                    : i,
                ),
        })),
      clear: () => set({ items: [] }),
      count: () => get().items.reduce((n, i) => n + i.quantity, 0),
      total: () => get().items.reduce((n, i) => n + i.priceKes * i.quantity, 0),
    }),
    { name: "storesnap.cart" },
  ),
);
