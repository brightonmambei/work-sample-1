/**
 * Catalog client: live API types and the mapping into storefront display
 * products. Demo products (platform mode) share the same shape so the
 * masonry grid and modal render one code path.
 */
import type { ThemeSpec } from "@storesnap/shared";

export interface StorefrontMedia {
  id: string;
  thumbUrl: string | null;
  cardUrl: string | null;
  fullUrl: string | null;
}

export interface StorefrontProduct {
  id: string;
  code: string;
  title: string;
  description: string | null;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  badgeText: string | null;
  sizes: string[];
  colors: string[];
  media: StorefrontMedia[];
}

export interface StorefrontCategory {
  id: string;
  slug: string;
  label: string;
}

export interface ThemeStore {
  slug: string;
  name: string;
  tagline: string | null;
  logoUrl: string | null;
  coverUrl: string | null;
  plan: string;
  status: string;
  theme: ThemeSpec;
}

interface RawMediaRow {
  id: string;
  thumbUrl: string | null;
  cardUrl: string | null;
  fullUrl: string | null;
}

interface RawListing {
  code: string;
  title: string;
  description: string | null;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  badgeText: string | null;
  sizes: string[];
  colors: string[];
  media: RawMediaRow[];
  categorySlug?: string | null;
}

export function toStorefrontProduct(raw: RawListing): StorefrontProduct {
  return {
    id: raw.code,
    code: raw.code,
    title: raw.title,
    description: raw.description,
    priceKes: raw.priceKes,
    compareAtKes: raw.compareAtKes,
    condition: raw.condition,
    conditionGrade: raw.conditionGrade,
    stock: raw.stock,
    badgeText: raw.badgeText,
    sizes: raw.sizes,
    colors: raw.colors,
    media: raw.media,
  };
}

export function toStorefrontProducts(raw: unknown[]): StorefrontProduct[] {
  return (raw as RawListing[]).map(toStorefrontProduct);
}

export const fallbackCategories: StorefrontCategory[] = [
  { id: "all", slug: "all", label: "All items" },
];

export function coverUrlOf(product: StorefrontProduct): string | null {
  const hero = product.media[0];
  if (product.media.length === 0 || hero === undefined) return null;
  return hero.cardUrl ?? hero.thumbUrl ?? hero.fullUrl;
}
