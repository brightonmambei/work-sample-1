/**
 * Session store (zustand). Access token in memory only; the httpOnly refresh
 * cookie is the durable credential. On boot we try /auth/refresh to restore.
 */

import { create } from "zustand";
import { api, setAccessToken, setUnauthorizedHandler } from "./api.js";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: string;
  status: string;
}

interface AuthState {
  user: SessionUser | null;
  status: "booting" | "ready" | "authenticating";
  bootstrap: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (input: { name: string; email: string; password: string }) => Promise<void>;
  signOut: () => Promise<void>;
}

interface AuthResponse {
  user: SessionUser;
  accessToken: string;
}

export const useAuthStore = create<AuthState>((set) => {
  const apply = (data: AuthResponse) => {
    setAccessToken(data.accessToken);
    set({ user: data.user, status: "ready" });
  };

  return {
    user: null,
    status: "booting",

    bootstrap: async () => {
      try {
        const res = await api.raw("/auth/refresh", { method: "POST" });
        if (res.ok) {
          const payload = (await res.json()) as { data: AuthResponse };
          apply(payload.data);
        } else {
          setAccessToken(null);
          set({ user: null, status: "ready" });
        }
      } catch {
        setAccessToken(null);
        set({ user: null, status: "ready" });
      }
    },

    login: async (email, password) => {
      set({ status: "authenticating" });
      const data = await api.post<AuthResponse>("/auth/login", { email, password });
      apply(data);
    },

    register: async ({ name, email, password }) => {
      set({ status: "authenticating" });
      const data = await api.post<AuthResponse>("/auth/register", {
        name,
        email,
        password,
        intent: "seller",
      });
      apply(data);
    },

    signOut: async () => {
      try {
        await api.post("/auth/logout");
      } finally {
        setAccessToken(null);
        set({ user: null, status: "ready" });
      }
    },
  };
});

setUnauthorizedHandler(() => {
  setAccessToken(null);
  useAuthStore.setState({ user: null, status: "ready" });
});
