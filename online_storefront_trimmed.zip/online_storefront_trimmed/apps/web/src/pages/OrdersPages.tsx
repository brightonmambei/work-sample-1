import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { FormError } from "../pages/CatalogPage.js";
import { IconSpinner } from "../components/icons.js";

interface OrderRow {
  id: string;
  buyerName: string;
  buyerPhone: string;
  buyerLocation: string | null;
  fulfillment: "pickup" | "delivery";
  paymentMethod: string;
  status: "pending" | "confirmed" | "out" | "fulfilled" | "cancelled";
  source: "web" | "whatsapp" | "self_report";
  note: string | null;
  totalKes: number;
  createdAt: string;
  items: Array<{ id: string; title: string; priceKes: number; quantity: number; size: string | null; color: string | null; condition: string }>;
}

const STATUS_LABELS: Record<OrderRow["status"], string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  out: "Out",
  fulfilled: "Fulfilled",
  cancelled: "Cancelled",
};

/** Next action per status: the inbox is about one tap per order. */
const NEXT_ACTIONS: Array<{
  from: OrderRow["status"][];
  to: "confirmed" | "out" | "fulfilled" | "cancelled";
  label: string;
  accent: boolean;
}> = [
  { from: ["pending"], to: "confirmed", label: "Confirm", accent: true },
  { from: ["confirmed"], to: "out", label: "Out for hand-off", accent: true },
  { from: ["out"], to: "fulfilled", label: "Mark handed over", accent: true },
  { from: ["pending", "confirmed", "out"], to: "cancelled", label: "Cancel", accent: false },
];

interface UsageSummary {
  units: number;
  recordedKes: number;
}

export function OrderInboxPage(): React.ReactElement {
  const [orders, setOrders] = useState<OrderRow[] | null>(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback((status: string) => {
    void api
      .get<{ orders: OrderRow[] }>(
        `/seller/orders${status !== "" ? `?status=${encodeURIComponent(status)}` : ""}`,
      )
      .then((data) => setOrders(data.orders))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load orders."),
      );
  }, []);

  useEffect(() => {
    load(statusFilter);
  }, [statusFilter, load]);

  async function transition(order: OrderRow, to: string): Promise<void> {
    setBusyId(order.id);
    setError(null);
    try {
      await api.post(`/seller/orders/${order.id}/transition`, { status: to });
      load(statusFilter);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not update the order.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Order inbox
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Link to="/dashboard/catalog" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Catalog
            </Link>
            <Link to="/dashboard/sales" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Sale recorder
            </Link>
            <Link to="/dashboard" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Store settings
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-semibold text-fg">Orders</h1>
            <p className="mt-1 text-sm text-muted">
              Every order your storefront recorded. Buyers pay you directly.
            </p>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label="Filter by status"
            className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg"
          >
            <option value="">All statuses</option>
            {Object.entries(STATUS_LABELS).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </div>

        <FormError message={error} />

        {orders === null ? (
          <p className="py-20 text-center text-sm text-muted">Loading...</p>
        ) : orders.length === 0 ? (
          <div className="rounded-token-lg border border-border bg-surface p-10 text-center shadow-strip">
            <p className="text-sm font-medium text-fg">No orders here yet</p>
            <p className="mt-1 text-xs text-muted">
              Post your item links; recorded orders land in this inbox.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <article
                key={order.id}
                className="rounded-token-lg border border-border bg-surface p-4 shadow-strip"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-semibold text-fg">{order.buyerName}</p>
                      <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[10px] font-semibold text-fg">
                        {STATUS_LABELS[order.status]}
                      </span>
                      {order.source === "self_report" && (
                        <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[10px] text-muted">
                          Book entry
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-muted">
                      {order.buyerPhone}
                      {order.buyerLocation !== null ? ` / ${order.buyerLocation}` : ""} /{" "}
                      {order.fulfillment === "pickup" ? "Pick up" : "Delivery"} /{" "}
                      {order.paymentMethod.toUpperCase()}
                      {order.note !== null ? ` / ${order.note}` : ""}
                    </p>
                  </div>
                  <p className="text-sm font-semibold text-fg">
                    KSh {order.totalKes.toLocaleString("en-KE")}
                  </p>
                </div>

                <div className="mt-3 space-y-1 border-t border-border pt-3">
                  {order.items.map((item) => (
                    <p key={item.id} className="text-xs text-muted">
                      <span className="font-medium text-fg">
                        {item.quantity} x {item.title}
                      </span>
                      {item.size !== null ? ` / ${item.size}` : ""}
                      {item.color !== null ? ` / ${item.color}` : ""}{" "}
                      <span className="tabular-nums">
                        KSh {(item.priceKes * item.quantity).toLocaleString("en-KE")}
                      </span>
                    </p>
                  ))}
                </div>

                {NEXT_ACTIONS.filter((a) => a.from.includes(order.status)).length > 0 && (
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {NEXT_ACTIONS.filter((a) => a.from.includes(order.status)).map((action) => (
                      <button
                        key={action.to}
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => void transition(order, action.to)}
                        className={
                          "rounded-token px-3 py-1.5 text-xs font-semibold transition disabled:opacity-50 " +
                          (action.accent
                            ? "bg-accent text-on-accent hover:bg-accent-hover"
                            : "border border-border bg-surface text-muted hover:text-danger")
                        }
                      >
                        {busyId === order.id ? (
                          <span className="inline-flex items-center gap-2">
                            <IconSpinner size={12} className="animate-spin" />
                            Working
                          </span>
                        ) : (
                          action.label
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                              Sale Recorder                                 */
/* -------------------------------------------------------------------------- */

const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted/70 focus:border-accent focus:outline-none";

export function SaleRecorderPage(): React.ReactElement {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [buyerName, setBuyerName] = useState("");
  const [buyerPhone, setBuyerPhone] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [usage, setUsage] = useState<UsageSummary | null>(null);
  const [listings, setListings] = useState<
    Array<{ id: string; title: string; stock: number; status: string }>
  >([]);
  const [listingId, setListingId] = useState("");

  useEffect(() => {
    void api
      .get<{ usage: UsageSummary }>("/seller/usage/summary")
      .then((data) => setUsage(data.usage))
      .catch(() => undefined);
    void api
      .get<{ items: Array<{ id: string; title: string; stock: number; status: string }> }>(
        "/seller/products?pageSize=48",
      )
      .then((data) => {
        setListings(data.items);
        setListingId(data.items[0]?.id ?? "");
      })
      .catch(() => undefined);
  }, [saved]);

  async function submit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.post("/seller/sales/self-report", {
        title: title.trim(),
        amountKes: Math.round(Number(amount)),
        quantity: Math.max(1, Number(quantity) || 1),
        buyerName: buyerName.trim() === "" ? null : buyerName.trim(),
        buyerPhone: buyerPhone.trim() === "" ? null : buyerPhone.trim(),
        listingId: listingId === "" ? null : listingId,
        note: note.trim() === "" ? null : note.trim(),
      });
      setSaved((n) => n + 1);
      setTitle("");
      setAmount("");
      setBuyerName("");
      setBuyerPhone("");
      setNote("");
      const data = await api.get<{ usage: UsageSummary }>("/seller/usage/summary");
      setUsage(data.usage);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not record the sale.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Sale recorder
            </span>
          </div>
          <Link
            to="/dashboard/orders"
            className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-medium text-fg"
          >
            Order inbox
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h1 className="text-sm font-semibold text-fg">Your book</h1>
          <p className="mt-1 text-xs text-muted">
            Sales you settled outside the storefront (WhatsApp groups, DMs). They count honestly
            toward your transparent ledger; corrections happen on invoices, never in this record.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-token bg-surface-alt px-4 py-3">
              <p className="text-[11px] font-medium text-muted">Recorded sales</p>
              <p className="mt-1 text-xl font-semibold tabular-nums text-fg">
                {usage?.units ?? 0}
              </p>
            </div>
            <div className="rounded-token bg-surface-alt px-4 py-3">
              <p className="text-[11px] font-medium text-muted">Recorded value</p>
              <p className="mt-1 text-xl font-semibold tabular-nums text-fg">
                KSh {(usage?.recordedKes ?? 0).toLocaleString("en-KE")}
              </p>
            </div>
          </div>
        </section>

        <form
          onSubmit={submit}
          className="space-y-4 rounded-token-lg border border-border bg-surface p-5 shadow-strip"
        >
          <h2 className="text-sm font-semibold text-fg">Record a sale</h2>
          <FormError message={error} />

          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold text-fg">What was sold</span>
            <input
              required
              minLength={1}
              maxLength={140}
              className={inputClass}
              placeholder="Two thrift denim jackets"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Unit price (KSh)</span>
              <input
                required
                type="number"
                min={1}
                className={inputClass}
                placeholder="1800"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Quantity</span>
              <input
                type="number"
                min={1}
                className={inputClass}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </label>
          </div>

          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold text-fg">
              Link to a listed item (optional, also decrements its stock)
            </span>
            <select className={inputClass} value={listingId} onChange={(e) => setListingId(e.target.value)}>
              <option value="">Not a listed item</option>
              {listings.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title} (stock {l.stock})
                </option>
              ))}
            </select>
          </label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Buyer (optional)</span>
              <input className={inputClass} placeholder="Wanjiku" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Buyer phone (optional)</span>
              <input className={inputClass} placeholder="0712 345 678" value={buyerPhone} onChange={(e) => setBuyerPhone(e.target.value)} />
            </label>
          </div>

          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold text-fg">Note</span>
            <textarea
              rows={2}
              maxLength={500}
              className={inputClass}
              placeholder="Settled by M-Pesa, picked up at stall."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </label>

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-token bg-accent py-3 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
          >
            {busy ? (
              <span className="inline-flex items-center justify-center gap-2">
                <IconSpinner size={15} className="animate-spin" />
                Recording
              </span>
            ) : (
              "Record sale"
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
