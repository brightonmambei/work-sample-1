import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { Link } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { FormError } from "../pages/CatalogPage.js";
import { IconCheck, IconImage, IconLink, IconShare, IconSpinner, IconTrash } from "../components/icons.js";

interface Category {
  id: string;
  slug: string;
  label: string;
}

interface UploadResult {
  uploadId: string;
  key: string;
  uploadUrl: string;
}

interface AttachedPhoto {
  uploadId: string;
  key: string;
  previewUrl: string;
}

interface CreatedListing {
  id: string;
  code: string;
}

const MAX_FILES = 12;
const MAX_BYTES = 12 * 1024 * 1024;
const ACCEPTED_MIMES = ["image/jpeg", "image/png", "image/webp", "image/avif", "image/heic"] as const;
type AcceptedMime = (typeof ACCEPTED_MIMES)[number];

export function NewItemPage(): React.ReactElement {
  const [categories, setCategories] = useState<Category[]>([]);
  const [photos, setPhotos] = useState<AttachedPhoto[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [compareAt, setCompareAt] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [condition, setCondition] = useState<"new" | "thrift">("new");
  const [grade, setGrade] = useState("4");
  const [stock, setStock] = useState("1");
  const [sizes, setSizes] = useState("");
  const [colors, setColors] = useState("");
  const [description, setDescription] = useState("");
  const [publishNow, setPublishNow] = useState(true);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<CreatedListing | null>(null);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState<string | null>(null);
  const [copied, setCopied] = useState<"link" | "caption" | null>(null);

  useEffect(() => {
    void api
      .get<{ categories: Category[] }>("/market/categories")
      .then((data) => {
        setCategories(data.categories);
        setCategoryId(data.categories[0]?.id ?? "");
      })
      .catch(() => undefined);
  }, []);

  const conditioned = condition === "thrift";
  const canSubmit = useMemo(
    () =>
      photos.length > 0 &&
      title.trim().length >= 2 &&
      Number(price) >= 1 &&
      categoryId !== "" &&
      !busy &&
      !uploading,
    [photos.length, title, price, categoryId, busy, uploading],
  );

  /* ------------------------- presigned upload flow ------------------------ */

  async function attachFiles(files: FileList | null): Promise<void> {
    if (files === null || files.length === 0) return;
    const room = MAX_FILES - photos.length - (uploading ? pendingCount.current : 0);
    if (room <= 0) {
      setUploadError(`Up to ${MAX_FILES} photos per item.`);
      return;
    }
    const selected = Array.from(files).slice(0, room);
    pendingCount.current += selected.length;
    setUploadError(null);
    setUploading(true);

    for (const file of selected) {
      const mime = (ACCEPTED_MIMES as readonly string[]).includes(file.type)
        ? (file.type as AcceptedMime)
        : "image/jpeg";
      try {
        if (file.size > MAX_BYTES) {
          throw new ApiClientError(413, "FILE_TOO_LARGE", file.name + " is over 12 MB.");
        }
        const presign = await api.post<UploadResult>("/seller/media/presign", {
          mime,
          sizeBytes: file.size,
        });
        const put = await fetch(presign.uploadUrl, {
          method: "PUT",
          body: file,
          headers: { "Content-Type": file.type },
        });
        if (!put.ok) throw new Error("upload rejected");
        await api.post("/seller/media/confirm", { key: presign.key });
        setPhotos((prev) => [
          ...prev,
          { uploadId: presign.uploadId, key: presign.key, previewUrl: URL.createObjectURL(file) },
        ]);
      } catch (err) {
        setUploadError(
          err instanceof ApiClientError
            ? err.message
            : `${file.name} could not be uploaded. Try again.`,
        );
      } finally {
        pendingCount.current -= 1;
        if (pendingCount.current === 0) setUploading(false);
      }
    }
  }

  const pendingCount = useRef(0);

  function onPick(e: ChangeEvent<HTMLInputElement>): void {
    void attachFiles(e.target.files);
    e.target.value = "";
  }

  async function onSubmit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const data = await api.post<{ listing: CreatedListing }>("/seller/products", {
        title: title.trim(),
        priceKes: Math.round(Number(price)),
        compareAtKes: compareAt === "" ? null : Math.round(Number(compareAt)),
        categoryId,
        condition,
        conditionGrade: conditioned ? Math.max(1, Math.min(5, Number(grade) || 4)) : null,
        stock: Math.max(0, Number(stock) || 0),
        description: description.trim() === "" ? null : description.trim(),
        sizes:
          sizes === ""
            ? []
            : sizes.split(",").map((s) => s.trim()).filter((s) => s !== ""),
        colors:
          colors === ""
            ? []
            : colors.split(",").map((c) => c.trim()).filter((c) => c !== ""),
        publishNow,
        media: photos.map((p, idx) => ({
          uploadId: p.uploadId,
          sortOrder: idx,
          isHero: idx === 0,
        })),
      });
      setCreated(data.listing);
      // Share-ready at upload: the link and the caption exist the moment the
      // item does. Both come from the API so every surface posts identical text.
      try {
        const share = await api.get<{ shareUrl: string; caption: string }>(
          `/seller/share/links/${data.listing.id}`,
        );
        setShareUrl(share.shareUrl);
        setCaption(share.caption);
      } catch {
        /* share link fetch is best-effort */
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not create the item.");
    } finally {
      setBusy(false);
    }
  }

  async function onCopy(what: "link" | "caption"): Promise<void> {
    if (created === null) return;
    const text = what === "link" ? (shareUrl ?? "") : (caption ?? "");
    if (text === "") return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(what);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* clipboard unavailable */
    }
  }

  function openWhatsApp(): void {
    if (created === null) return;
    const text = caption ?? shareUrl ?? "";
    if (text === "") return;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
  }

  const [posterUrl, setPosterUrl] = useState<string | null>(null);
  const [posterBusy, setPosterBusy] = useState(false);

  /** 9:16 status poster, rendered server-side from the hero photo. */
  async function onPoster(): Promise<void> {
    if (created === null) return;
    setPosterBusy(true);
    try {
      const data = await api.post<{ posterUrl: string }>("/seller/share/poster", {
        listingId: created.id,
      });
      setPosterUrl(data.posterUrl);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not render the poster.");
    } finally {
      setPosterBusy(false);
    }
  }

  /* ------------------------------- share done ------------------------------ */

  if (created !== null) {
    return (
      <div className="min-h-screen">
        <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
          <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
            <Link to="/dashboard/catalog" className="text-sm font-semibold text-fg">
              Back to catalog
            </Link>
          </div>
        </header>
        <main className="mx-auto max-w-3xl px-4 py-12">
          <div className="rounded-token-lg border border-border bg-surface p-8 text-center shadow-strip">
            <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-success/10 text-success">
              <IconCheck size={22} />
            </span>
            <p className="mt-4 text-lg font-semibold text-fg">
              {publishNow ? "Item is live" : "Draft saved"}
            </p>
            <p className="mt-1 text-xs text-muted">
              Ref {created.code}. Post the link in your WhatsApp groups;
              your storefront already lists the item.
            </p>
            {caption !== null && (
              <div className="mt-5 text-left">
                <label
                  htmlFor="share-caption"
                  className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted"
                >
                  Caption
                </label>
                <textarea
                  id="share-caption"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  rows={5}
                  className="mt-2 w-full rounded-token border border-border bg-surface-alt px-3 py-2 text-xs leading-relaxed text-fg outline-none focus:border-accent"
                />
                <p className="mt-1 text-[10px] text-muted">
                  Auto-written from the item, yours to edit. The link is included.
                </p>
              </div>
            )}
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => void onCopy("link")}
                disabled={shareUrl === null}
                className="flex items-center gap-2 rounded-token border border-border bg-surface px-4 py-2.5 text-xs font-medium text-fg disabled:opacity-50"
              >
                {copied === "link" ? <IconCheck size={14} className="text-success" /> : <IconLink size={14} />}
                {copied === "link" ? "Link copied" : "Copy share link"}
              </button>
              <button
                type="button"
                onClick={() => void onCopy("caption")}
                disabled={caption === null}
                className="flex items-center gap-2 rounded-token border border-border bg-surface px-4 py-2.5 text-xs font-medium text-fg disabled:opacity-50"
              >
                {copied === "caption" ? <IconCheck size={14} className="text-success" /> : <IconShare size={14} />}
                {copied === "caption" ? "Caption copied" : "Copy caption"}
              </button>
              <button
                type="button"
                onClick={openWhatsApp}
                disabled={caption === null && shareUrl === null}
                className="flex items-center gap-2 rounded-token bg-success px-4 py-2.5 text-xs font-semibold text-white disabled:opacity-50"
              >
                <IconShare size={14} />
                Post to WhatsApp
              </button>
              <button
                type="button"
                onClick={() => void onPoster()}
                disabled={posterBusy}
                className="flex items-center gap-2 rounded-token border border-border bg-surface px-4 py-2.5 text-xs font-medium text-fg disabled:opacity-50"
              >
                {posterBusy ? <IconSpinner size={14} /> : <IconImage size={14} />}
                {posterBusy
                  ? "Rendering"
                  : posterUrl !== null
                    ? "Regenerate status poster"
                    : "Create status poster"}
              </button>
            </div>
            {posterUrl !== null ? (
              <div className="mt-5 flex flex-col items-center gap-2">
                <a
                  href={posterUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-medium text-accent hover:text-accent-hover"
                >
                  Open status poster (9:16)
                </a>
                <p className="text-[11px] text-muted">
                  A fresh image each render, so WhatsApp re-scrapes the new one.
                </p>
              </div>
            ) : null}
            <div className="mt-6 flex items-center justify-center gap-3 text-xs">
              <button
                type="button"
                onClick={() => window.location.assign("/dashboard/catalog/new")}
                className="text-muted hover:text-fg"
              >
                Add another item
              </button>
              <Link to="/dashboard/catalog" className="font-medium text-fg">
                Go to catalog
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  /* ------------------------------- editor ---------------------------------- */

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link to="/dashboard/catalog" className="text-sm font-semibold text-fg">
            Back to catalog
          </Link>
          <span className="text-[11px] font-medium text-muted">New item</span>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-8">
        <form onSubmit={onSubmit} className="space-y-6">
          <FormError message={error ?? uploadError} />

          {/* Photos: the minimum path starts here */}
          <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <h2 className="text-sm font-semibold text-fg">Photos</h2>
            <p className="mt-0.5 text-xs text-muted">
              Up to {MAX_FILES} photos, 12 MB each. The first one becomes your cover.
            </p>

            <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4">
              {photos.map((p, idx) => (
                <div key={p.uploadId} className="relative aspect-square overflow-hidden rounded-token border border-border bg-skeleton">
                  <img src={p.previewUrl} alt={idx === 0 ? "Cover photo" : "Photo"} className="h-full w-full object-cover" />
                  {idx === 0 && (
                    <span className="absolute left-1.5 top-1.5 rounded-token bg-surface/95 px-1.5 py-0.5 text-[10px] font-semibold text-fg">
                      Cover
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => setPhotos((prev) => prev.filter((x) => x.uploadId !== p.uploadId))}
                    className="absolute right-1.5 top-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-surface/95 text-muted shadow-strip hover:text-danger"
                    aria-label="Remove photo"
                  >
                    <IconTrash size={13} />
                  </button>
                </div>
              ))}

              {photos.length < MAX_FILES && (
                <button
                  type="button"
                  onClick={() => document.getElementById("photo-input")?.click()}
                  className="flex aspect-square flex-col items-center justify-center gap-2 rounded-token border border-dashed border-border bg-surface-alt text-muted hover:border-accent/40 hover:text-fg"
                  disabled={uploading}
                >
                  {uploading ? (
                    <>
                      <IconSpinner size={18} className="animate-spin" />
                      <span className="text-[11px] font-medium">Uploading</span>
                    </>
                  ) : (
                    <>
                      <IconImage size={18} />
                      <span className="text-[11px] font-medium">Add photos</span>
                    </>
                  )}
                </button>
              )}
            </div>

            <input
              id="photo-input"
              type="file"
              accept={ACCEPTED_MIMES.join(",")}
              multiple
              onChange={onPick}
              className="hidden"
              aria-hidden
            />
          </section>

          {/* The essentials */}
          <section className="space-y-4 rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <ItemInput label="Title" hint="Short and clear, like the caption you would post.">
              <input
                required
                minLength={2}
                maxLength={140}
                className={inputClass}
                placeholder="Cropped denim jacket, thrift condition"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </ItemInput>

            <div className="grid gap-4 sm:grid-cols-2">
              <ItemInput label="Price (KSh)">
                <input
                  required
                  type="number"
                  min={1}
                  className={inputClass}
                  placeholder="1800"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </ItemInput>
              <ItemInput label="Was price (optional)">
                <input
                  type="number"
                  min={1}
                  className={inputClass}
                  placeholder="2400"
                  value={compareAt}
                  onChange={(e) => setCompareAt(e.target.value)}
                />
              </ItemInput>
            </div>

            <ItemInput label="Category">
              <select
                required
                className={inputClass}
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </ItemInput>

            <div className="grid gap-4 sm:grid-cols-3">
              <ItemInput label="Condition">
                <select
                  className={inputClass}
                  value={condition}
                  onChange={(e) => setCondition(e.target.value === "thrift" ? "thrift" : "new")}
                >
                  <option value="new">Brand new</option>
                  <option value="thrift">Thrift</option>
                </select>
              </ItemInput>
              {conditioned && (
                <ItemInput label="Grade (1 to 5)" hint="5 is nearly new.">
                  <select className={inputClass} value={grade} onChange={(e) => setGrade(e.target.value)}>
                    {[1, 2, 3, 4, 5].map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </ItemInput>
              )}
              <ItemInput label="Stock">
                <input
                  type="number"
                  min={0}
                  className={inputClass}
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                />
              </ItemInput>
            </div>
          </section>

          {/* Optional, defaults fine */}
          <section className="space-y-4 rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted">
              Optional details
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <ItemInput label="Sizes" hint="Comma separated, e.g. S, M, L">
                <input className={inputClass} placeholder="S, M, L" value={sizes} onChange={(e) => setSizes(e.target.value)} />
              </ItemInput>
              <ItemInput label="Colors" hint="Comma separated, e.g. Black, Indigo">
                <input className={inputClass} placeholder="Black, Indigo" value={colors} onChange={(e) => setColors(e.target.value)} />
              </ItemInput>
            </div>
            <ItemInput label="Description">
              <textarea
                rows={3}
                maxLength={2000}
                className={inputClass}
                placeholder="Fit, fabric, anything buyers ask about."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </ItemInput>
            <label className="flex items-center gap-2 text-xs font-medium text-fg">
              <input
                type="checkbox"
                checked={publishNow}
                onChange={(e) => setPublishNow(e.target.checked)}
                className="h-4 w-4 accent-[var(--st-accent)]"
              />
              Publish now (live on your storefront and shareable)
            </label>
          </section>

          <button
            type="submit"
            disabled={!canSubmit}
            className="w-full rounded-token bg-accent py-3 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
          >
            {busy ? (
              <span className="inline-flex items-center gap-2">
                <IconSpinner size={15} className="animate-spin" />
                Creating item
              </span>
            ) : publishNow ? (
              "Publish item"
            ) : (
              "Save draft"
            )}
          </button>
        </form>
      </main>
    </div>
  );
}

/* ------------------------------- shared bits ----------------------------- */

const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted/70 focus:border-accent focus:outline-none";

function ItemInput({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold text-fg">{label}</span>
      {children}
      {hint !== undefined && <span className="mt-1 block text-[11px] text-muted">{hint}</span>}
    </label>
  );
}
