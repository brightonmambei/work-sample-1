import { useEffect, useMemo, useState } from "react";
import {
  fallbackCategories,
  toStorefrontProducts,
  type StorefrontCategory,
  type StorefrontProduct,
} from "../lib/catalog.js";
import { demoStorefrontProducts, demoCategoryByCode, demoCategories } from "../data/demo.js";import { CategoryPills } from "../components/CategoryPills.js";
import { MasonryGrid } from "../components/MasonryGrid.js";
import { ProductCard } from "../components/ProductCard.js";
import { ProductModal } from "../components/ProductModal.js";
import {
  StorefrontHeader,
  storefrontAspectClasses as aspectClasses,
  useCurrentStore,
  useTenantTheme,
} from "../components/StorefrontChrome.js";
import { IconCheck } from "../components/icons.js";

export function StorefrontHome({ slug }: { slug?: string }): React.ReactElement {
  const [category, setCategory] = useState<string>("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const [categories, setCategories] = useState<StorefrontCategory[] | null>(null);
  const [products, setProducts] = useState<StorefrontProduct[] | null>(null);
  const [loading, setLoading] = useState(true);

  // A store addressed by slug (item redirects, seller profile links) must
  // resolve on any host; ?storeSlug=... is the public browsing override.
  const slugQuery = slug ? `?storeSlug=${encodeURIComponent(slug)}` : "";
  const store = useCurrentStore(slug);

  // Live catalog: taxonomy + active listings for the resolved tenant host.
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void Promise.all([
      fetch(`/api/v1/market/categories${slugQuery}`).then<StorefrontCategory[] | null>((r) =>
        r.ok ? r.json().then((b: { data?: { categories: StorefrontCategory[] } }) => b.data?.categories ?? null) : null,
      ),
      fetch(`/api/v1/market/products${category !== "all" ? `?category=${encodeURIComponent(category)}&` : "?"}${slug ? `storeSlug=${encodeURIComponent(slug)}` : ""}`).then<
        { items: unknown[] } | null
      >((r) => (r.ok ? r.json().then((b: { data?: { items: unknown[] } }) => b.data ?? null) : null)),
    ])
      .then(([cats, listings]) => {
        if (cancelled) return;
        if (cats !== null) {
          setCategories([{ id: "all", slug: "all", label: "All items" }, ...cats.filter((c) => c.slug !== "all")]);
        }
        if (listings !== null) {
          setProducts(toStorefrontProducts(listings.items));
        }
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [category, slugQuery, slug]);

  useTenantTheme(store?.store?.theme);

  const isTenant = store?.mode === "tenant" && store.store !== null;

  // Tenant = live data only (demo stays in platform mode as the showcase).
  const visible: StorefrontProduct[] = useMemo(() => {
    if (isTenant) return products ?? [];
    if (category === "all") return demoStorefrontProducts;
    return demoStorefrontProducts.filter(
      (p) => demoCategoryByCode[p.code] === category,
    );
  }, [isTenant, products, category]);

  const pills: StorefrontCategory[] = isTenant
    ? categories ?? fallbackCategories
    : demoCategories.map((c) => ({ id: c.id, slug: c.id, label: c.label }));

  const openProduct: StorefrontProduct | null = useMemo(() => {
    const byId = visible.find((p) => p.id === openId);
    if (byId !== undefined) return byId;
    return null;
  }, [visible, openId]);

  return (
    <div className="min-h-screen">
      <StorefrontHeader
        mode={store?.mode ?? "platform"}
        store={store}
        homeHref={slug ? `/s/${slug}` : "/"}
      />

      <main className="mx-auto max-w-6xl px-4 py-6">
        {store?.previewingDraft === true && (
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-token border border-warning/30 bg-warning/10 px-4 py-3">
            <p className="text-xs font-medium text-warning">
              Draft preview. Shoppers still see your published theme.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="/dashboard/theme"
                className="rounded-token border border-warning/40 px-3 py-1.5 text-[11px] font-semibold text-warning hover:bg-warning/10"
              >
                Back to the editor
              </a>
              <a
                href={slug ? `/s/${slug}` : "/"}
                className="text-[11px] font-semibold text-muted hover:text-fg"
              >
                View published
              </a>
            </div>
          </div>
        )}
        {slug !== undefined && !loading && store?.store === null ? (
          // A slug-addressed storefront that does not exist: never show the
          // platform demo here, it would look broken, not branded.
          <section className="py-24 text-center">
            <h1 className="font-display text-3xl font-semibold text-fg">
              This storefront is not here
            </h1>
            <p className="mt-3 text-sm text-muted">
              The address may be mistyped, or the store may have moved.
            </p>
          </section>
        ) : (
          <>
            {store?.mode === "tenant" && (
          <section className="mb-8 border-b border-border pb-8 pt-6 text-center">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
              New arrivals · Updated weekly
            </p>
            <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-fg sm:text-5xl">
              {store.store?.name}
            </h1>
            {store.store?.tagline ? (
              <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-muted italic">
                {store.store.tagline}
              </p>
            ) : null}
            <div className="mx-auto mt-5 flex h-px w-16 bg-accent/60" aria-hidden="true" />
            <p className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs text-muted">
              <span className="inline-flex items-center gap-1.5">
                <IconCheck size={13} className="text-success" />
                Live catalog
              </span>
              <span aria-hidden="true">·</span>
              <span>Tap any item to see sizes, stock, and ordering</span>
            </p>
          </section>
        )}

        {store?.mode === "platform" && (
          <section className="mb-8 border-b border-border pb-8 pt-6 text-center">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
              StoreSnap · Demo storefront
            </p>
            <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-fg sm:text-5xl">
              Media-first storefronts, built elegant
            </h1>
            <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-muted italic">
              Masonry browsing, tokenized themes, and one-tap ordering. Demo
              catalog below; every seller storefront renders live listings.
            </p>
            <div className="mx-auto mt-5 flex h-px w-16 bg-accent/60" aria-hidden="true" />
          </section>
        )}

        {slug !== undefined && !loading && store?.store === null ? null : (
          <CategoryPills pills={pills} active={category} onSelect={setCategory} />
        )}

        {slug !== undefined && !loading && store?.store === null ? null : isTenant && loading && products === null ? (
          <MasonryGrid>
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className={`masonry-item animate-pulse rounded-token-lg bg-skeleton ${aspectClasses[i % aspectClasses.length]!}`}
              />
            ))}
          </MasonryGrid>
        ) : visible.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted">
            {isTenant ? "No items live yet. Check back soon." : "No items in this category yet."}
          </p>
        ) : (
          <MasonryGrid>
            {visible.map((product, i) => (
              <ProductCard
                key={product.id}
                product={product}
                aspectClass={aspectClasses[i % aspectClasses.length]!}
                onOpen={setOpenId}
              />
            ))}
          </MasonryGrid>
        )}
          </>
        )}
      </main>

      <footer className="mx-auto max-w-6xl px-4 py-8">
        <div className="border-t border-border pt-6 text-center sm:flex sm:items-center sm:justify-between sm:text-left">
          <p className="font-display text-base font-semibold tracking-wide text-fg">
            {isTenant ? (store?.store?.name ?? "StoreSnap") : "StoreSnap"}
          </p>
          <p className="mt-2 text-[11px] text-muted sm:mt-0">
            {isTenant
              ? "Order in one tap. The message goes straight to the seller."
              : "Media-first storefronts for Kenyan sellers. Powered by StoreSnap."}
          </p>
        </div>
      </footer>

      <ProductModal
        product={openProduct}
        onClose={() => setOpenId(null)}
        storeSlug={slug ?? store?.store?.slug ?? null}
      />
    </div>
  );
}
