/**
 * Drop page (AGENTS.md section 8): where a collection link lands. One curated
 * set of items rendered as the same masonry the storefront uses, so a group
 * chat post opens into a browsable mini-feed instead of a list of links.
 * Ended drops keep working (invariant 5): they say so, then point home.
 */
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toStorefrontProducts, type StorefrontProduct } from "../lib/catalog.js";
import {
  StorefrontHeader,
  storefrontAspectClasses as aspectClasses,
  useCurrentStore,
  useTenantTheme,
} from "../components/StorefrontChrome.js";
import { MasonryGrid } from "../components/MasonryGrid.js";
import { ProductCard } from "../components/ProductCard.js";
import { ProductModal } from "../components/ProductModal.js";
import { IconChevronRight, IconLayers } from "../components/icons.js";

interface DropStore {
  slug: string;
  name: string;
  locationLabel: string | null;
}

interface DropCollection {
  code: string;
  title: string;
  description: string | null;
  status: "active" | "archived";
  itemCount: number;
  minPriceKes: number;
  maxPriceKes: number;
  items: unknown[];
}

interface DropResolution {
  state: "live" | "ended";
  store: DropStore | null;
  collection: DropCollection | null;
}

export function CollectionPage(): React.ReactElement {
  const { slug, code = "" } = useParams();
  const [resolution, setResolution] = useState<DropResolution | null>(null);
  const [failed, setFailed] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const store = useCurrentStore(slug);
  useTenantTheme(store?.store?.theme);

  useEffect(() => {
    let cancelled = false;
    setResolution(null);
    setFailed(false);
    const r = new URLSearchParams(window.location.search).get("r");
    void fetch(`/api/v1/market/collections/${encodeURIComponent(code)}${r ? `?r=${encodeURIComponent(r)}` : ""}`)
      .then((res) =>
        res.ok ? res.json().then((b: { data?: DropResolution }) => b.data ?? null) : null,
      )
      .then((data) => {
        if (cancelled) return;
        if (data === null) setFailed(true);
        else setResolution(data);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [code]);

  const collection = resolution?.collection ?? null;
  const products = useMemo<StorefrontProduct[]>(
    () => (collection === null ? [] : toStorefrontProducts(collection.items)),
    [collection],
  );
  const openProduct = useMemo(
    () => products.find((p) => p.id === openId) ?? null,
    [products, openId],
  );

  const storeSlug = resolution?.store?.slug ?? slug ?? null;
  const storeName = resolution?.store?.name ?? store?.store?.name ?? "StoreSnap";

  if (failed) {
    return (
      <QuietState
        title="This drop is not here"
        line="The link may be mistyped, or the seller has taken it down."
        action={slug !== undefined ? { label: "Browse the store", href: `/s/${slug}` } : null}
      />
    );
  }

  return (
    <div className="min-h-screen">
      <StorefrontHeader
        mode={resolution === null && store === null ? "platform" : "tenant"}
        store={store}
        homeHref={storeSlug !== null ? `/s/${storeSlug}` : "/"}
      />

      <main className="mx-auto max-w-6xl px-4 pb-16 pt-6">
        <nav className="flex items-center gap-1.5 pb-5 text-xs text-muted">
          <Link to={storeSlug !== null ? `/s/${storeSlug}` : "/"} className="hover:text-fg">
            {storeName}
          </Link>
          <IconChevronRight size={13} />
          <span className="text-fg">Drop</span>
        </nav>

        {collection === null ? (
          <div className="space-y-4">
            <div className="h-10 w-2/3 animate-pulse rounded-token bg-skeleton" />
            <div className="h-4 w-1/3 animate-pulse rounded-token bg-skeleton" />
            <MasonryGrid>
              {Array.from({ length: 3 }).map((_, i) => (
                <div
                  key={i}
                  className={`masonry-item animate-pulse rounded-token-lg bg-skeleton ${
                    aspectClasses[i % aspectClasses.length]!
                  }`}
                />
              ))}
            </MasonryGrid>
          </div>
        ) : (
          <>
            <section className="border-b border-border pb-7">
              <p className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-accent">
                <IconLayers size={13} />
                {resolution?.state === "ended" ? "Drop ended" : "Drop"}
              </p>
              <h1 className="mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight text-fg sm:text-5xl">
                {collection.title}
              </h1>
              {collection.description !== null && collection.description !== "" ? (
                <p className="mt-3 max-w-2xl whitespace-pre-line text-sm leading-relaxed text-muted">
                  {collection.description}
                </p>
              ) : null}
              <p className="mt-4 text-xs text-muted">
                {collection.itemCount === 1 ? "1 item" : `${collection.itemCount} items`}
                {collection.itemCount > 0 ? (
                  <>
                    <span aria-hidden="true"> · </span>
                    {priceRange(collection.minPriceKes, collection.maxPriceKes)}
                  </>
                ) : null}
                {resolution?.store?.locationLabel ? (
                  <>
                    <span aria-hidden="true"> · </span>
                    {resolution.store.locationLabel}
                  </>
                ) : null}
              </p>
              {resolution?.state === "ended" ? (
                <p className="mt-4 rounded-token border border-border bg-surface px-4 py-3 text-xs leading-relaxed text-muted">
                  This drop is closed. The items below may still be in the store.
                  <Link
                    to={storeSlug !== null ? `/s/${storeSlug}` : "/"}
                    className="ml-1.5 font-semibold text-accent hover:underline"
                  >
                    See what is left
                  </Link>
                </p>
              ) : null}
            </section>

            {products.length === 0 ? (
              <p className="py-16 text-center text-sm text-muted">
                Restocking. Check the store for new arrivals.
              </p>
            ) : (
              <div className="pt-6">
                <MasonryGrid>
                  {products.map((product, i) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      aspectClass={aspectClasses[i % aspectClasses.length]!}
                      onOpen={setOpenId}
                    />
                  ))}
                </MasonryGrid>
              </div>
            )}
          </>
        )}
      </main>

      <ProductModal
        product={openProduct}
        onClose={() => setOpenId(null)}
        storeSlug={storeSlug}
      />
    </div>
  );
}

function priceRange(min: number, max: number): string {
  const low = `KSh ${min.toLocaleString("en-KE")}`;
  if (min === max) return low;
  return `${low} - ${max.toLocaleString("en-KE")}`;
}

function QuietState({
  title,
  line,
  action,
}: {
  title: string;
  line: string;
  action: { label: string; href: string } | null;
}): React.ReactElement {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md rounded-token-lg border border-border bg-surface p-10 text-center shadow-strip">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-surface-alt">
          <IconLayers size={20} className="text-muted" />
        </div>
        <h1 className="mt-5 font-display text-3xl font-semibold text-fg">{title}</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">{line}</p>
        {action !== null && (
          <Link
            to={action.href}
            className="mt-6 inline-flex items-center gap-1.5 rounded-token bg-accent px-5 py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover"
          >
            {action.label}
            <IconChevronRight size={15} />
          </Link>
        )}
      </div>
    </main>
  );
}
