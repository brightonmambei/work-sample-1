import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { useAuthStore } from "../lib/auth.js";
import { IconCheck, IconLayers, IconLink, IconMessage, IconRefresh, IconTrash } from "../components/icons.js";

/* ------------------------------- types ---------------------------------- */

export interface SellerMedia {
  id: string;
  thumbUrl: string | null;
  cardUrl: string | null;
  fullUrl: string | null;
}

export interface SellerListing {
  id: string;
  code: string;
  title: string;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  status: "draft" | "active" | "paused" | "sold_out" | "archived";
  description: string | null;
  createdAt: string;
  media: SellerMedia[];
}

interface ListingsResponse {
  items: SellerListing[];
  total: number;
}

const STATUS_LABELS: Record<SellerListing["status"], string> = {
  draft: "Draft",
  active: "Live",
  paused: "Paused",
  sold_out: "Sold out",
  archived: "Archived",
};

/* ------------------------------ page shell ------------------------------ */

export function CatalogPage(): React.ReactElement {
  const signOut = useAuthStore((s) => s.signOut);
  const navigate = useNavigate();

  const [listings, setListings] = useState<ListingsResponse | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  // Multi-select feeds the drop builder: tick items in the grid, create one
  // post for all of them.
  const [selected, setSelected] = useState<Set<string>>(new Set());

  function toggleSelected(id: string): void {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const load = useCallback((status: string) => {
    setLoading(true);
    void api
      .get<ListingsResponse>(
        `/seller/products${status !== "" ? `?status=${encodeURIComponent(status)}` : ""}`,
      )
      .then((data) => setListings(data))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load your catalog."),
      )
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load(statusFilter);
  }, [statusFilter, load]);

  async function onSignOut(): Promise<void> {
    await signOut();
    navigate("/", { replace: true });
  }

  async function onArchive(listing: SellerListing): Promise<void> {
    try {
      await api.patch(`/seller/products/${listing.id}`, { archive: true });
      load(statusFilter);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not archive that item.");
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Catalog
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Link to="/dashboard/collections" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Drops
            </Link>
            <Link to="/dashboard/media" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Media
            </Link>
            <Link to="/dashboard/orders" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Orders
            </Link>
            <Link to="/dashboard/sales" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Sales
            </Link>
            <Link to="/dashboard/billing" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Billing
            </Link>
            <Link to="/dashboard" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Store settings
            </Link>
            <button
              type="button"
              onClick={onSignOut}
              className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg hover:border-fg/20"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-semibold text-fg">Your catalog</h1>
            <p className="mt-1 text-sm text-muted">
              {listings
                ? `${listings.total} item${listings.total === 1 ? "" : "s"}. Live items count toward your plan quota.`
                : "Loading your items."}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by status"
              className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg"
            >
              <option value="">All statuses</option>
              {Object.entries(STATUS_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
            <Link
              to="/dashboard/catalog/new"
              className="rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover"
            >
              Add item
            </Link>
            <Link
              to="/dashboard"
              className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg"
            >
              Store settings
            </Link>
          </div>
        </div>

        <FormError message={error} />

        {loading && listings === null ? (
          <p className="py-20 text-center text-sm text-muted">Loading...</p>
        ) : listings !== null && listings.items.length === 0 ? (
          <div className="rounded-token-lg border border-border bg-surface p-10 text-center shadow-strip">
            <p className="text-sm font-medium text-fg">No items yet</p>
            <p className="mt-1 text-xs text-muted">
              Photos plus price and condition is all you need to list in seconds.
            </p>
            <Link
              to="/dashboard/catalog/new"
              className="mt-4 inline-block rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent"
            >
              Add your first item
            </Link>
          </div>
        ) : (
          listings && (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {listings.items.map((item) => (
                <CatalogCard
                  key={item.id}
                  item={item}
                  onArchive={onArchive}
                  selected={selected.has(item.id)}
                  onToggle={toggleSelected}
                />
              ))}
            </div>
          )
        )}
      </main>

      {selected.size > 0 && (
        <div className="sticky bottom-0 z-20 border-t border-border bg-surface/95 backdrop-blur">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
            <p className="text-xs font-medium text-fg">
              {selected.size} item{selected.size === 1 ? "" : "s"} selected
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSelected(new Set())}
                className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-muted hover:text-fg"
              >
                Clear
              </button>
              <Link
                to={`/dashboard/collections?items=${Array.from(selected).join(",")}`}
                className="inline-flex items-center gap-1.5 rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover"
              >
                <IconLayers size={13} />
                Create drop
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------- grid card ------------------------------ */

interface ShareLinks {
  shareUrl: string;
  caption: string;
}

/**
 * Share link and caption per listing. The cache key covers every field the
 * caption is built from, so an inline price or stock edit invalidates the
 * entry, and the entry survives a remount: the card paints its share actions
 * from cache instead of firing the request again (React StrictMode mounts
 * twice in development, and a slow first paint used to swallow the response).
 */
const shareCache = new Map<string, ShareLinks>();

function shareCacheKey(item: SellerListing): string {
  return [
    item.id,
    item.title,
    item.priceKes,
    item.compareAtKes ?? "",
    item.condition,
    item.conditionGrade ?? "",
    item.stock,
  ].join(":");
}

function CatalogCard({
  item,
  onArchive,
  selected,
  onToggle,
}: {
  item: SellerListing;
  onArchive: (item: SellerListing) => Promise<void>;
  selected: boolean;
  onToggle: (id: string) => void;
}): React.ReactElement {
  const shareKey = shareCacheKey(item);
  const [share, setShare] = useState<ShareLinks | null>(
    () => shareCache.get(shareKey) ?? null,
  );
  const [copied, setCopied] = useState<"link" | "caption" | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const cover = item.media[0]?.cardUrl ?? item.media[0]?.thumbUrl ?? null;
  const discounted =
    item.compareAtKes !== null && item.compareAtKes > item.priceKes;
  const selectable = item.status === "active";

  useEffect(() => {
    if (item.status !== "active") return;
    const cached = shareCache.get(shareKey);
    if (cached) {
      setShare(cached);
      return;
    }
    void api
      .get<ShareLinks>(`/seller/share/links/${item.id}`)
      .then((data) => {
        shareCache.set(shareKey, data);
        setShare(data);
      })
      .catch(() => undefined);
  }, [shareKey, item.status, item.id]);

  async function copy(text: string | null | undefined, what: "link" | "caption"): Promise<void> {
    if (text === null || text === undefined || text === "") return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(what);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* clipboard unavailable */
    }
  }

  const onCopyLink = () => copy(share?.shareUrl, "link");
  const onCopyCaption = () => copy(share?.caption, "caption");

  /**
   * WhatsApp caches unfurls hard: bumping the version suffix makes the next
   * scrape pick up new photos or copy.
   */
  async function onRefresh(): Promise<void> {
    setRefreshing(true);
    try {
      await api.post("/seller/share/refresh", { listingId: item.id });
    } catch {
      /* best-effort: the seller can press it again */
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <article className="overflow-hidden rounded-token-lg border border-border bg-surface shadow-strip">
      <div className="relative aspect-[3/4] bg-skeleton">
        {cover !== null ? (
          <img src={cover} alt={item.title} loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <span className="text-[11px] uppercase tracking-wider text-muted">No photo</span>
          </div>
        )}
        <span className="absolute left-2 top-2 rounded-token bg-surface/95 px-2 py-0.5 text-[10px] font-semibold text-fg shadow-strip">
          {STATUS_LABELS[item.status]}
        </span>
        {selectable && (
          <button
            type="button"
            onClick={() => onToggle(item.id)}
            aria-pressed={selected}
            aria-label={selected ? `Deselect ${item.title}` : `Select ${item.title} for a drop`}
            className={
              "absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full border shadow-strip " +
              (selected
                ? "border-accent bg-accent text-on-accent"
                : "border-border bg-surface/95 text-muted hover:text-fg")
            }
          >
            {selected ? <IconCheck size={13} /> : null}
          </button>
        )}
      </div>

      <div className="space-y-2 p-3">
        <p className="line-clamp-1 text-sm font-medium text-fg">{item.title}</p>
        <div className="flex items-baseline justify-between">
          <span className="text-sm font-semibold text-fg">
            KSh {item.priceKes.toLocaleString("en-KE")}
          </span>
          {discounted && (
            <span className="text-[11px] text-muted line-through">
              KSh {item.compareAtKes!.toLocaleString("en-KE")}
            </span>
          )}
        </div>
        <p className="text-[11px] text-muted">
          {item.condition === "thrift" ? "Thrift" : "New"} / Stock {item.stock}
        </p>

        {item.status === "active" && share !== null && (
          <div className="space-y-1.5">
            <button
              type="button"
              onClick={() => void onCopyLink()}
              className="flex w-full items-center justify-center gap-1.5 rounded-token border border-border bg-surface px-2 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40"
            >
              {copied === "link" ? (
                <IconCheck size={12} className="text-success" />
              ) : (
                <IconLink size={12} />
              )}
              {copied === "link" ? "Link copied" : "Copy share link"}
            </button>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => void onCopyCaption()}
                disabled={share === null}
                className="flex items-center justify-center gap-1.5 rounded-token border border-border bg-surface px-2 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40 disabled:opacity-50"
              >
                {copied === "caption" ? (
                  <IconCheck size={12} className="text-success" />
                ) : (
                  <IconMessage size={12} />
                )}
                {copied === "caption" ? "Caption copied" : "Copy caption"}
              </button>
              <button
                type="button"
                onClick={() => void onRefresh()}
                disabled={refreshing}
                className="flex items-center justify-center gap-1.5 rounded-token border border-border bg-surface px-2 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40 disabled:opacity-50"
              >
                <IconRefresh size={12} />
                {refreshing ? "Refreshing" : "Refresh preview"}
              </button>
            </div>
          </div>
        )}

        {item.status !== "archived" && (
          <button
            type="button"
            onClick={() => void onArchive(item)}
            className="flex w-full items-center justify-center gap-1.5 rounded-token px-2 py-1.5 text-[11px] font-medium text-muted hover:text-danger"
          >
            <IconTrash size={12} />
            Archive
          </button>
        )}
      </div>
    </article>
  );
}

/* --------------------------- shared error ------------------------------- */

export function FormError({ message }: { message: string | null }): React.ReactElement | null {
  if (message === null) return null;
  return (
    <p
      role="alert"
      className="mb-4 rounded-token border border-danger/40 bg-danger/10 px-4 py-3 text-xs font-medium text-danger"
    >
      {message}
    </p>
  );
}
