/**
 * Seller drops (AGENTS.md section 8): build a curated set from the catalog,
 * get one canonical link plus its caption, and re-share it later. The catalog
 * grid multi-select lands here with items preselected, so the seller types a
 * title and posts; nothing else is required.
 */
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { useAuthStore } from "../lib/auth.js";
import type { SellerListing } from "./CatalogPage.js";
import { FormError } from "./CatalogPage.js";
import {
  IconCheck,
  IconCopy,
  IconLayers,
  IconLink,
  IconMessage,
  IconRefresh,
  IconTrash,
} from "../components/icons.js";

interface Drop {
  id: string;
  code: string;
  title: string;
  description: string | null;
  status: "active" | "archived";
  itemCount: number;
  listingIds: string[];
  minPriceKes: number;
  maxPriceKes: number;
  shareUrl: string;
  caption: string;
  cardUrl: string | null;
  createdAt: string;
  updatedAt: string;
}

interface DropsResponse {
  collections: Drop[];
}

interface ListingsResponse {
  items: SellerListing[];
  total: number;
}

function priceRange(min: number, max: number): string {
  const low = `KSh ${min.toLocaleString("en-KE")}`;
  return min === max ? low : `${low} - ${max.toLocaleString("en-KE")}`;
}

export function CollectionsPage(): React.ReactElement {
  const signOut = useAuthStore((s) => s.signOut);
  const navigate = useNavigate();
  const [params] = useSearchParams();

  const [drops, setDrops] = useState<Drop[] | null>(null);
  const [listings, setListings] = useState<SellerListing[] | null>(null);
  const [picked, setPicked] = useState<Set<string>>(
    () => new Set((params.get("items") ?? "").split(",").filter((id) => id !== "")),
  );
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const loadDrops = useCallback(() => {
    void api
      .get<DropsResponse>("/seller/collections")
      .then((data) => setDrops(data.collections))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load your drops."),
      );
  }, []);

  useEffect(() => {
    loadDrops();
    void api
      .get<ListingsResponse>("/seller/products?status=active&pageSize=48")
      .then((data) => setListings(data.items))
      .catch(() => setListings([]));
  }, [loadDrops]);

  const pickedItems = useMemo(
    () => (listings ?? []).filter((l) => picked.has(l.id)),
    [listings, picked],
  );

  function toggle(id: string): void {
    setPicked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function onCreate(): Promise<void> {
    if (title.trim().length < 2) {
      setError("Give the drop a short title first.");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await api.post<{ collection: Drop }>("/seller/collections", {
        title: title.trim(),
        description: description.trim() === "" ? null : description.trim(),
        listingIds: pickedItems.map((l) => l.id),
      });
      setTitle("");
      setDescription("");
      setPicked(new Set());
      loadDrops();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not create the drop.");
    } finally {
      setSaving(false);
    }
  }

  async function copy(text: string, key: string): Promise<void> {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* clipboard unavailable */
    }
  }

  async function onRefresh(drop: Drop): Promise<void> {
    setBusyId(drop.id);
    try {
      await api.post(`/seller/collections/${drop.id}/refresh`);
      loadDrops();
    } catch {
      /* best-effort: the seller can press it again */
    } finally {
      setBusyId(null);
    }
  }

  async function onArchive(drop: Drop): Promise<void> {
    setBusyId(drop.id);
    try {
      await api.del(`/seller/collections/${drop.id}`);
      loadDrops();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not end that drop.");
    } finally {
      setBusyId(null);
    }
  }

  async function onSignOut(): Promise<void> {
    await signOut();
    navigate("/", { replace: true });
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Drops
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Link to="/dashboard/catalog" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Catalog
            </Link>
            <Link to="/dashboard/media" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Media
            </Link>
            <Link to="/dashboard/orders" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Orders
            </Link>
            <button
              type="button"
              onClick={onSignOut}
              className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg hover:border-fg/20"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6">
          <h1 className="text-lg font-semibold text-fg">Drops</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted">
            One link for many items. Pick what belongs together, post the link once,
            and buyers browse the whole set.
          </p>
        </div>

        <FormError message={error} />

        {/* ------------------------------ builder ------------------------------ */}
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-fg">
            <IconLayers size={15} className="text-accent" />
            New drop
          </h2>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted">
                Title
              </span>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Friday drop: new arrivals"
                maxLength={140}
                className="mt-1.5 w-full rounded-token border border-border bg-surface px-3 py-2 text-sm text-fg"
              />
            </label>
            <label className="block">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted">
                Note (optional)
              </span>
              <input
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Sizes 6 to 12, pickup in Kilimani"
                maxLength={600}
                className="mt-1.5 w-full rounded-token border border-border bg-surface px-3 py-2 text-sm text-fg"
              />
            </label>
          </div>

          <div className="mt-5">
            <div className="flex items-baseline justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-muted">
                Items
              </span>
              <span className="text-[11px] text-muted">
                {picked.size} selected
                {pickedItems.length > 0 &&
                  ` · ${priceRange(
                    Math.min(...pickedItems.map((i) => i.priceKes)),
                    Math.max(...pickedItems.map((i) => i.priceKes)),
                  )}`}
              </span>
            </div>

            {listings === null ? (
              <p className="py-8 text-center text-xs text-muted">Loading your live items.</p>
            ) : listings.length === 0 ? (
              <p className="py-8 text-center text-xs text-muted">
                No live items yet.{" "}
                <Link to="/dashboard/catalog/new" className="font-semibold text-accent">
                  Add one first
                </Link>
                .
              </p>
            ) : (
              <div className="mt-2 grid max-h-80 grid-cols-3 gap-2 overflow-y-auto sm:grid-cols-5 lg:grid-cols-6">
                {listings.map((item) => {
                  const active = picked.has(item.id);
                  const cover = item.media[0]?.thumbUrl ?? item.media[0]?.cardUrl ?? null;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => toggle(item.id)}
                      aria-pressed={active}
                      className={
                        "group relative overflow-hidden rounded-token border text-left " +
                        (active ? "border-accent ring-1 ring-accent/30" : "border-border")
                      }
                    >
                      <span className="block aspect-[3/4] bg-skeleton">
                        {cover !== null ? (
                          <img src={cover} alt="" loading="lazy" className="h-full w-full object-cover" />
                        ) : null}
                      </span>
                      <span className="absolute inset-x-0 bottom-0 bg-surface/90 px-1.5 py-1 text-[10px] font-medium text-fg">
                        <span className="block truncate">{item.title}</span>
                      </span>
                      {active && (
                        <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-accent text-on-accent">
                          <IconCheck size={12} />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-5 flex items-center justify-end gap-2">
            {picked.size > 0 && (
              <button
                type="button"
                onClick={() => setPicked(new Set())}
                className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-muted hover:text-fg"
              >
                Clear
              </button>
            )}
            <button
              type="button"
              onClick={() => void onCreate()}
              disabled={saving || title.trim().length < 2}
              className="rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-50"
            >
              {saving ? "Creating" : "Create drop"}
            </button>
          </div>
        </section>

        {/* ------------------------------- list ------------------------------- */}
        <section className="mt-10">
          <h2 className="text-sm font-semibold text-fg">Your drops</h2>
          {drops === null ? (
            <p className="py-8 text-center text-xs text-muted">Loading...</p>
          ) : drops.length === 0 ? (
            <p className="py-8 text-center text-xs text-muted">
              Nothing yet. Pick a few items above and post the link in a group.
            </p>
          ) : (
            <div className="mt-3 space-y-3">
              {drops.map((drop) => (
                <article
                  key={drop.id}
                  className="flex flex-col gap-4 rounded-token-lg border border-border bg-surface p-4 shadow-strip sm:flex-row sm:items-center"
                >
                  <div className="h-20 w-32 shrink-0 overflow-hidden rounded-token bg-skeleton">
                    {drop.cardUrl !== null ? (
                      <img src={drop.cardUrl} alt="" loading="lazy" className="h-full w-full object-cover" />
                    ) : null}
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-fg">{drop.title}</p>
                    <p className="mt-0.5 text-[11px] text-muted">
                      {drop.itemCount === 1 ? "1 item" : `${drop.itemCount} items`}
                      {drop.itemCount > 0 && ` · ${priceRange(drop.minPriceKes, drop.maxPriceKes)}`}
                      {` · /p/${drop.code}`}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => void copy(drop.shareUrl, `${drop.id}:link`)}
                      className="flex items-center gap-1.5 rounded-token border border-border bg-surface px-2.5 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40"
                    >
                      {copied === `${drop.id}:link` ? (
                        <IconCheck size={12} className="text-success" />
                      ) : (
                        <IconLink size={12} />
                      )}
                      Copy link
                    </button>
                    <button
                      type="button"
                      onClick={() => void copy(drop.caption, `${drop.id}:caption`)}
                      className="flex items-center gap-1.5 rounded-token border border-border bg-surface px-2.5 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40"
                    >
                      {copied === `${drop.id}:caption` ? (
                        <IconCheck size={12} className="text-success" />
                      ) : (
                        <IconMessage size={12} />
                      )}
                      Copy caption
                    </button>
                    <button
                      type="button"
                      onClick={() => void onRefresh(drop)}
                      disabled={busyId === drop.id}
                      className="flex items-center gap-1.5 rounded-token border border-border bg-surface px-2.5 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40 disabled:opacity-50"
                    >
                      <IconRefresh size={12} />
                      Refresh
                    </button>
                    <a
                      href={drop.shareUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 rounded-token border border-border bg-surface px-2.5 py-1.5 text-[11px] font-medium text-fg hover:border-accent/40"
                    >
                      <IconCopy size={12} />
                      Open
                    </a>
                    <button
                      type="button"
                      onClick={() => void onArchive(drop)}
                      disabled={busyId === drop.id}
                      className="flex items-center gap-1.5 rounded-token px-2.5 py-1.5 text-[11px] font-medium text-muted hover:text-danger disabled:opacity-50"
                    >
                      <IconTrash size={12} />
                      End drop
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
