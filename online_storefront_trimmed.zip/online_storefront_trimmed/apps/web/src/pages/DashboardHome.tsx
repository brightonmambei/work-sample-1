import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { useAuthStore } from "../lib/auth.js";
import { Field, FormError, inputClass } from "../pages/AuthPages.js";
import { IconCheck } from "../components/icons.js";

interface StorePayload {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  logoUrl: string | null;
  coverUrl: string | null;
  whatsappNumber: string | null;
  locationLabel: string | null;
  plan: string;
  status: string;
  theme: { schemaVersion: number; preset: "pro-light" | "pro-dark"; overrides: Record<string, never> };
}

interface StoreResponse {
  store: StorePayload | null;
}

export function DashboardHome(): React.ReactElement {
  const user = useAuthStore((s) => s.user);
  const signOut = useAuthStore((s) => s.signOut);
  const [store, setStore] = useState<StorePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    void api
      .get<StoreResponse>("/seller/store")
      .then((data) => {
        if (!cancelled) setStore(data.store);
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function onSignOut(): Promise<void> {
    await signOut();
    navigate("/", { replace: true });
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Seller dashboard
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="text-muted">{user?.email}</span>
            <button
              type="button"
              onClick={onSignOut}
              className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg hover:border-fg/20"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8">
        {loading ? (
          <p className="py-20 text-center text-sm text-muted">Loading your store...</p>
        ) : store === null ? (
          <StoreSetup onCreated={(s) => setStore(s)} />
        ) : (
          <StoreSettings store={store} onUpdated={(s) => setStore(s)} />
        )}
      </main>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

const RESERVED_HINT =
  "3 to 32 characters, lowercase letters, numbers and hyphens. This becomes your storefront address.";

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32);
}

function StoreSetup({ onCreated }: { onCreated: (store: StorePayload) => void }): React.ReactElement {
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [slugEdited, setSlugEdited] = useState(false);
  const [tagline, setTagline] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [location, setLocation] = useState("");
  const [preset, setPreset] = useState<"pro-light" | "pro-dark">("pro-light");
  const [slugState, setSlugState] = useState<"idle" | "checking" | "ok" | "bad">("idle");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const debounce = useRef<number | null>(null);

  useEffect(() => {
    if (slugEdited) setSlug(slugify(name));
    // Only auto-suggest while untouched; once keyed, respect the seller.
  }, [name, slugEdited]);

  const checkSlug = useCallback((candidate: string) => {
    if (debounce.current !== null) window.clearTimeout(debounce.current);
    if (candidate.length < 3) {
      setSlugState("idle");
      return;
    }
    setSlugState("checking");
    debounce.current = window.setTimeout(() => {
      void api
        .get<{ slug: string | null; available: boolean }>(
          `/stores/slug-check?slug=${encodeURIComponent(candidate)}`,
        )
        .then((data) => setSlugState(data.available ? "ok" : "bad"))
        .catch(() => setSlugState("idle"));
    }, 350);
  }, []);

  function onSlugChange(value: string): void {
    setSlug(value);
    checkSlug(value);
  }

  async function onSubmit(e: FormEvent): Promise<void> {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const data = await api.post<{ store: StorePayload }>("/seller/store", {
        name: name.trim(),
        slug: slug.trim(),
        tagline: tagline.trim() === "" ? undefined : tagline.trim(),
        whatsappNumber: whatsapp.trim() === "" ? undefined : whatsapp.trim(),
        locationLabel: location.trim() === "" ? undefined : location.trim(),
        themePreset: preset,
      });
      onCreated(data.store);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not create the store.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-6">
        <h1 className="text-lg font-semibold text-fg">Set up your storefront</h1>
        <p className="mt-1 text-sm text-muted">
          Photos, prices, and condition chips come later in the catalog phase. Start with
          your identity.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-5 rounded-token-lg border border-border bg-surface p-6 shadow-strip">
        <FormError message={error} />

        <Field label="Store name">
          <input
            required
            minLength={2}
            className={inputClass}
            placeholder="Kilimani Thrift Hub"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>

        <Field label="Store address" hint={RESERVED_HINT}>
          <div className="relative">
            <input
              required
              minLength={3}
              maxLength={32}
              className={inputClass}
              placeholder="kilimani-thrift-hub"
              value={slug}
              onChange={(e) => {
                if (!slugEdited) setSlugEdited(true);
                onSlugChange(e.target.value);
              }}
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2">
              {slugState === "checking" && <span className="text-[11px] text-muted">Checking</span>}
              {slugState === "ok" && <IconCheck size={15} className="text-success" />}
              {slugState === "bad" && <span className="text-[11px] font-medium text-danger">Taken</span>}
            </span>
          </div>
        </Field>

        <Field label="Tagline" hint="One line buyers see under your name. Optional.">
          <input
            className={inputClass}
            placeholder="Thrift finds, reconditioned tech, everyday carries"
            value={tagline}
            onChange={(e) => setTagline(e.target.value)}
          />
        </Field>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="WhatsApp number" hint="Buying contact shown on the storefront (future phase).">
            <input
              className={inputClass}
              placeholder="254712345678"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
            />
          </Field>
          <Field label="Location" hint="Neighbourhood or CBD stall. Optional.">
            <input
              className={inputClass}
              placeholder="Kilimani, Nairobi"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </Field>
        </div>

        <Field label="Theme preset" hint="Full customization ships in the theme editor (Phase 5).">
          <div className="grid gap-3 sm:grid-cols-2">
            {(
              [
                { id: "pro-light", label: "Studio Light", blurb: "Neutral paper, graphite text." },
                { id: "pro-dark", label: "Studio Dark", blurb: "Deep blue-black, cool contrast." },
              ] as const
            ).map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPreset(p.id)}
                aria-pressed={preset === p.id}
                className={
                  "rounded-token border p-3 text-left transition " +
                  (preset === p.id
                    ? "border-accent bg-accent-soft"
                    : "border-border bg-surface-alt hover:border-accent/40")
                }
              >
                <span className="block text-xs font-semibold text-fg">{p.label}</span>
                <span className="mt-0.5 block text-[11px] text-muted">{p.blurb}</span>
              </button>
            ))}
          </div>
        </Field>

        <button
          type="submit"
          disabled={busy || slugState === "bad" || slugState === "checking"}
          className="w-full rounded-token bg-accent py-3 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
        >
          {busy ? "Creating storefront" : "Create storefront"}
        </button>
      </form>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function StoreSettings({
  store,
  onUpdated,
}: {
  store: StorePayload;
  onUpdated: (store: StorePayload) => void;
}): React.ReactElement {
  const [name, setName] = useState(store.name);
  const [tagline, setTagline] = useState(store.tagline ?? "");
  const [whatsapp, setWhatsapp] = useState(store.whatsappNumber ?? "");
  const [location, setLocation] = useState(store.locationLabel ?? "");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  // Free-tier storefront address: the platform origin with the slug path.
  // Subdomains and custom domains are package/add-on surfaces on top of this.
  const storefrontPath = store.slug === "unknown" ? "" : `/s/${store.slug}`;
  const storefrontUrl = storefrontPath === "" ? "" : `${window.location.origin}${storefrontPath}`;

  async function onSubmit(e: FormEvent): Promise<void> {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      const data = await api.patch<{ store: StorePayload }>("/seller/store", {
        name: name.trim(),
        tagline: tagline.trim() === "" ? null : tagline.trim(),
        whatsappNumber: whatsapp.trim() === "" ? null : whatsapp.trim(),
        locationLabel: location.trim() === "" ? null : location.trim(),
      });
      onUpdated(data.store);
      setNotice("Storefront details saved.");
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not save changes.");
    } finally {
      setBusy(false);
    }
  }

  async function copyLink(): Promise<void> {
    try {
      await navigator.clipboard.writeText(storefrontUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <section className="rounded-token-lg border border-border bg-surface p-6 shadow-strip">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-fg">Your storefront is live</h2>
          <span className="rounded-full bg-success/15 px-2.5 py-1 text-[11px] font-semibold text-success">
            {store.plan === "grow" ? "Grow plan" : store.plan}
          </span>
        </div>
        <div className="flex items-center justify-between gap-3 rounded-token bg-surface-alt px-4 py-3">
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-fg">{storefrontUrl}</p>
            <p className="text-[10px] text-muted">
              Your storefront link. Subdomains come with higher plans; custom domains are an add-on.
            </p>
          </div>
          <button
            type="button"
            onClick={copyLink}
            className="shrink-0 rounded-token border border-border bg-surface px-3 py-1.5 text-[11px] font-semibold text-fg hover:border-accent/40"
          >
            {copied ? "Copied" : "Copy link"}
          </button>
        </div>
        <Link
          to="/dashboard/catalog"
          className="mt-3 block rounded-token bg-accent px-4 py-2.5 text-center text-xs font-semibold text-on-accent transition hover:bg-accent-hover"
        >
          Manage catalog
        </Link>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <Link
            to="/dashboard/orders"
            className="block rounded-token border border-border bg-surface px-4 py-2.5 text-center text-xs font-semibold text-fg hover:border-accent/40"
          >
            Order inbox
          </Link>
          <Link
            to="/dashboard/theme"
            className="block rounded-token border border-border bg-surface px-4 py-2.5 text-center text-xs font-semibold text-fg hover:border-accent/40"
          >
            Theme and branding
          </Link>
          <Link
            to="/dashboard/billing"
            className="block rounded-token border border-border bg-surface px-4 py-2.5 text-center text-xs font-semibold text-fg hover:border-accent/40"
          >
            Billing and boosts
          </Link>
        </div>
      </section>

      <form onSubmit={onSubmit} className="space-y-5 rounded-token-lg border border-border bg-surface p-6 shadow-strip">
        <h3 className="text-sm font-semibold text-fg">Storefront details</h3>
        {error !== null && <FormError message={error} />}
        {notice !== null && (
          <p className="rounded-token border border-success/25 bg-success/10 px-3 py-2 text-xs font-medium text-success">
            {notice}
          </p>
        )}

        <Field label="Store name">
          <input required minLength={2} className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Tagline">
          <input className={inputClass} value={tagline} onChange={(e) => setTagline(e.target.value)} />
        </Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="WhatsApp number">
            <input className={inputClass} value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} />
          </Field>
          <Field label="Location">
            <input className={inputClass} value={location} onChange={(e) => setLocation(e.target.value)} />
          </Field>
        </div>

        <Field label="Theme">
          <Link
            to="/dashboard/theme"
            className="block rounded-token border border-border bg-surface-alt px-4 py-3 transition hover:border-accent/40"
          >
            <span className="block text-xs font-semibold text-fg">Theme and branding</span>
            <span className="mt-0.5 block text-[11px] text-muted">
              Preset, colors, fonts, corners. Preview it, then publish when you are happy.
            </span>
          </Link>
        </Field>

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-token bg-accent py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
        >
          {busy ? "Saving" : "Save changes"}
        </button>
      </form>
    </div>
  );
}
