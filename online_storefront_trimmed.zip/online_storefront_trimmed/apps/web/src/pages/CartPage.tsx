import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useCart } from "../lib/cart.js";
import { api, ApiClientError } from "../lib/api.js";
import { FormError } from "../pages/CatalogPage.js";
import { IconBag, IconCheck, IconShare, IconSpinner, IconTrash } from "../components/icons.js";

interface CheckoutPayload {
  buyerName: string;
  buyerPhone: string;
  buyerLocation: string | null;
  fulfillment: "pickup" | "delivery";
  paymentMethod: "mpesa" | "pochi" | "cash" | "other";
  note: string | null;
  items: Array<{ listingId: string; quantity: number; size?: string; color?: string }>;
}

export interface OrderResult {
  token: string;
  status: string;
  totalKes: number;
  store: { slug: string; name: string; whatsappNumber: string | null };
  items: Array<{ title: string; priceKes: number; quantity: number }>;
}

const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted/70 focus:border-accent focus:outline-none";

export function CartPage(): React.ReactElement {
  const cart = useCart();
  const [buyerName, setBuyerName] = useState("");
  const [buyerPhone, setBuyerPhone] = useState("");
  const [buyerLocation, setBuyerLocation] = useState("");
  const [fulfillment, setFulfillment] = useState<"pickup" | "delivery">("pickup");
  const [paymentMethod, setPaymentMethod] = useState<"mpesa" | "pochi" | "cash" | "other">("mpesa");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [placed, setPlaced] = useState<OrderResult | null>(null);

  const total = cart.total();
  const items = cart.items;

  function whatsappMessage(order: OrderResult): string {
    const lines = [
      `New order, ${order.store.name}.`,
      "",
      ...order.items.map((i) => `${i.quantity} x ${i.title} KSh ${i.priceKes.toLocaleString("en-KE")}`),
      `Total: KSh ${order.totalKes.toLocaleString("en-KE")}`,
      "",
      `Buyer: ${buyerName}`,
      `Phone: ${buyerPhone}`,
      `${fulfillment === "pickup" ? "Pick up" : "Delivery"}${buyerLocation ? `, ${buyerLocation}` : ""}`,
      `Payment: ${paymentMethod}`,
      `Order ref: ${order.token}`,
    ];
    return lines.join("\n");
  }

  function openWhatsApp(order: OrderResult): void {
    if (order.store.whatsappNumber !== null) {
      window.open(
        `https://wa.me/${order.store.whatsappNumber.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(whatsappMessage(order))}`,
        "_blank",
        "noopener",
      );
    } else {
      window.open(
        `https://wa.me/?text=${encodeURIComponent(whatsappMessage(order))}`,
        "_blank",
        "noopener",
      );
    }
  }

  async function placeOrder(): Promise<void> {
    setError(null);
    setBusy(true);
    try {
      const payload: CheckoutPayload = {
        buyerName: buyerName.trim(),
        buyerPhone: buyerPhone.trim(),
        buyerLocation: buyerLocation.trim() === "" ? null : buyerLocation.trim(),
        fulfillment,
        paymentMethod,
        note: note.trim() === "" ? null : note.trim(),
        items: items.map((i) => ({
          listingId: i.listingId,
          quantity: i.quantity,
          ...(i.size !== null ? { size: i.size } : {}),
          ...(i.color !== null ? { color: i.color } : {}),
        })),
      };
      const data = await api.post<{ order: OrderResult }>(
        // Checkout POSTs land on the tenant that owns the bag even when the
        // buyer browsed an item link from the app domain or another host.
        items[0]?.storeSlug != null
          ? `/market/orders?storeSlug=${encodeURIComponent(items[0].storeSlug)}`
          : "/market/orders",
        payload,
      );
      setPlaced(data.order);
      cart.clear();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not place the order.");
    } finally {
      setBusy(false);
    }
  }

  /* --------------------------- confirmation view --------------------------- */

  if (placed !== null) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12">
        <div className="rounded-token-lg border border-border bg-surface p-8 text-center shadow-strip">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-success/10 text-success">
            <IconCheck size={22} />
          </span>
          <p className="mt-4 text-lg font-semibold text-fg">Order placed</p>
          <p className="mt-1 text-xs text-muted">
            Ref {placed.token}. Show this to the seller or send it straight to their WhatsApp.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => openWhatsApp(placed)}
              className="flex items-center gap-2 rounded-token bg-success px-5 py-2.5 text-xs font-semibold text-white"
            >
              <IconShare size={14} />
              Send order on WhatsApp
            </button>
            <Link
              to={`/orders/${placed.token}`}
              className="rounded-token border border-border bg-surface px-4 py-2.5 text-xs font-medium text-fg"
            >
              Order tracking
            </Link>
          </div>
        </div>
      </div>
    );
  }

  /* ------------------------------- cart view ------------------------------- */

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <header className="mb-6">
        <Link to="/" className="text-xs font-medium text-muted hover:text-fg">
          Back to storefront
        </Link>
        <h1 className="mt-2 text-lg font-semibold text-fg">Your bag</h1>
      </header>

      {items.length === 0 ? (
        <div className="rounded-token-lg border border-border bg-surface p-10 text-center shadow-strip">
          <IconBag size={22} className="mx-auto text-muted" />
          <p className="mt-3 text-sm font-medium text-fg">Your bag is empty</p>
          <p className="mt-1 text-xs text-muted">Items you pick from the storefront appear here.</p>
          <Link
            to="/"
            className="mt-4 inline-block rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent"
          >
            Browse items
          </Link>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {items.map((item) => (
              <div
                key={`${item.listingId}-${item.size ?? "-"}-${item.color ?? "-"}`}
                className="flex items-center gap-3 rounded-token-lg border border-border bg-surface p-3 shadow-strip"
              >
                {item.thumbUrl !== null ? (
                  <img
                    src={item.thumbUrl}
                    alt={item.title}
                    className="h-16 w-16 shrink-0 rounded-token object-cover"
                  />
                ) : (
                  <div className="h-16 w-16 shrink-0 rounded-token bg-skeleton" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="line-clamp-1 text-sm font-medium text-fg">{item.title}</p>
                  <p className="mt-0.5 text-xs text-muted">
                    KSh {item.priceKes.toLocaleString("en-KE")}
                    {item.size !== null ? ` / ${item.size}` : ""}
                    {item.color !== null ? ` / ${item.color}` : ""}
                  </p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <button
                      type="button"
                      aria-label="Fewer"
                      onClick={() =>
                        cart.setQuantity(item.listingId, item.size, item.color, item.quantity - 1)
                      }
                      className="h-7 w-7 rounded-token border border-border bg-surface text-xs font-semibold text-fg"
                    >
                      -
                    </button>
                    <span className="min-w-5 text-center text-xs font-semibold text-fg">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      aria-label="More"
                      onClick={() =>
                        cart.setQuantity(item.listingId, item.size, item.color, item.quantity + 1)
                      }
                      className="h-7 w-7 rounded-token border border-border bg-surface text-xs font-semibold text-fg"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => cart.remove(item.listingId, item.size, item.color)}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-token text-muted hover:text-danger"
                  aria-label={`Remove ${item.title}`}
                >
                  <IconTrash size={14} />
                </button>
              </div>
            ))}
          </div>

          <div className="mt-6 flex items-center justify-between rounded-token-lg border border-border bg-surface px-4 py-3 shadow-strip">
            <span className="text-xs font-medium text-muted">Total</span>
            <span className="text-sm font-semibold text-fg">
              KSh {total.toLocaleString("en-KE")}
            </span>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void placeOrder();
            }}
            className="mt-6 space-y-4 rounded-token-lg border border-border bg-surface p-5 shadow-strip"
          >
            <h2 className="text-sm font-semibold text-fg">Checkout details</h2>
            <FormError message={error} />

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Your name</span>
              <input required minLength={2} className={inputClass} placeholder="Amina Wanji" value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Phone number</span>
              <input required className={inputClass} placeholder="0712 345 678" value={buyerPhone} onChange={(e) => setBuyerPhone(e.target.value)} />
            </label>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-fg">Hand-off</span>
                <select className={inputClass} value={fulfillment} onChange={(e) => setFulfillment(e.target.value === "delivery" ? "delivery" : "pickup")}>
                  <option value="pickup">Pick up</option>
                  <option value="delivery">Delivery</option>
                </select>
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-fg">Payment</span>
                <select className={inputClass} value={paymentMethod} onChange={(e) => {
                  const value = e.target.value;
                  if (value === "mpesa" || value === "pochi" || value === "cash" || value === "other") {
                    setPaymentMethod(value);
                  }
                }}>
                  <option value="mpesa">M-Pesa (direct to seller)</option>
                  <option value="pochi">Pochi</option>
                  <option value="cash">Cash</option>
                  <option value="other">Other</option>
                </select>
              </label>
            </div>

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">
                {fulfillment === "pickup" ? "Where you will pick up" : "Delivery area"}
              </span>
              <input className={inputClass} placeholder="Kilimani, Nairobi" value={buyerLocation} onChange={(e) => setBuyerLocation(e.target.value)} />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold text-fg">Note to seller</span>
              <textarea rows={2} maxLength={500} className={inputClass} placeholder="Anything the seller should know." value={note} onChange={(e) => setNote(e.target.value)} />
            </label>

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-token bg-accent py-3 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
            >
              {busy ? (
                <span className="inline-flex items-center gap-2">
                  <IconSpinner size={15} className="animate-spin" />
                  Placing order
                </span>
              ) : (
                "Place order"
              )}
            </button>
            <p className="text-center text-[10px] text-muted">
              You pay the seller directly, in the app you already use. No payment runs through StoreSnap.
            </p>
          </form>
        </>
      )}
    </div>
  );
}

/** Buyer order tracking page, keyed by the unguessable token. */
export function OrderTrackingPage({ token }: { token: string }): React.ReactElement {
  const [order, setOrder] = useState<OrderResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void api
      .get<{ order: OrderResult }>(`/market/orders/${token}`)
      .then((data) => setOrder(data.order))
      .catch(() => setError("We could not find that order. Check the link."))
      .finally(() => setLoading(false));
  }, [token]);

  const statusLabels: Record<string, string> = {
    pending: "Awaiting seller confirmation",
    confirmed: "Confirmed",
    out: "On the way to hand-off",
    fulfilled: "Handed over",
    cancelled: "Cancelled",
  };

  if (loading) {
    return <p className="py-20 text-center text-sm text-muted">Loading...</p>;
  }
  if (error !== null || order === null) {
    return (
      <p className="py-20 text-center text-sm text-muted">
        {error ?? "Something went wrong."}
      </p>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <div className="rounded-token-lg border border-border bg-surface p-6 shadow-strip">
        <p className="text-xs font-medium text-muted">{order.store.name}</p>
        <h1 className="mt-1 text-lg font-semibold text-fg">
          Order {order.token}
        </h1>
        <p className="mt-2 inline-flex rounded-token bg-surface-alt px-3 py-1 text-[11px] font-semibold text-fg">
          {statusLabels[order.status] ?? order.status}
        </p>
        <div className="mt-6 space-y-2">
          {order.items.map((item, i) => (
            <div key={i} className="flex items-baseline justify-between text-sm">
              <span className="text-fg">
                {item.quantity} x {item.title}
              </span>
              <span className="font-medium text-fg">
                KSh {(item.priceKes * item.quantity).toLocaleString("en-KE")}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-4 border-t border-border pt-3 text-sm">
          <span className="text-muted">Total </span>
          <span className="font-semibold text-fg">
            KSh {order.totalKes.toLocaleString("en-KE")}
          </span>
        </div>
      </div>
    </div>
  );
}
