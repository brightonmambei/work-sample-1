/**
 * Theme editor (Phase 5): preset, palette, fonts, corners and grid density,
 * with a live in-page preview, draft save, atomic publish and one-step
 * rollback. The live storefront keeps the published theme until Publish, and
 * the draft is only visible to the owner through /s/{slug}?preview=draft.
 */
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  resolveThemeTokens,
  themeToCss,
  themeFonts,
  themeRadii,
  themeDensities,
  type Palette,
  type ThemeSpec,
} from "@storesnap/shared";
import { api, ApiClientError } from "../lib/api.js";

interface StorePayload {
  slug: string;
  name: string;
  tagline: string | null;
  plan: string;
  theme: ThemeSpec;
  themeDraft: ThemeSpec | null;
  themePrevious: ThemeSpec | null;
}

const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2 text-sm text-fg outline-none transition focus:border-accent";

/** Tokens a seller can tune; the rest stay derived from the preset. */
const paletteFields: Array<{ key: keyof Palette; label: string }> = [
  { key: "accent", label: "Accent" },
  { key: "accentHover", label: "Accent hover" },
  { key: "onAccent", label: "Text on accent" },
  { key: "bg", label: "Page background" },
  { key: "surface", label: "Card surface" },
  { key: "surfaceAlt", label: "Subtle surface" },
  { key: "fg", label: "Text" },
  { key: "muted", label: "Muted text" },
  { key: "border", label: "Borders" },
];

const HEX_RE = /^#[0-9a-f]{6}$/i;

function clamp255(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function shiftHex(hex: string, delta: number): string {
  const r = clamp255(parseInt(hex.slice(1, 3), 16) + delta);
  const g = clamp255(parseInt(hex.slice(3, 5), 16) + delta);
  const b = clamp255(parseInt(hex.slice(5, 7), 16) + delta);
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("")}`;
}

function alphaHex(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function ThemeEditorPage(): React.ReactElement {
  const [store, setStore] = useState<StorePayload | null>(null);
  const [spec, setSpec] = useState<ThemeSpec | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void api
      .get<{ store: StorePayload | null }>("/seller/store")
      .then((data) => {
        if (cancelled || data.store === null) return;
        setStore(data.store);
        setSpec(data.store.themeDraft ?? data.store.theme);
      })
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const baseline = store === null ? null : (store.themeDraft ?? store.theme);
  const dirty = spec !== null && baseline !== null && JSON.stringify(spec) !== JSON.stringify(baseline);
  const previewCss = useMemo(() => (spec === null ? "" : themeToCss(spec, "#theme-preview")), [spec]);
  // Swatches show what the storefront actually uses: an override when it is a
  // pickable hex value, otherwise the preset value the token falls back to.
  const presetTokens = useMemo(
    () =>
      resolveThemeTokens({
        schemaVersion: 1,
        preset: spec?.preset ?? "pro-light",
        overrides: {},
      }),
    [spec?.preset],
  );

  function swatchValue(key: keyof Palette): string {
    const override = spec?.overrides.palette?.[key];
    if (typeof override === "string" && HEX_RE.test(override)) return override;
    const fromPreset = presetTokens[key];
    return HEX_RE.test(fromPreset) ? fromPreset : presetTokens.accent;
  }

  function patch(next: Partial<ThemeSpec["overrides"]>): void {
    setNotice(null);
    setSpec((current) =>
      current === null ? current : { ...current, overrides: { ...current.overrides, ...next } },
    );
  }

  function setColor(key: keyof Palette, value: string): void {
    setSpec((current) => {
      if (current === null) return current;
      const palette = { ...(current.overrides.palette ?? {}), [key]: value };
      // Keep the accent family coherent when the accent itself moves: the
      // soft tint and hover shade follow it instead of clashing with the
      // preset's blue.
      if (key === "accent" && HEX_RE.test(value)) {
        palette.accentSoft = alphaHex(value, 0.1);
        palette.accentHover = shiftHex(value, -24);
      }
      return { ...current, overrides: { ...current.overrides, palette } };
    });
  }

  function resetColor(key: keyof Palette): void {
    setSpec((current) => {
      if (current === null) return current;
      const palette = { ...(current.overrides.palette ?? {}) };
      delete palette[key];
      return { ...current, overrides: { ...current.overrides, palette } };
    });
  }

  async function run(action: string, fn: () => Promise<{ store: StorePayload }>): Promise<void> {
    setBusy(action);
    setError(null);
    setNotice(null);
    try {
      const data = await fn();
      setStore(data.store);
      if (action === "save") {
        setSpec(data.store.themeDraft ?? data.store.theme);
        setNotice("Draft saved. Buyers still see the published theme.");
      } else if (action === "publish") {
        setSpec(data.store.theme);
        setNotice("Published. Your storefront is live with the new theme.");
      } else if (action === "discard") {
        setSpec(data.store.theme);
        setNotice("Draft discarded.");
      } else if (action === "restore") {
        setSpec(data.store.theme);
        setNotice("Restored the previous theme.");
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "That did not work. Try again.");
    } finally {
      setBusy(null);
    }
  }

  const saveDraft = () =>
    run("save", () => api.patch<{ store: StorePayload }>("/seller/store/theme", spec));
  const publish = () =>
    run("publish", async () => {
      // Publish whatever the editor currently shows: save first when the
      // local state has moved on, so one click always means "make this live".
      if (dirty) await api.patch<{ store: StorePayload }>("/seller/store/theme", spec);
      return api.post<{ store: StorePayload }>("/seller/store/theme/publish");
    });
  const discard = () => run("discard", () => api.post<{ store: StorePayload }>("/seller/store/theme/discard"));
  const restore = () => run("restore", () => api.post<{ store: StorePayload }>("/seller/store/theme/restore"));

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16 text-center text-sm text-muted">Loading theme...</div>
    );
  }
  if (store === null || spec === null) {
    return (
      <div className="mx-auto max-w-xl space-y-4 px-4 py-16 text-center">
        <p className="text-sm text-muted">Create your store first, then come back to style it.</p>
        <Link to="/dashboard" className="text-sm font-semibold text-accent">
          Back to dashboard
        </Link>
      </div>
    );
  }

  const palette: Partial<Palette> = spec.overrides.palette ?? {};

  return (
    <div className="mx-auto max-w-6xl px-4 pb-16 pt-6">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">Theme</p>
          <h1 className="font-display text-2xl font-semibold text-fg">{store.name}</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Link
            to="/dashboard"
            className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-semibold text-fg hover:border-accent/40"
          >
            Dashboard
          </Link>
          <a
            href={`/s/${store.slug}?preview=draft`}
            target="_blank"
            rel="noreferrer"
            className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-semibold text-fg hover:border-accent/40"
          >
            Preview storefront
          </a>
          <button
            type="button"
            onClick={() => void saveDraft()}
            disabled={busy !== null || !dirty}
            className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-semibold text-fg hover:border-accent/40 disabled:opacity-50"
          >
            {busy === "save" ? "Saving" : "Save draft"}
          </button>
          <button
            type="button"
            onClick={() => void publish()}
            disabled={busy !== null || (!dirty && store.themeDraft === null)}
            className="rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-50"
          >
            {busy === "publish" ? "Publishing" : "Publish"}
          </button>
        </div>
      </div>

      {error !== null && (
        <p className="mb-4 rounded-token border border-danger/30 bg-danger/10 px-3 py-2 text-xs font-medium text-danger">
          {error}
        </p>
      )}
      {notice !== null && (
        <p className="mb-4 rounded-token border border-success/25 bg-success/10 px-3 py-2 text-xs font-medium text-success">
          {notice}
        </p>
      )}

      <div className="mb-5 flex flex-wrap items-center gap-2 text-[11px]">
        {store.themeDraft !== null ? (
          <span className="rounded-full bg-warning/15 px-2.5 py-1 font-semibold text-warning">
            Unpublished draft
          </span>
        ) : (
          <span className="rounded-full bg-success/15 px-2.5 py-1 font-semibold text-success">
            Published and live
          </span>
        )}
        {dirty && (
          <span className="rounded-full bg-surface-alt px-2.5 py-1 font-medium text-muted">
            Unsaved edits in this page
          </span>
        )}
        {dirty && (
          <span className="text-muted">
            Publish saves these edits and makes them live. Save draft keeps them for later.
          </span>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)]">
        <div className="space-y-5">
          <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <h2 className="text-sm font-semibold text-fg">Preset</h2>
            <p className="mt-1 text-[11px] text-muted">
              A preset sets every token. Your overrides layer on top of it.
            </p>
            <div className="mt-3 grid grid-cols-2 gap-3">
              {(
                [
                  { id: "pro-light", label: "Studio Light" },
                  { id: "pro-dark", label: "Studio Dark" },
                ] as const
              ).map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setSpec({ ...spec, preset: preset.id })}
                  aria-pressed={spec.preset === preset.id}
                  className={
                    "rounded-token border px-4 py-3 text-left text-xs font-semibold transition " +
                    (spec.preset === preset.id
                      ? "border-accent bg-accent-soft text-fg"
                      : "border-border bg-surface-alt text-muted hover:text-fg")
                  }
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </section>

          <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <h2 className="text-sm font-semibold text-fg">Colors</h2>
            <p className="mt-1 text-[11px] text-muted">
              Leave a token alone to inherit it from the preset. Changing the accent also
              refreshes its hover shade and soft tint.
            </p>
            <div className="mt-4 space-y-3">
              {paletteFields.map((field) => {
                const value = palette[field.key];
                return (
                  <div key={field.key} className="flex items-center gap-3">
                    <input
                      type="color"
                      aria-label={field.label}
                      value={swatchValue(field.key)}
                      onChange={(e) => setColor(field.key, e.target.value)}
                      className="h-9 w-12 shrink-0 cursor-pointer rounded-token border border-border bg-surface"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-fg">{field.label}</p>
                      <input
                        value={value ?? ""}
                        placeholder="From preset"
                        onChange={(e) => setColor(field.key, e.target.value)}
                        className="mt-1 w-full rounded-token border border-border bg-surface-alt px-2 py-1 text-[11px] tabular-nums text-muted outline-none focus:border-accent"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => resetColor(field.key)}
                      disabled={value === undefined}
                      className="shrink-0 rounded-token border border-border px-2 py-1 text-[10px] font-semibold text-muted hover:text-fg disabled:opacity-40"
                    >
                      Reset
                    </button>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
            <h2 className="text-sm font-semibold text-fg">Typography, corners and density</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <label className="block">
                <span className="text-[11px] font-medium text-muted">Fonts</span>
                <select
                  className={`${inputClass} mt-1`}
                  value={spec.overrides.font ?? "editorial"}
                  onChange={(e) => patch({ font: e.target.value as ThemeSpec["overrides"]["font"] })}
                >
                  {Object.entries(themeFonts).map(([id, font]) => (
                    <option key={id} value={id}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="text-[11px] font-medium text-muted">Corners</span>
                <select
                  className={`${inputClass} mt-1`}
                  value={spec.overrides.radius ?? "soft"}
                  onChange={(e) => patch({ radius: e.target.value as ThemeSpec["overrides"]["radius"] })}
                >
                  {Object.entries(themeRadii).map(([id, radius]) => (
                    <option key={id} value={id}>
                      {radius.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="text-[11px] font-medium text-muted">Grid density</span>
                <select
                  className={`${inputClass} mt-1`}
                  value={spec.overrides.density ?? "comfy"}
                  onChange={(e) => patch({ density: e.target.value as ThemeSpec["overrides"]["density"] })}
                >
                  {Object.entries(themeDensities).map(([id, density]) => (
                    <option key={id} value={id}>
                      {density.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setSpec({ schemaVersion: 1, preset: spec.preset, overrides: {} })}
                className="rounded-token border border-border bg-surface px-3 py-2 text-[11px] font-semibold text-fg hover:border-accent/40"
              >
                Clear all overrides
              </button>
              <button
                type="button"
                onClick={() => void restore()}
                disabled={busy !== null || store.themePrevious === null}
                className="rounded-token border border-border bg-surface px-3 py-2 text-[11px] font-semibold text-fg hover:border-accent/40 disabled:opacity-50"
              >
                {busy === "restore" ? "Restoring" : "Restore previous theme"}
              </button>
              <button
                type="button"
                onClick={() => void discard()}
                disabled={busy !== null || store.themeDraft === null}
                className="rounded-token border border-danger/30 px-3 py-2 text-[11px] font-semibold text-danger hover:bg-danger/10 disabled:opacity-50"
              >
                {busy === "discard" ? "Discarding" : "Discard draft"}
              </button>
            </div>
          </section>
        </div>

        <div>
          <div className="sticky top-4">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">
              Live preview
            </p>
            <div id="theme-preview" className="rounded-token-lg border border-border bg-bg p-4">
              <style>{previewCss}</style>
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-token bg-accent text-[11px] font-bold text-on-accent">
                    {store.name.slice(0, 1)}
                  </span>
                  <span className="font-display text-sm font-semibold text-fg">{store.name}</span>
                </div>
                <span className="rounded-token border border-border bg-surface px-2 py-1 text-[10px] font-medium text-muted">
                  Bag
                </span>
              </div>
              <div className="mb-3 flex gap-1.5 overflow-hidden">
                {["All items", "Clothes", "Sneakers"].map((pill, i) => (
                  <span
                    key={pill}
                    className={
                      "whitespace-nowrap rounded-full px-2.5 py-1 text-[10px] font-semibold " +
                      (i === 0
                        ? "bg-accent text-on-accent"
                        : "border border-border bg-surface text-muted")
                    }
                  >
                    {pill}
                  </span>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                {["Denim jacket", "Air Force 1"].map((title, i) => (
                  <div
                    key={title}
                    className="overflow-hidden rounded-token-lg border border-border bg-surface shadow-strip"
                  >
                    <div className="flex aspect-[3/4] items-center justify-center bg-skeleton">
                      <span className="text-[10px] font-medium uppercase tracking-wider text-muted">
                        Photo
                      </span>
                    </div>
                    <div className="space-y-1 p-3">
                      <p className="font-display text-xs font-semibold text-fg">{title}</p>
                      <p className="text-[11px] font-semibold tabular-nums text-fg">
                        KSh {(i === 0 ? 1800 : 4500).toLocaleString("en-KE")}
                      </p>
                      <p className="text-[10px] font-medium text-warning">Only 2 left</p>
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[10px] leading-relaxed text-muted">
                Preview only. Your storefront shows your real photos, prices and stock.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
