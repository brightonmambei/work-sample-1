/**
 * Item deep-link page: where /p/:shortId humans land (AGENTS.md section 8).
 * The route works on any host, so a WhatsApp click on app.storesnap... still
 * resolves the item. Sold links never die: they resolve to this page's sold
 * state with a way back to what is left.
 */
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toStorefrontProducts, type StorefrontProduct } from "../lib/catalog.js";
import { useCart } from "../lib/cart.js";
import { IconBag, IconCheck, IconChevronRight, IconMessage } from "../components/icons.js";

interface ShareStore {
  slug: string;
  name: string;
  tagline: string | null;
  whatsappNumber: string | null;
}

interface ShareResolution {
  state: "live" | "sold" | "gone";
  store: ShareStore | null;
  listing: unknown;
}

function waDigits(n: string): string {
  return n.replace(/[^\d]/g, "");
}

export function ItemPage(): React.ReactElement {
  const { code = "" } = useParams();
  const [resolution, setResolution] = useState<ShareResolution | null>(null);
  const [failed, setFailed] = useState(false);

  // Variant picks + cart, mirroring the storefront product modal.
  const product = useMemo<StorefrontProduct | null>(() => {
    if (resolution?.listing == null) return null;
    return toStorefrontProducts([resolution.listing])[0] ?? null;
  }, [resolution]);

  useEffect(() => {
    let cancelled = false;
    setResolution(null);
    setFailed(false);
    const search = new URLSearchParams(window.location.search);
    const r = search.get("r");
    void fetch(`/api/v1/market/p/${encodeURIComponent(code)}${r ? `?r=${encodeURIComponent(r)}` : ""}`)
      .then((res) =>
        res.ok ? res.json().then((b: { data?: ShareResolution }) => b.data ?? null) : null,
      )
      .then((data) => {
        if (!cancelled) {
          if (data === null) setFailed(true);
          else setResolution(data);
        }
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [code]);

  if (failed) {
    return (
      <RestfulState
        title="This link came up empty"
        line="The item may have been removed, or the address is mistyped."
        cta={null}
      />
    );
  }

  const store = resolution?.store ?? null;

  if (resolution !== null && resolution.state !== "live") {
    return (
      <RestfulState
        title={resolution.state === "sold" ? "This piece found a home" : "This link is resting"}
        line={
          resolution.state === "sold"
            ? "It sold out. Group posts change fast. Here is what is still in the store."
            : "The seller has paused or archived this item."
        }
        cta={store !== null ? { label: `Browse ${store.name}`, href: `/s/${store.slug}` } : null}
      />
    );
  }

  return (
    <div className="min-h-screen">
      {product !== null && store !== null ? (
        <ItemDetail product={product} store={store} />
      ) : (
        <div className="mx-auto max-w-5xl px-4 py-16">
          <div className="mx-auto max-w-xl space-y-4">
            <div className="aspect-[3/4] w-full max-w-md animate-pulse rounded-token-lg bg-skeleton" />
            <div className="h-7 w-3/4 animate-pulse rounded-token bg-skeleton" />
            <div className="h-5 w-1/3 animate-pulse rounded-token bg-skeleton" />
          </div>
        </div>
      )}
    </div>
  );
}

/** Quiet full-page states: sold, archived, or an empty link. */
function RestfulState({
  title,
  line,
  cta,
}: {
  title: string;
  line: string;
  cta: { label: string; href: string } | null;
}): React.ReactElement {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md rounded-token-lg border border-border bg-surface p-10 text-center shadow-strip">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-surface-alt">
          <IconBag size={20} className="text-muted" />
        </div>
        <h1 className="mt-5 font-display text-3xl font-semibold text-fg">{title}</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">{line}</p>
        {cta !== null && (
          <Link
            to={cta.href}
            className="mt-6 inline-flex items-center gap-1.5 rounded-token bg-accent px-5 py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover"
          >
            {cta.label}
            <IconChevronRight size={15} />
          </Link>
        )}
      </div>
    </main>
  );
}

function ItemDetail({
  product,
  store,
}: {
  product: StorefrontProduct;
  store: ShareStore;
}): React.ReactElement {
  const { slug } = store;
  const [sizeIdx, setSizeIdx] = useState(0);
  const [colorIdx, setColorIdx] = useState(0);
  const [imgIdx, setImgIdx] = useState(0);
  const [added, setAdded] = useState(false);
  const add = useCart((s) => s.add);

  const img = imgIdx < product.media.length ? product.media[imgIdx] : undefined;
  const cover = img?.fullUrl ?? img?.cardUrl ?? img?.thumbUrl ?? null;
  const soldOut = product.stock <= 0;
  const discount =
    product.compareAtKes !== null && product.compareAtKes > product.priceKes;
  const digits = store.whatsappNumber !== null ? waDigits(store.whatsappNumber) : "";

  const waHref =
    digits !== ""
      ? `https://wa.me/${digits}?text=${encodeURIComponent(
          `Hi ${store.name}, is "${product.title}" (KSh ${product.priceKes.toLocaleString("en-KE")}) still available?`,
        )}`
      : null;

  return (
    <main className="mx-auto max-w-6xl px-4 pb-16 pt-4">
      <nav className="flex items-center gap-1.5 pb-5 text-xs text-muted">
        <Link to={`/s/${slug}`} className="hover:text-fg">
          {store.name}
        </Link>
        <IconChevronRight size={13} />
        <span className="text-fg">{product.title}</span>
      </nav>

      <div className="grid gap-8 md:grid-cols-2">
        {/* Media: full-bleed portrait, nothing competes with the garment. */}
        <div>
          <div className="relative overflow-hidden rounded-token-lg bg-skeleton">
            {cover !== null ? (
              <img
                src={cover}
                alt={product.title}
                className="aspect-[3/4] w-full object-cover"
              />
            ) : (
              <div className="aspect-[3/4] w-full" />
            )}
            {product.media.length > 1 ? (
              <span className="absolute bottom-3 right-3 rounded-token bg-surface/90 px-2.5 py-1 text-[11px] font-medium text-fg shadow-strip">
                {imgIdx + 1} / {product.media.length}
              </span>
            ) : null}
          </div>
          {product.media.length > 1 ? (
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {product.media.map((m, i) => {
                const src = m.thumbUrl ?? m.cardUrl ?? m.fullUrl;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setImgIdx(i)}
                    className={
                      "h-16 w-12 shrink-0 overflow-hidden rounded-token border " +
                      (i === imgIdx ? "border-accent" : "border-border opacity-70 hover:opacity-100")
                    }
                    aria-label={`Photo ${i + 1}`}
                  >
                    {src !== null ? <img src={src} alt="" className="h-full w-full object-cover" /> : null}
                  </button>
                );
              })}
            </div>
          ) : null}
        </div>

        {/* Buy panel */}
        <div className="md:sticky md:top-6 md:self-start">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-accent">
            {product.badgeText ?? (product.condition === "thrift" ? "Thrift item" : "New item")}
          </p>

          <h1 className="mt-3 font-display text-3xl font-semibold leading-tight text-fg sm:text-4xl">
            {product.title}
          </h1>

          <div className="mt-3 flex items-baseline gap-3">
            <span className="font-display text-3xl font-semibold tabular-nums text-fg">
              KSh {product.priceKes.toLocaleString("en-KE")}
            </span>
            {discount && (
              <>
                <span className="text-sm text-muted line-through tabular-nums">
                  KSh {product.compareAtKes!.toLocaleString("en-KE")}
                </span>
                <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-semibold text-warning">
                  {Math.round((1 - product.priceKes / product.compareAtKes!) * 100)}% off
                </span>
              </>
            )}
          </div>

          {product.description !== null && (
            <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted">
              {product.description}
            </p>
          )}

          {product.sizes.length > 0 ? (
            <VariantRow
              label="Size"
              options={product.sizes}
              active={sizeIdx}
              onSelect={setSizeIdx}
            />
          ) : null}
          {product.colors.length > 0 ? (
            <VariantRow
              label="Color"
              options={product.colors}
              active={colorIdx}
              onSelect={setColorIdx}
            />
          ) : null}

          <p className="mt-5 text-xs font-medium text-muted">
            {soldOut ? (
              <span className="text-danger">Sold out</span>
            ) : product.stock <= 2 ? (
              <span className="text-warning">Only {product.stock} left in stock</span>
            ) : (
              `${product.stock} in stock`
            )}
          </p>

          <div className="mt-5 space-y-2.5 border-t border-border pt-5">
            <button
              type="button"
              disabled={soldOut}
              onClick={() => {
                add({
                  listingId: product.id,
                  code: product.code,
                  title: product.title,
                  priceKes: product.priceKes,
                  condition: product.condition,
                  size: product.sizes.length > 0 ? (product.sizes[sizeIdx] ?? null) : null,
                  color: product.colors.length > 0 ? (product.colors[colorIdx] ?? null) : null,
                  thumbUrl: img?.thumbUrl ?? null,
                  storeSlug: slug,
                });
                setAdded(true);
                window.setTimeout(() => setAdded(false), 1400);
              }}
              className="w-full rounded-token bg-accent py-3.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
            >
              {added ? (
                <span className="inline-flex items-center justify-center gap-2">
                  <IconCheck size={15} />
                  Added to bag
                </span>
              ) : (
                <span className="inline-flex items-center justify-center gap-2">
                  <IconBag size={15} />
                  Add to bag
                </span>
              )}
            </button>
            {waHref !== null && (
              <a
                href={waHref}
                target="_blank"
                rel="noreferrer"
                className="flex w-full items-center justify-center gap-2 rounded-token border border-border bg-surface py-3 text-sm font-semibold text-fg transition hover:border-accent/40"
              >
                <IconMessage size={15} />
                Ask about this on WhatsApp
              </a>
            )}
            <p className="text-center text-[11px] leading-relaxed text-muted">
              Pickup or delivery is arranged with {store.name}. Buyers pay the seller
              directly; StoreSnap never handles the money.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}

function VariantRow({
  label,
  options,
  active,
  onSelect,
}: {
  label: string;
  options: string[];
  active: number;
  onSelect: (i: number) => void;
}): React.ReactElement {
  return (
    <div className="mt-5">
      <p className="text-[11px] font-semibold uppercase tracking-wider text-muted">{label}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((opt, i) => (
          <button
            key={opt}
            type="button"
            onClick={() => onSelect(i)}
            className={
              "rounded-token px-4 py-2 text-xs font-medium transition " +
              (i === active
                ? "bg-accent text-on-accent"
                : "border border-border bg-surface text-muted hover:border-accent/40 hover:text-fg")
            }
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}
