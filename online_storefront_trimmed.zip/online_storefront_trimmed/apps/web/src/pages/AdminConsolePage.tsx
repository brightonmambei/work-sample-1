/**
 * Platform admin console, Phase 4 slice: overview, stores, billing, rate card,
 * audit log. Reached only by the platform_owner role (server-enforced).
 */
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { FormError } from "./CatalogPage.js";

const kes = (n: number): string => `KSh ${n.toLocaleString("en-KE")}`;

interface Overview {
  activeStores: number;
  suspendedStores: number;
  sellers: number;
  planCounts: Record<string, number>;
  mrrKes: number;
  boostRevenueKes: number;
  invoiceRevenueKes: number;
  overdueInvoices: number;
  openInvoices: number;
  recordedSales: { units: number; valueKes: number };
  tierPrices: { commerce: number; business: number };
}

interface StoreRow {
  id: string;
  slug: string;
  name: string;
  plan: string;
  status: string;
  createdAt: string;
  _count: { listings: number; orders: number };
}

interface InvoiceAdminRow {
  id: string;
  storeSlug: string;
  storeName: string;
  status: string;
  totalKes: number;
  issuedAt: string | null;
  paidAt: string | null;
  dueAt: string | null;
  periodUnits: number | null;
  periodRecordedKes: number | null;
}

interface RateCardRow {
  key: string;
  label: string;
  feeBps: number;
  minFeeKes: number;
  active: boolean;
  updatedAt: string;
}

interface AuditEntry {
  id: string;
  actorEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  createdAt: string;
}

type Tab = "overview" | "stores" | "invoices" | "rate" | "storage" | "audit";

export function AdminConsolePage(): React.ReactElement {
  return <AdminTabs />;
}

function AdminTabs(): React.ReactElement {
  const [tab, setTab] = useState<Tab>("overview");
  const tabs: Array<{ key: Tab; label: string }> = [
    { key: "overview", label: "Overview" },
    { key: "stores", label: "Stores" },
    { key: "invoices", label: "Invoices" },
    { key: "rate", label: "Rate card" },
    { key: "storage", label: "Storage" },
    { key: "audit", label: "Audit log" },
  ];

  return (
    <div className="min-h-screen bg-surface-alt">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-fg">StoreSnap</span>
            <span className="rounded-token bg-accent px-2 py-0.5 text-[11px] font-semibold text-on-accent">
              Admin
            </span>
          </div>
          <nav className="flex flex-wrap items-center gap-1">
            {tabs.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTab(t.key)}
                className={
                  "rounded-token px-3 py-1.5 text-xs font-medium transition " +
                  (tab === t.key
                    ? "bg-surface-alt text-fg shadow-strip"
                    : "text-muted hover:text-fg")
                }
              >
                {t.label}
              </button>
            ))}
            <Link
              to="/dashboard"
              className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-medium text-fg"
            >
              Dashboard
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {tab === "overview" && <OverviewTab />}
        {tab === "stores" && <StoresTab />}
        {tab === "invoices" && <InvoicesTab />}
        {tab === "rate" && <RateCardTab />}
        {tab === "storage" && <StorageTab />}
        {tab === "audit" && <AuditTab />}
      </main>
    </div>
  );
}

/* ------------------------------- overview --------------------------------- */

function OverviewTab(): React.ReactElement {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void api
      .get<{ overview: Overview }>("/admin/overview")
      .then((d) => setData(d.overview))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load the overview."),
      );
  }, []);

  if (error !== null) return <FormError message={error} />;
  if (data === null) return <LoadingBlock />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card label="MRR" value={kes(data.mrrKes)} />
        <Card label="Boost revenue" value={kes(data.boostRevenueKes)} />
        <Card label="Invoice revenue" value={kes(data.invoiceRevenueKes)} />
        <Card
          label="Recorded sales"
          value={`${kes(data.recordedSales.valueKes)} / ${data.recordedSales.units}`}
        />
        <Card
          label="Stores"
          value={`${data.activeStores} active${data.suspendedStores > 0 ? ` / ${data.suspendedStores} suspended` : ""}`}
        />
        <Card label="Sellers" value={String(data.sellers)} />
        <Card
          label="Open invoices"
          value={`${data.openInvoices}${data.overdueInvoices > 0 ? ` / ${data.overdueInvoices} overdue` : ""}`}
        />
        <Card
          label="Tier mix"
          value={`G ${data.planCounts.grow ?? 0} / C ${data.planCounts.commerce ?? 0} / B ${data.planCounts.business ?? 0}`}
        />
      </div>

      <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
        <h2 className="text-sm font-semibold text-fg">Metering operations</h2>
        <p className="mt-1 text-xs text-muted">
          The nightly pg-boss schedule runs these automatically; use them to run a pass on demand.
        </p>
        <div className="mt-3 flex gap-2">
          <MeterButton
            label="Aggregate usage now"
            path="/admin/usage/aggregate"
            success="Periods aggregated."
          />
          <MeterButton
            label="Enforce overdue now"
            path="/admin/billing/enforce-overdue"
            success="Dunning pass complete."
          />
        </div>
      </section>
    </div>
  );
}

function MeterButton({
  label,
  path,
  success,
}: {
  label: string;
  path: string;
  success: string;
}): React.ReactElement {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <span>
      <button
        type="button"
        disabled={busy}
        onClick={() => {
          setBusy(true);
          setErr(null);
          void api
            .post(path)
            .then(() => setDone(true))
            .catch((e) => setErr(e instanceof ApiClientError ? e.message : "Failed."))
            .finally(() => setBusy(false));
        }}
        className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-semibold text-fg hover:border-accent/40 disabled:opacity-60"
      >
        {busy ? "Running..." : label}
      </button>
      {done && <span className="ml-2 text-xs text-muted">{success}</span>}
      {err !== null && <span className="ml-2 text-xs text-danger">{err}</span>}
    </span>
  );
}

function Card({ label, value }: { label: string; value: string }): React.ReactElement {
  return (
    <div className="rounded-token-lg border border-border bg-surface p-4 shadow-strip">
      <p className="text-[11px] font-medium text-muted">{label}</p>
      <p className="mt-1 text-base font-semibold tabular-nums text-fg">{value}</p>
    </div>
  );
}

function LoadingBlock(): React.ReactElement {
  return <p className="py-16 text-center text-sm text-muted">Loading...</p>;
}

/* -------------------------------- stores ---------------------------------- */

function StoresTab(): React.ReactElement {
  const [stores, setStores] = useState<StoreRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(() => {
    void api
      .get<{ stores: StoreRow[] }>("/admin/stores")
      .then((d) => setStores(d.stores))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load stores."),
      );
  }, []);

  useEffect(load, [load]);

  async function act(path: string, id: string): Promise<void> {
    setBusy(`${path}-${id}`);
    setError(null);
    try {
      await api.post(`/admin/stores/${id}/${path}`);
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Action failed.");
    } finally {
      setBusy(null);
    }
  }

  if (error !== null && stores === null) return <FormError message={error} />;
  if (stores === null) return <LoadingBlock />;

  return (
    <div className="space-y-3">
      <FormError message={error} />
      {stores.map((s) => (
        <article key={s.id} className="rounded-token-lg border border-border bg-surface p-4 shadow-strip">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold text-fg">
                {s.name}{" "}
                <span className="font-normal text-muted">(/s/{s.slug})</span>
              </p>
              <p className="mt-0.5 text-xs text-muted">
                {s.plan} / {s.status} / {s._count.listings} items / {s._count.orders} orders /{" "}
                {new Date(s.createdAt).toLocaleDateString("en-KE")}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label={`Change plan for ${s.name}`}
                value={s.plan}
                disabled={busy === `plan-${s.id}`}
                onChange={(e) => void planChange(e.target.value, s.id)}
                className="rounded-token border border-border bg-surface px-2 py-1.5 text-xs font-medium text-fg"
              >
                {["grow", "commerce", "business"].map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              {s.status === "active" ? (
                <button
                  type="button"
                  disabled={busy === `suspend-${s.id}`}
                  onClick={() => void act("suspend", s.id)}
                  className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-semibold text-muted hover:text-danger disabled:opacity-60"
                >
                  Suspend
                </button>
              ) : (
                <button
                  type="button"
                  disabled={busy === `restore-${s.id}`}
                  onClick={() => void act("restore", s.id)}
                  className="rounded-token bg-accent px-3 py-1.5 text-xs font-semibold text-on-accent hover:bg-accent-hover disabled:opacity-60"
                >
                  Restore
                </button>
              )}
            </div>
          </div>
        </article>
      ))}
    </div>
  );

  async function planChange(plan: string, id: string): Promise<void> {
    setBusy(`plan-${id}`);
    setError(null);
    try {
      await api.post(`/admin/stores/${id}/plan`, { plan });
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Plan change failed.");
    } finally {
      setBusy(null);
    }
  }
}

/* ------------------------------- invoices ---------------------------------- */

function InvoicesTab(): React.ReactElement {
  const [invoices, setInvoices] = useState<InvoiceAdminRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(() => {
    void api
      .get<{ invoices: InvoiceAdminRow[] }>("/admin/invoices")
      .then((d) => setInvoices(d.invoices))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load invoices."),
      );
  }, []);

  useEffect(load, [load]);

  async function op(id: string, op_: "release" | "void"): Promise<void> {
    setBusy(`${op_}-${id}`);
    setError(null);
    try {
      await api.post(`/admin/invoices/${id}/${op_}`);
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Action failed.");
    } finally {
      setBusy(null);
    }
  }

  async function adjust(id: string): Promise<void> {
    const raw = window.prompt("Adjustment in KSh (negative to credit, e.g. -50):");
    if (raw === null) return;
    const delta = Number(raw);
    if (!Number.isFinite(delta) || delta === 0) return;
    setBusy(`adjust-${id}`);
    setError(null);
    try {
      await api.post(`/admin/invoices/${id}/adjust`, { deltaKes: delta });
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Adjustment failed.");
    } finally {
      setBusy(null);
    }
  }

  if (invoices === null) return <LoadingBlock />;

  return (
    <div className="space-y-3">
      <FormError message={error} />
      {invoices.length === 0 && <LoadingOrEmpty count={0} text="No invoices yet." />}
      {invoices.map((i) => (
        <article key={i.id} className="rounded-token-lg border border-border bg-surface p-4 shadow-strip">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold tabular-nums text-fg">{kes(i.totalKes)}</p>
              <p className="mt-0.5 text-xs text-muted">
                {i.storeName} ({i.storeSlug}) /{" "}
                <span className="capitalize">{i.status}</span>
                {i.periodUnits !== null ? ` / ${i.periodUnits} sales / ${kes(i.periodRecordedKes ?? 0)} recorded` : ""}
                {i.dueAt !== null ? ` / due ${new Date(i.dueAt).toLocaleDateString("en-KE")}` : ""}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {i.status === "draft" && (
                <button
                  type="button"
                  disabled={busy === `release-${i.id}`}
                  onClick={() => void op(i.id, "release")}
                  className="rounded-token bg-accent px-3 py-1.5 text-xs font-semibold text-on-accent disabled:opacity-60"
                >
                  Release
                </button>
              )}
              <button
                type="button"
                disabled={busy === `adjust-${i.id}`}
                onClick={() => void adjust(i.id)}
                className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-medium text-fg disabled:opacity-60"
              >
                Adjust
              </button>
              {i.status !== "paid" && i.status !== "void" && (
                <button
                  type="button"
                  disabled={busy === `void-${i.id}`}
                  onClick={() => void op(i.id, "void")}
                  className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-semibold text-muted hover:text-danger disabled:opacity-60"
                >
                  Void
                </button>
              )}
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

function LoadingOrEmpty({ count, text }: { count: number; text: string }): React.ReactElement {
  void count;
  return <p className="py-8 text-center text-sm text-muted">{text}</p>;
}

/* ------------------------------- rate card --------------------------------- */

function RateCardTab(): React.ReactElement {
  const [cards, setCards] = useState<RateCardRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(() => {
    void api
      .get<{ cards: RateCardRow[] }>("/admin/rate-card")
      .then((d) => setCards(d.cards))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load the rate card."),
      );
  }, []);

  useEffect(load, [load]);

  async function save(card: RateCardRow, patch: Partial<RateCardRow>): Promise<void> {
    setBusy(card.key);
    setError(null);
    try {
      await api.put(`/admin/rate-card/${card.key}`, {
        feeBps: patch.feeBps ?? card.feeBps,
        minFeeKes: patch.minFeeKes ?? card.minFeeKes,
        active: patch.active ?? card.active,
      });
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Save failed.");
    } finally {
      setBusy(null);
    }
  }

  if (cards === null) return <LoadingBlock />;

  return (
    <div className="space-y-3">
      <FormError message={error} />
      <p className="text-xs text-muted">
        The rate card is configuration, not code. Fees apply to platform-recorded sales on
        Business-tier storefronts; corrections always happen on invoices, never in the ledger.
      </p>
      {cards.map((c) => (
        <RateCardEditor
          key={c.key}
          card={c}
          busy={busy === c.key}
          onSave={save}
        />
      ))}
    </div>
  );
}

function RateCardEditor({
  card,
  busy,
  onSave,
}: {
  card: RateCardRow;
  busy: boolean;
  onSave: (card: RateCardRow, patch: Partial<RateCardRow>) => Promise<void>;
}): React.ReactElement {
  const [feeBps, setFeeBps] = useState(String(card.feeBps));
  const [minFeeKes, setMinFeeKes] = useState(String(card.minFeeKes));

  return (
    <article className="rounded-token-lg border border-border bg-surface p-4 shadow-strip">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-fg">{card.label}</p>
          <p className="mt-0.5 text-[11px] text-muted">
            {card.key} / updated {new Date(card.updatedAt).toLocaleDateString("en-KE")} /{" "}
            {card.active ? "active" : "paused"}
          </p>
        </div>
        <button
          type="button"
          disabled={busy}
          onClick={() => void onSave(card, { active: !card.active })}
          className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-medium text-fg disabled:opacity-60"
        >
          {card.active ? "Pause" : "Activate"}
        </button>
      </div>
      <div className="mt-3 flex flex-wrap items-end gap-3">
        <label className="block">
          <span className="mb-1 block text-[11px] font-semibold text-fg">Fee (basis points)</span>
          <input
            type="number"
            min={0}
            max={2000}
            value={feeBps}
            onChange={(e) => setFeeBps(e.target.value)}
            className="w-28 rounded-token border border-border bg-surface px-3 py-2 text-sm tabular-nums text-fg"
          />
          <span className="mt-1 block text-[10px] text-muted">
            {Number(feeBps) / 100}% of recorded value
          </span>
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-semibold text-fg">Minimum fee (KSh)</span>
          <input
            type="number"
            min={0}
            value={minFeeKes}
            onChange={(e) => setMinFeeKes(e.target.value)}
            className="w-24 rounded-token border border-border bg-surface px-3 py-2 text-sm tabular-nums text-fg"
          />
        </label>
        <button
          type="button"
          disabled={busy}
          onClick={() =>
            void onSave(card, { feeBps: Number(feeBps), minFeeKes: Number(minFeeKes) })
          }
          className="rounded-token bg-accent px-3 py-2 text-xs font-semibold text-on-accent hover:bg-accent-hover disabled:opacity-60"
        >
          {busy ? "Saving..." : "Save rates"}
        </button>
      </div>
    </article>
  );
}

/* --------------------------------- audit ----------------------------------- */

/* ------------------------------- storage ---------------------------------- */

interface StorageOverview {
  bucket: string;
  ledger: {
    uploads: number;
    ledgerBytes: number;
    estimatedObjects: number;
    stalePending: number;
    orphanUploads: number;
  };
  bucketLive: { objectCount: number; totalBytes: number; unledgeredObjects: number };
  stores: Array<{
    storeId: string;
    slug: string;
    name: string;
    uploads: number;
    attachedUploads: number;
    orphanUploads: number;
    bytes: number;
  }>;
}

function StorageTab(): React.ReactElement {
  const [data, setData] = useState<StorageOverview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    void api
      .get<StorageOverview>("/admin/storage")
      .then(setData)
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load storage stats."),
      );
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function onGc(): Promise<void> {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await api.post<{ deletedUploads: number; deletedObjects: number }>("/admin/storage/gc");
      setNotice(
        `Orphan sweep removed ${res.deletedUploads} ledger row${res.deletedUploads === 1 ? "" : "s"} and ${res.deletedObjects} bucket file${res.deletedObjects === 1 ? "" : "s"}. Logged to the audit trail.`,
      );
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Orphan sweep failed.");
    } finally {
      setBusy(false);
    }
  }

  if (error !== null) return <FormError message={error} />;
  if (data === null) return <LoadingBlock />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card label="Bucket" value={data.bucket} />
        <Card label="Objects in bucket" value={data.bucketLive.objectCount.toLocaleString("en-KE")} />
        <Card label="Bucket size" value={fmtAdminBytes(data.bucketLive.totalBytes)} />
        <Card label="Ledger uploads" value={data.ledger.uploads.toLocaleString("en-KE")} />
        <Card label="Ledger size" value={fmtAdminBytes(data.ledger.ledgerBytes)} />
        <Card label="Unattached uploads" value={String(data.ledger.orphanUploads)} />
        <Card label="Stale pending" value={String(data.ledger.stalePending)} />
        <Card label="Unledgered objects" value={String(data.bucketLive.unledgeredObjects)} />
      </div>

      {notice !== null && (
        <div className="rounded-token border border-success/30 bg-success/10 px-4 py-3 text-sm text-fg">
          {notice}
        </div>
      )}

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted">
          Orphan sweep deletes uploads that were never attached to any item (older than 24 hours) and
          stale pending uploads (older than 7 days), from the ledger and the bucket.
        </p>
        <button
          type="button"
          onClick={onGc}
          disabled={busy}
          className="shrink-0 rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-50"
        >
          {busy ? "Sweeping..." : "Run orphan sweep"}
        </button>
      </div>

      <div className="overflow-hidden rounded-token-lg border border-border bg-surface">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="text-muted">
              <th className="px-3 py-2 font-medium">Store</th>
              <th className="px-3 py-2 font-medium">Uploads</th>
              <th className="px-3 py-2 font-medium">Attached</th>
              <th className="px-3 py-2 font-medium">Unattached</th>
              <th className="px-3 py-2 font-medium">Size</th>
            </tr>
          </thead>
          <tbody>
            {data.stores.map((s) => (
              <tr key={s.storeId} className="border-t border-border">
                <td className="px-3 py-2 font-medium text-fg">
                  {s.name} <span className="text-muted">/{s.slug}</span>
                </td>
                <td className="px-3 py-2">{s.uploads}</td>
                <td className="px-3 py-2">{s.attachedUploads}</td>
                <td className={"px-3 py-2" + (s.orphanUploads > 0 ? " text-warning" : "")}>
                  {s.orphanUploads}
                </td>
                <td className="px-3 py-2">{fmtAdminBytes(s.bytes)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {data.stores.length === 0 && (
          <p className="px-3 py-6 text-center text-sm text-muted">No uploads in the ledger yet.</p>
        )}
      </div>
    </div>
  );
}

function fmtAdminBytes(n: number): string {
  if (n >= 1024 * 1024 * 1024) return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  if (n >= 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  if (n >= 1024) return `${Math.round(n / 1024)} KB`;
  return `${n} B`;
}

function AuditTab(): React.ReactElement {
  const [entries, setEntries] = useState<AuditEntry[] | null>(null);

  useEffect(() => {
    void api
      .get<{ entries: AuditEntry[] }>("/admin/audit")
      .then((d) => setEntries(d.entries))
      .catch(() => setEntries([]));
  }, []);

  if (entries === null) return <LoadingBlock />;

  return (
    <div className="rounded-token-lg border border-border bg-surface p-2 shadow-strip">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className="text-muted">
            <th className="px-3 py-2 font-medium">When</th>
            <th className="px-3 py-2 font-medium">Actor</th>
            <th className="px-3 py-2 font-medium">Action</th>
            <th className="px-3 py-2 font-medium">Target</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.id} className="border-t border-border">
              <td className="px-3 py-2 text-muted">
                {new Date(e.createdAt).toLocaleString("en-KE")}
              </td>
              <td className="px-3 py-2">{e.actorEmail}</td>
              <td className="px-3 py-2 font-medium text-fg">{e.action}</td>
              <td className="px-3 py-2 text-muted">
                {e.targetType}:{e.targetId.slice(-8)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {entries.length === 0 && (
        <p className="px-3 py-6 text-center text-sm text-muted">No admin actions recorded yet.</p>
      )}
    </div>
  );
}
