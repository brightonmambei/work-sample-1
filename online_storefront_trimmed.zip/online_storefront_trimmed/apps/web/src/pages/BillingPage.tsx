/**
 * Seller billing (Phase 4): plan choice, the transparent usage ledger,
 * invoice collection over M-Pesa STK, and Boost purchases. Money discipline:
 * this page never handles seller sale money, only the platform's own fees.
 */
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { plans } from "@storesnap/shared";
import { api, ApiClientError } from "../lib/api.js";
import { FormError } from "./CatalogPage.js";

interface SubscriptionInfo {
  plan: string;
  status: string;
  period?: string;
  priceKes?: number;
  renewsAt?: string | null;
}

interface UsageInfo {
  units: number;
  recordedKes: number;
  currentFeeKes: number;
}

interface InvoiceRow {
  id: string;
  status: string;
  totalKes: number;
  lines: { items?: Array<{ label: string; amountKes: number }> } | null;
  createdAt: string;
}

interface BoostRow {
  id: string;
  listingId: string;
  packKey: string;
  amountKes: number;
  status: string;
  expiresAt: string | null;
}

interface BillingPayload {
  subscription: SubscriptionInfo;
  usage: UsageInfo;
  invoices: InvoiceRow[];
  boosts: BoostRow[];
  packs: Record<string, { label: string; amountKes: number; hours: number }>;
}

const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted/70 focus:border-accent focus:outline-none";

const kes = (n: number): string => `KSh ${n.toLocaleString("en-KE")}`;

export function BillingPage(): React.ReactElement {
  const [data, setData] = useState<BillingPayload | null>(null);
  const [listings, setListings] = useState<Array<{ id: string; title: string; stock: number }>>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Plan selection
  const [planChoice, setPlanChoice] = useState<"grow" | "commerce" | "business">("grow");
  const [periodChoice, setPeriodChoice] = useState<"monthly" | "weekly" | "quarterly">("monthly");

  // Collect
  const [collectPhone, setCollectPhone] = useState("");
  const [collectFor, setCollectFor] = useState<string | null>(null);

  // Boost
  const [boostListing, setBoostListing] = useState("");
  const [boostPack, setBoostPack] = useState("feature_48h");
  const [boostPhone, setBoostPhone] = useState("");

  const load = useCallback(() => {
    void api
      .get<BillingPayload>("/billing")
      .then((payload) => {
        setData(payload);
        setPlanChoice((payload.subscription.plan as typeof planChoice) ?? "grow");
      })
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load billing."),
      );
    void api
      .get<{ items: Array<{ id: string; title: string; stock: number }> }>(
        "/seller/products?pageSize=48",
      )
      .then((d) => setListings(d.items))
      .catch(() => undefined);
  }, []);

  useEffect(load, [load]);

  async function changePlan(): Promise<void> {
    setBusy("plan");
    setError(null);
    setNotice(null);
    try {
      await api.post("/billing/plan", { plan: planChoice, period: periodChoice });
      setNotice(
        planChoice === "grow"
          ? "You are back on Grow. Your catalog and storefront stay live."
          : "Plan active. The first collection confirms the subscription.",
      );
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not change the plan.");
    } finally {
      setBusy(null);
    }
  }

  async function collect(invoiceId: string): Promise<void> {
    setBusy(`collect-${invoiceId}`);
    setError(null);
    try {
      await api.post(`/billing/invoices/${invoiceId}/collect`, { phone: collectPhone });
      setNotice("M-Pesa request sent. Confirm on your phone; the invoice settles itself.");
      setCollectFor(null);
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Collection failed.");
    } finally {
      setBusy(null);
    }
  }

  async function boost(): Promise<void> {
    setBusy("boost");
    setError(null);
    try {
      await api.post("/boosts", {
        listingId: boostListing,
        packKey: boostPack,
        phone: boostPhone,
      });
      setNotice("Boost bought. The featured window is running.");
      load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Boost purchase failed.");
    } finally {
      setBusy(null);
    }
  }

  if (data === null) {
    return (
      <div className="min-h-screen">
        <PageHeader />
        <p className="px-4 py-16 text-center text-sm text-muted">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <PageHeader />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-8">
        <div>
          <h1 className="text-lg font-semibold text-fg">Billing</h1>
          <p className="mt-1 text-sm text-muted">
            Your plan, your transparent ledger, and the boosts that lifted a listing.
          </p>
        </div>

        <FormError message={error} />
        {notice !== null && (
          <p className="rounded-token border border-border bg-surface-alt px-4 py-3 text-sm text-fg">
            {notice}
          </p>
        )}

        {/* ------------------------------ plan ------------------------------ */}
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h2 className="text-sm font-semibold text-fg">Plan</h2>
          <p className="mt-1 text-xs text-muted">
            {data.subscription.plan === "grow" ? (
              <>
                On <span className="font-semibold text-fg">Grow</span>, free forever. 25 active
                listings, full storefront, order inbox.
              </>
            ) : (
              <>
                On <span className="font-semibold text-fg">{data.subscription.plan}</span>
                {data.subscription.renewsAt !== null && data.subscription.renewsAt !== undefined
                  ? `, renews ${new Date(data.subscription.renewsAt).toLocaleDateString("en-KE")}`
                  : ""}
                .
              </>
            )}
          </p>

          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {(["grow", "commerce", "business"] as const).map((tier) => (
              <button
                key={tier}
                type="button"
                onClick={() => setPlanChoice(tier)}
                className={
                  "rounded-token border px-4 py-3 text-left transition " +
                  (planChoice === tier
                    ? "border-accent bg-surface-alt"
                    : "border-border bg-surface hover:border-accent/40")
                }
              >
                <p className="text-sm font-semibold text-fg">{plans[tier].label}</p>
                <p className="mt-1 text-xs tabular-nums text-muted">
                  {tier === "grow"
                    ? "Free"
                    : `${kes(tier === "commerce" ? 999 : 2999)} / month`}
                </p>
              </button>
            ))}
          </div>

          {planChoice !== "grow" && (
            <div className="mt-3 flex gap-2">
              {(["monthly", "weekly", "quarterly"] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPeriodChoice(p)}
                  className={
                    "rounded-token border px-3 py-1.5 text-xs font-medium capitalize transition " +
                    (periodChoice === p
                      ? "border-accent bg-surface-alt text-fg"
                      : "border-border bg-surface text-muted")
                  }
                >
                  {p}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            disabled={busy === "plan"}
            onClick={() => void changePlan()}
            className="mt-4 w-full rounded-token bg-accent py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
          >
            {busy === "plan" ? "Updating..." : "Switch plan"}
          </button>
          <p className="mt-2 text-[11px] text-muted">
            Downgrades never pause your storefront or delete your catalog. Only boost and usage
            tooling pauses when something is unpaid.
          </p>
        </section>

        {/* ------------------------- usage ledger --------------------------- */}
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h2 className="text-sm font-semibold text-fg">This month, transparently</h2>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <Stat label="Recorded sales" value={String(data.usage.units)} />
            <Stat label="Recorded value" value={kes(data.usage.recordedKes)} />
            <Stat
              label="Fee accrued"
              value={
                data.usage.currentFeeKes > 0 ? kes(data.usage.currentFeeKes) : "KSh 0"
              }
            />
          </div>
          <p className="mt-3 text-[11px] text-muted">
            Sales you record here (storefront orders + the sale recorder) build this ledger. It is a
            record, not a charge; corrections happen on invoices, never in the record.
          </p>
        </section>

        {/* ---------------------------- invoices ---------------------------- */}
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h2 className="text-sm font-semibold text-fg">Usage invoices</h2>
          {data.invoices.length === 0 ? (
            <p className="mt-3 text-xs text-muted">No invoices yet.</p>
          ) : (
            <div className="mt-3 space-y-3">
              {data.invoices.map((inv) => (
                <div key={inv.id} className="rounded-token border border-border p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold tabular-nums text-fg">
                        {kes(inv.totalKes)}
                      </p>
                      <p className="text-[11px] capitalize text-muted">
                        {inv.status} /{" "}
                        {new Date(inv.createdAt).toLocaleDateString("en-KE")}
                      </p>
                    </div>
                    {(inv.status === "draft" || inv.status === "overdue") && (
                      <button
                        type="button"
                        onClick={() => {
                          setCollectFor(collectFor === inv.id ? null : inv.id);
                        }}
                        className="rounded-token bg-accent px-3 py-1.5 text-xs font-semibold text-on-accent hover:bg-accent-hover"
                      >
                        Pay by M-Pesa
                      </button>
                    )}
                    {inv.status === "issued" && (
                      <span className="text-[11px] text-muted">Awaiting your confirmation</span>
                    )}
                    {inv.status === "paid" && (
                      <span className="text-[11px] text-muted">Settled</span>
                    )}
                  </div>
                  {collectFor === inv.id && (
                    <div className="mt-3 flex gap-2">
                      <input
                        className={inputClass}
                        placeholder="0712 345 678"
                        value={collectPhone}
                        onChange={(e) => setCollectPhone(e.target.value)}
                      />
                      <button
                        type="button"
                        disabled={busy === `collect-${inv.id}`}
                        onClick={() => void collect(inv.id)}
                        className="shrink-0 rounded-token bg-accent px-3 py-2 text-xs font-semibold text-on-accent disabled:opacity-60"
                      >
                        {busy === `collect-${inv.id}` ? "Sending..." : "Push STK"}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ------------------------------ boosts ---------------------------- */}
        <section className="rounded-token-lg border border-border bg-surface p-5 shadow-strip">
          <h2 className="text-sm font-semibold text-fg">Boosts</h2>
          <p className="mt-1 text-xs text-muted">
            Put an item in front of the storefront first for a fixed window. Underlay on every
            plan; bought and settled here.
          </p>

          <div className="mt-4 space-y-3">
            <select
              className={inputClass}
              value={boostListing}
              onChange={(e) => setBoostListing(e.target.value)}
              aria-label="Listing to boost"
            >
              <option value="">Choose an item</option>
              {listings.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title}
                </option>
              ))}
            </select>
            <div className="grid gap-2 sm:grid-cols-3">
              {Object.entries(data.packs).map(([key, pack]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setBoostPack(key)}
                  className={
                    "rounded-token border px-3 py-2 text-left text-xs transition " +
                    (boostPack === key
                      ? "border-accent bg-surface-alt"
                      : "border-border bg-surface")
                  }
                >
                  <p className="font-semibold text-fg">{kes(pack.amountKes)}</p>
                  <p className="mt-0.5 text-muted">{pack.label}</p>
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                className={inputClass}
                placeholder="M-Pesa number, e.g. 0712 345 678"
                value={boostPhone}
                onChange={(e) => setBoostPhone(e.target.value)}
              />
              <button
                type="button"
                disabled={busy === "boost" || boostListing === "" || boostPhone === ""}
                onClick={() => void boost()}
                className="shrink-0 rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
              >
                {busy === "boost" ? "Processing..." : "Boost"}
              </button>
            </div>
          </div>

          {data.boosts.length > 0 && (
            <ul className="mt-4 space-y-2 border-t border-border pt-3">
              {data.boosts.map((b) => (
                <li key={b.id} className="flex items-center justify-between text-xs">
                  <span className="text-muted">
                    {data.packs[b.packKey]?.label ?? b.packKey}
                    {b.expiresAt !== null
                      ? ` / ends ${new Date(b.expiresAt).toLocaleDateString("en-KE")}`
                      : ""}
                  </span>
                  <span className="tabular-nums text-fg">
                    {kes(b.amountKes)} / {b.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }): React.ReactElement {
  return (
    <div className="rounded-token bg-surface-alt px-4 py-3">
      <p className="text-[11px] font-medium text-muted">{label}</p>
      <p className="mt-1 text-lg font-semibold tabular-nums text-fg">{value}</p>
    </div>
  );
}

export function PageHeader(): React.ReactElement {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
      <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <Link to="/dashboard" className="text-sm font-semibold text-fg">
            StoreSnap
          </Link>
          <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
            Billing
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <Link
            to="/dashboard/orders"
            className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg"
          >
            Order inbox
          </Link>
          <Link
            to="/dashboard/catalog"
            className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg"
          >
            Catalog
          </Link>
        </div>
      </div>
    </header>
  );
}
