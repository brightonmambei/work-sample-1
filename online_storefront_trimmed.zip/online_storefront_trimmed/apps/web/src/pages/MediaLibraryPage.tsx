/**
 * Media library (seller): every upload the store owns, straight from the
 * storage ledger. Deletion here is a hard delete: the row and the bucket
 * objects (original + WebP variants) both go. Media still attached to live
 * items is refused server side so storefronts never show broken images.
 */
import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiClientError } from "../lib/api.js";
import { useAuthStore } from "../lib/auth.js";
import { IconSpinner, IconTrash, IconUpload, IconImage } from "../components/icons.js";

interface MediaItem {
  id: string;
  key: string;
  url: string;
  cardUrl: string;
  mime: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  status: "pending" | "ready" | "failed" | string;
  createdAt: string;
  attachedTo: Array<{ listingId: string; code: string; title: string; status: string }>;
}

interface LibraryResponse {
  items: MediaItem[];
  pagination: { page: number; limit: number; total: number; totalPages: number };
  summary: { totalObjects: number; orphanCount: number; totalBytes: number };
}

type Filter = "all" | "attached" | "orphan";

const fmtBytes = (n: number): string => {
  if (n >= 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  if (n >= 1024) return `${Math.round(n / 1024)} KB`;
  return `${n} B`;
};

export function MediaLibraryPage(): React.ReactElement {
  const signOut = useAuthStore((s) => s.signOut);
  const navigate = useNavigate();

  const [data, setData] = useState<LibraryResponse | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [page, setPage] = useState(1);
  const [bucketObjects, setBucketObjects] = useState<Array<{ key: string; bytes: number }> | null>(null);
  const [confirming, setConfirming] = useState<MediaItem | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback((f: Filter, p: number) => {
    setLoading(true);
    void api
      .get<LibraryResponse>(`/seller/media?filter=${f}&page=${p}&limit=24`)
      .then((res) => setData(res))
      .catch((err) =>
        setError(err instanceof ApiClientError ? err.message : "Could not load your media."),
      )
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load(filter, page);
  }, [filter, page, load]);

  async function onSignOut(): Promise<void> {
    await signOut();
    navigate("/", { replace: true });
  }

  async function onDelete(item: MediaItem): Promise<void> {
    setBusy(true);
    setError(null);
    try {
      await api.del(`/seller/media/${item.id}`);
      setConfirming(null);
      setNotice("Photo deleted from your library and storage.");
      load(filter, page);
    } catch (err) {
      setConfirming(null);
      setError(err instanceof ApiClientError ? err.message : "Could not delete that photo.");
    } finally {
      setBusy(false);
    }
  }

  async function onGc(): Promise<void> {
    setBusy(true);
    setError(null);
    try {
      const res = await api.post<{ deletedUploads: number; deletedObjects: number }>("/seller/media/gc");
      setNotice(
        `Cleaned ${res.deletedUploads} unattached upload${res.deletedUploads === 1 ? "" : "s"} (${res.deletedObjects} files removed from storage).`,
      );
      load(filter, page);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Cleanup failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onToggleBucket(): Promise<void> {
    if (bucketObjects !== null) {
      setBucketObjects(null);
      return;
    }
    setBusy(true);
    try {
      const res = await api.get<{ bucket: string; objects: Array<{ key: string; bytes: number }> }>(
        "/seller/media/bucket",
      );
      setBucketObjects(res.objects);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Could not list stored files.");
    } finally {
      setBusy(false);
    }
  }

  const summary = data?.summary;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="text-sm font-semibold text-fg">
              StoreSnap
            </Link>
            <span className="rounded-token bg-surface-alt px-2 py-0.5 text-[11px] font-medium text-muted">
              Media
            </span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Link to="/dashboard/catalog" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Catalog
            </Link>
            <Link to="/dashboard/orders" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Orders
            </Link>
            <Link to="/dashboard" className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg">
              Store settings
            </Link>
            <button
              type="button"
              onClick={onSignOut}
              className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg hover:border-fg/20"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-lg font-semibold text-fg">Media library</h1>
            <p className="mt-1 text-sm text-muted">
              {summary
                ? `${summary.totalObjects} photo${summary.totalObjects === 1 ? "" : "s"} in storage, ${fmtBytes(summary.totalBytes)} total. Deleting a photo here also removes it from storage permanently.`
                : "Loading your media."}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {summary !== undefined && summary.orphanCount > 0 && (
              <button
                type="button"
                onClick={onGc}
                disabled={busy}
                className="rounded-token border border-warning/40 bg-warning/10 px-3 py-2 text-xs font-semibold text-fg disabled:opacity-50"
              >
                Clean up {summary.orphanCount} unattached
              </button>
            )}
            <button
              type="button"
              onClick={onToggleBucket}
              disabled={busy}
              className="rounded-token border border-border bg-surface px-3 py-2 text-xs font-medium text-fg disabled:opacity-50"
            >
              {bucketObjects !== null ? "Hide stored files" : "List stored files"}
            </button>
            <Link
              to="/dashboard/catalog/new"
              className="rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent transition hover:bg-accent-hover"
            >
              Add item
            </Link>
          </div>
        </div>

        {error !== null && (
          <div className="mb-4 rounded-token border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-fg">
            {error}
          </div>
        )}
        {notice !== null && (
          <div className="mb-4 rounded-token border border-success/30 bg-success/10 px-4 py-3 text-sm text-fg">
            {notice}
          </div>
        )}

        <div className="mb-4 flex gap-2">
          {(
            [
              ["all", "All"],
              ["attached", "Used by items"],
              ["orphan", "Not attached"],
            ] as Array<[Filter, string]>
          ).map(([value, label]) => (
            <button
              key={value}
              type="button"
              onClick={() => {
                setFilter(value);
                setPage(1);
              }}
              className={
                "rounded-token px-3 py-1.5 text-xs font-semibold transition " +
                (filter === value
                  ? "bg-surface-alt text-fg shadow-strip"
                  : "text-muted hover:text-fg")
              }
            >
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-16 text-muted">
            <IconSpinner size={24} />
          </div>
        ) : data !== null && data.items.length > 0 ? (
          <>
            <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {data.items.map((m) => (
                <li key={m.id} className="overflow-hidden rounded-token-lg border border-border bg-surface">
                  <div className="relative aspect-square bg-surface-alt">
                    {m.status === "ready" && m.url !== "" ? (
                      <img
                        src={m.url}
                        alt={m.key}
                        loading="lazy"
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted">
                        <IconImage size={22} />
                        <span className="text-[11px]">
                          {m.status === "pending" ? "Processing" : m.status === "failed" ? "Failed" : "No preview"}
                        </span>
                      </div>
                    )}
                    {m.attachedTo.length > 0 && (
                      <span className="absolute left-2 top-2 rounded-token bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-on-accent">
                        Used by {m.attachedTo.length}
                      </span>
                    )}
                  </div>
                  <div className="space-y-1.5 p-3">
                    <p className="truncate text-[11px] font-medium text-fg" title={m.key}>
                      {m.width !== null ? `${m.width} x ${m.height ?? "?"}` : m.mime}
                    </p>
                    <p className="text-[11px] text-muted">{fmtBytes(m.sizeBytes)}</p>
                    {m.attachedTo.length > 0 ? (
                      <p className="truncate text-[11px] text-muted" title={m.attachedTo.map((a) => a.title).join(", ")}>
                        {m.attachedTo.map((a) => a.title).join(", ")}
                      </p>
                    ) : (
                      <p className="text-[11px] italic text-muted">Not attached to any item</p>
                    )}
                    <div className="flex gap-2 pt-1">
                      {m.status === "ready" && m.cardUrl !== "" && (
                        <a
                          href={m.cardUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-token border border-border px-2 py-1 text-[11px] font-medium text-fg hover:border-accent/40"
                        >
                          View
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => setConfirming(m)}
                        className="rounded-token border border-danger/30 px-2 py-1 text-[11px] font-medium text-danger hover:bg-danger/10"
                        aria-label={`Delete photo ${m.key}`}
                      >
                        <IconTrash size={14} />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            {data.pagination.totalPages > 1 && (
              <div className="mt-6 flex items-center justify-center gap-3 text-xs text-muted">
                <button
                  type="button"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                  className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg disabled:opacity-40"
                >
                  Previous
                </button>
                <span>
                  Page {data.pagination.page} of {data.pagination.totalPages} ({data.pagination.total} photos)
                </span>
                <button
                  type="button"
                  disabled={page >= data.pagination.totalPages}
                  onClick={() => setPage((p) => p + 1)}
                  className="rounded-token border border-border bg-surface px-3 py-1.5 font-medium text-fg disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="rounded-token-lg border border-border bg-surface px-6 py-16 text-center">
            <IconUpload size={28} className="mx-auto text-muted" />
            <p className="mt-3 text-sm text-muted">No photos here yet.</p>
            <Link
              to="/dashboard/catalog/new"
              className="mt-4 inline-block rounded-token bg-accent px-4 py-2 text-xs font-semibold text-on-accent"
            >
              Add your first item
            </Link>
          </div>
        )}

        {bucketObjects !== null && (
          <section className="mt-8 rounded-token-lg border border-border bg-surface p-5">
            <h2 className="text-sm font-semibold text-fg">Stored files ({bucketObjects.length})</h2>
            <p className="mt-1 text-[11px] text-muted">
              Raw storage contents for your store: originals plus generated WebP sizes and status posters.
            </p>
            <ul className="mt-3 divide-y divide-border text-[11px]">
              {bucketObjects.map((o) => (
                <li key={o.key} className="flex items-center justify-between gap-3 py-1.5">
                  <code className="truncate text-muted">{o.key}</code>
                  <span className="shrink-0 text-muted">{fmtBytes(o.bytes)}</span>
                </li>
              ))}
              {bucketObjects.length === 0 && <li className="py-2 text-muted">Empty.</li>}
            </ul>
          </section>
        )}

        {confirming !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-fg/40 p-4">
            <div className="w-full max-w-sm rounded-token-lg border border-border bg-surface p-6 shadow-strip">
              <h3 className="text-sm font-semibold text-fg">Delete this photo?</h3>
              <p className="mt-2 text-xs text-muted">
                {confirming.attachedTo.length > 0
                  ? `It is attached to ${confirming.attachedTo.length} item${confirming.attachedTo.length === 1 ? "" : "s"}. The server will refuse unless those items only reference it as archived.`
                  : "It will be removed from your library and from storage permanently. This cannot be undone."}
              </p>
              <div className="mt-5 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setConfirming(null)}
                  className="rounded-token border border-border bg-surface px-3 py-1.5 text-xs font-medium text-fg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => onDelete(confirming)}
                  disabled={busy}
                  className="rounded-token bg-danger px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-50"
                >
                  {busy ? "Deleting..." : "Delete permanently"}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
