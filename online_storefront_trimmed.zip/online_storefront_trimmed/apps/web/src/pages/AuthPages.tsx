import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuthStore } from "../lib/auth.js";
import { ApiClientError } from "../lib/api.js";
import { IconLock, IconStore } from "../components/icons.js";

export function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <span className="flex h-10 w-10 items-center justify-center rounded-token bg-accent text-on-accent">
            <IconStore size={19} />
          </span>
          <h1 className="text-base font-semibold text-fg">{title}</h1>
          <p className="text-xs text-muted">{subtitle}</p>
        </div>
        <div className="rounded-token-lg border border-border bg-surface p-6 shadow-strip">
          {children}
        </div>
        <p className="mt-4 text-center text-[11px] leading-relaxed text-muted">
          By continuing you agree to the StoreSnap seller terms. Payment
          collection stays with you; StoreSnap handles the storefront.
        </p>
      </div>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}): React.ReactElement {
  return (
    <label className="block">
      <span className="mb-1.5 flex items-baseline justify-between">
        <span className="text-xs font-semibold text-fg">{label}</span>
      </span>
      {children}
      {hint !== undefined && <span className="mt-1 block text-[11px] text-muted">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "w-full rounded-token border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted/70 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25";

export function AuthFooter({
  text,
  to,
  linkText,
}: {
  text: string;
  to: string;
  linkText: string;
}): React.ReactElement {
  return (
    <p className="mt-5 text-center text-xs text-muted">
      {text}{" "}
      <Link to={to} className="font-semibold text-accent hover:text-accent-hover">
        {linkText}
      </Link>
    </p>
  );
}

export function FormError({ message }: { message: string | null }): React.ReactElement | null {
  if (message === null) return null;
  return (
    <div role="alert" className="rounded-token border border-danger/30 bg-danger/10 px-3 py-2 text-xs font-medium text-danger">
      {message}
    </div>
  );
}

export function Spinner({ label = "Working" }: { label?: string }): React.ReactElement {
  return (
    <span className="inline-flex items-center gap-2 text-xs font-medium text-muted">
      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-accent border-t-transparent" />
      {label}
    </span>
  );
}

export function LoginPage(): React.ReactElement {
  const login = useAuthStore((s) => s.login);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(email.trim(), password);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Sign in failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell title="Sign in to StoreSnap" subtitle="Manage your storefront, catalog, and orders.">
      <form onSubmit={onSubmit} className="space-y-4">
        <FormError message={error} />
        <Field label="Email">
          <input
            type="email"
            required
            autoComplete="email"
            className={inputClass}
            placeholder="you@example.co.ke"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            required
            autoComplete="current-password"
            className={inputClass}
            placeholder="Your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        <button
          type="submit"
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-token bg-accent py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
        >
          <IconLock size={14} />
          {busy ? "Signing in" : "Sign in"}
        </button>
        {busy && <Spinner />}
      </form>
      <AuthFooter text="New to StoreSnap?" to="/register" linkText="Create a seller account" />
    </AuthShell>
  );
}

export function RegisterPage(): React.ReactElement {
  const register = useAuthStore((s) => s.register);
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await register({ name: name.trim(), email: email.trim(), password });
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Registration failed. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthShell
      title="Create your seller account"
      subtitle="Your storefront, your catalog, your customers."
    >
      <form onSubmit={onSubmit} className="space-y-4">
        <FormError message={error} />
        <Field label="Your name">
          <input
            type="text"
            required
            minLength={2}
            autoComplete="name"
            className={inputClass}
            placeholder="Wanjiku Kimani"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <Field label="Email">
          <input
            type="email"
            required
            autoComplete="email"
            className={inputClass}
            placeholder="you@example.co.ke"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Field>
        <Field label="Password" hint="8 characters or more.">
          <input
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            className={inputClass}
            placeholder="Create a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        <button
          type="submit"
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-token bg-accent py-2.5 text-sm font-semibold text-on-accent transition hover:bg-accent-hover disabled:opacity-60"
        >
          {busy ? "Creating account" : "Create account"}
        </button>
        {busy && <Spinner label="Setting things up" />}
      </form>
      <AuthFooter text="Already selling with us?" to="/login" linkText="Sign in" />
    </AuthShell>
  );
}
