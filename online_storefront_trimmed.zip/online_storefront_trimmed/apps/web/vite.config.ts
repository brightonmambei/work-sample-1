import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        // Host dev proxies to the API on localhost; in compose, VITE_API_PROXY
        // points at the api service name (localhost is the web container itself).
        target: process.env.VITE_API_PROXY ?? "http://localhost:4000",
        changeOrigin: true,
      },
      // Mirrors the prod nginx rule: canonical share links are scraped
      // server-side, so /p/{code} must reach the API (bot OG HTML, human 302)
      // instead of falling through to the SPA shell.
      "/p": {
        target: process.env.VITE_API_PROXY ?? "http://localhost:4000",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/p/, "/api/v1/p"),
      },
      // Media renditions when MEDIA_SERVE_MODE=proxy: same-origin image URLs.
      "/media": {
        target: process.env.VITE_API_PROXY ?? "http://localhost:4000",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/media/, "/api/v1/media"),
      },
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  build: {
    target: "es2020",
    sourcemap: true,
  },
});
