-- Phase 5 collection drop links (AGENTS.md section 8): a curated set of
-- listings with ONE shareable link, so twenty items travel through a group
-- chat as a single post. Collections live in the catalog schema and reuse the
-- share module: share_links now points at an item OR a collection.

CREATE TYPE "catalog"."CollectionStatus" AS ENUM ('active', 'archived');

CREATE TABLE "catalog"."collections" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "status" "catalog"."CollectionStatus" NOT NULL DEFAULT 'active',
    "cardKey" TEXT,
    "ogVersion" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "collections_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "catalog"."collection_items" (
    "id" TEXT NOT NULL,
    "collectionId" TEXT NOT NULL,
    "listingId" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "collection_items_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "collections_code_key" ON "catalog"."collections"("code");
CREATE INDEX "collections_storeId_status_idx" ON "catalog"."collections"("storeId", "status");
CREATE UNIQUE INDEX "collection_items_collectionId_listingId_key" ON "catalog"."collection_items"("collectionId", "listingId");
CREATE INDEX "collection_items_listingId_idx" ON "catalog"."collection_items"("listingId");

ALTER TABLE "catalog"."collections" ADD CONSTRAINT "collections_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES "stores"."stores"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "catalog"."collection_items" ADD CONSTRAINT "collection_items_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES "catalog"."collections"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "catalog"."collection_items" ADD CONSTRAINT "collection_items_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- share_links: subject is now item XOR collection.
ALTER TABLE "share"."share_links" DROP CONSTRAINT "share_links_listingId_fkey";
ALTER TABLE "share"."share_links" ALTER COLUMN "listingId" DROP NOT NULL;
ALTER TABLE "share"."share_links" ADD COLUMN "collectionId" TEXT;
ALTER TABLE "share"."share_links" ADD CONSTRAINT "share_links_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "share"."share_links" ADD CONSTRAINT "share_links_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES "catalog"."collections"("id") ON DELETE CASCADE ON UPDATE CASCADE;
