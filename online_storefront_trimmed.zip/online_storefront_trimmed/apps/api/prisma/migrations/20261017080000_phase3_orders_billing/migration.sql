-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "billing";

-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "orders";

-- CreateEnum
CREATE TYPE "orders"."OrderFulfillment" AS ENUM ('pickup', 'delivery');

-- CreateEnum
CREATE TYPE "orders"."OrderStatus" AS ENUM ('pending', 'confirmed', 'out', 'fulfilled', 'cancelled');

-- CreateEnum
CREATE TYPE "orders"."OrderSource" AS ENUM ('web', 'whatsapp', 'self_report');

-- CreateTable
CREATE TABLE "orders"."orders" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "buyerName" TEXT NOT NULL,
    "buyerPhone" TEXT NOT NULL,
    "buyerLocation" TEXT,
    "fulfillment" "orders"."OrderFulfillment" NOT NULL DEFAULT 'pickup',
    "paymentMethod" TEXT NOT NULL,
    "status" "orders"."OrderStatus" NOT NULL DEFAULT 'pending',
    "source" "orders"."OrderSource" NOT NULL DEFAULT 'web',
    "buyerToken" TEXT NOT NULL,
    "whatsappRef" TEXT,
    "note" TEXT,
    "totalKes" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "orders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "orders"."order_items" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "listingId" TEXT,
    "title" TEXT NOT NULL,
    "priceKes" INTEGER NOT NULL,
    "compareAtKes" INTEGER,
    "condition" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "size" TEXT,
    "color" TEXT,

    CONSTRAINT "order_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "orders"."holds" (
    "id" TEXT NOT NULL,
    "listingId" TEXT NOT NULL,
    "orderId" TEXT,
    "quantity" INTEGER NOT NULL,
    "size" TEXT,
    "color" TEXT,
    "buyerToken" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "holds_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."usage_events" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "orderId" TEXT,
    "type" TEXT NOT NULL,
    "amountKes" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "usage_events_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "orders_buyerToken_key" ON "orders"."orders"("buyerToken");

-- CreateIndex
CREATE INDEX "orders_storeId_status_idx" ON "orders"."orders"("storeId", "status");

-- CreateIndex
CREATE INDEX "orders_storeId_createdAt_idx" ON "orders"."orders"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "order_items_orderId_idx" ON "orders"."order_items"("orderId");

-- CreateIndex
CREATE INDEX "order_items_listingId_idx" ON "orders"."order_items"("listingId");

-- CreateIndex
CREATE INDEX "holds_listingId_expiresAt_idx" ON "orders"."holds"("listingId", "expiresAt");

-- CreateIndex
CREATE INDEX "holds_buyerToken_idx" ON "orders"."holds"("buyerToken");

-- CreateIndex
CREATE INDEX "usage_events_storeId_createdAt_idx" ON "billing"."usage_events"("storeId", "createdAt");

-- AddForeignKey
ALTER TABLE "orders"."orders" ADD CONSTRAINT "orders_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES "stores"."stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders"."order_items" ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"."orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders"."order_items" ADD CONSTRAINT "order_items_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders"."holds" ADD CONSTRAINT "holds_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders"."holds" ADD CONSTRAINT "holds_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"."orders"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."usage_events" ADD CONSTRAINT "usage_events_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"."orders"("id") ON DELETE SET NULL ON UPDATE CASCADE;

