-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "catalog";

-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "media";

-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "share";

-- CreateEnum
CREATE TYPE "catalog"."ListingStatus" AS ENUM ('draft', 'active', 'paused', 'sold_out', 'archived');

-- CreateEnum
CREATE TYPE "catalog"."ListingCondition" AS ENUM ('new', 'thrift');

-- CreateEnum
CREATE TYPE "media"."UploadStatus" AS ENUM ('pending', 'ready', 'failed');

-- CreateTable
CREATE TABLE "catalog"."categories" (
    "id" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "catalog"."listings" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "priceKes" INTEGER NOT NULL,
    "compareAtKes" INTEGER,
    "condition" "catalog"."ListingCondition" NOT NULL,
    "conditionGrade" INTEGER,
    "stock" INTEGER NOT NULL DEFAULT 1,
    "status" "catalog"."ListingStatus" NOT NULL DEFAULT 'draft',
    "badgeText" TEXT,
    "sizes" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "colors" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "coverKey" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "listings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "catalog"."listing_media" (
    "id" TEXT NOT NULL,
    "listingId" TEXT NOT NULL,
    "uploadId" TEXT NOT NULL,
    "thumbKey" TEXT,
    "cardKey" TEXT,
    "fullKey" TEXT,
    "width" INTEGER,
    "height" INTEGER,
    "isHero" BOOLEAN NOT NULL DEFAULT false,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "listing_media_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "media"."uploads" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "ownerUserId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "mime" TEXT NOT NULL,
    "sizeBytes" INTEGER NOT NULL,
    "width" INTEGER,
    "height" INTEGER,
    "status" "media"."UploadStatus" NOT NULL DEFAULT 'pending',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "uploads_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "share"."share_links" (
    "id" TEXT NOT NULL,
    "listingId" TEXT NOT NULL,
    "code" TEXT NOT NULL,

    CONSTRAINT "share_links_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "share"."share_events" (
    "id" TEXT NOT NULL,
    "shareLinkId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "channel" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "share_events_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "categories_slug_key" ON "catalog"."categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "listings_code_key" ON "catalog"."listings"("code");

-- CreateIndex
CREATE INDEX "listings_storeId_status_idx" ON "catalog"."listings"("storeId", "status");

-- CreateIndex
CREATE INDEX "listings_storeId_createdAt_idx" ON "catalog"."listings"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "listing_media_listingId_idx" ON "catalog"."listing_media"("listingId");

-- CreateIndex
CREATE UNIQUE INDEX "uploads_key_key" ON "media"."uploads"("key");

-- CreateIndex
CREATE INDEX "uploads_storeId_createdAt_idx" ON "media"."uploads"("storeId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "share_links_code_key" ON "share"."share_links"("code");

-- CreateIndex
CREATE INDEX "share_events_shareLinkId_type_idx" ON "share"."share_events"("shareLinkId", "type");

-- AddForeignKey
ALTER TABLE "catalog"."listings" ADD CONSTRAINT "listings_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES "stores"."stores"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "catalog"."listings" ADD CONSTRAINT "listings_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "catalog"."categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "catalog"."listing_media" ADD CONSTRAINT "listing_media_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "catalog"."listing_media" ADD CONSTRAINT "listing_media_uploadId_fkey" FOREIGN KEY ("uploadId") REFERENCES "media"."uploads"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "share"."share_links" ADD CONSTRAINT "share_links_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "share"."share_events" ADD CONSTRAINT "share_events_shareLinkId_fkey" FOREIGN KEY ("shareLinkId") REFERENCES "share"."share_links"("id") ON DELETE CASCADE ON UPDATE CASCADE;

