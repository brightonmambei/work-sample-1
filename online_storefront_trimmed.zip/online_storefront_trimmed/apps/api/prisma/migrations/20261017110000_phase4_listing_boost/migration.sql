-- AlterTable
ALTER TABLE "catalog"."listings" ADD COLUMN     "boostedUntil" TIMESTAMP(3);

