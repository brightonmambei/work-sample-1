-- Share kit (Phase 5): manual unfurl refresh. WhatsApp caches og:image hard,
-- so the bot card URL carries a version suffix; this column lets a seller bump
-- it on demand (content edits bump it through updatedAt automatically).
ALTER TABLE "catalog"."listings" ADD COLUMN     "ogVersion" TIMESTAMP(3);
