-- CreateEnum
CREATE TYPE "billing"."SubscriptionStatus" AS ENUM ('trialing', 'active', 'past_due', 'cancelled');

-- CreateEnum
CREATE TYPE "billing"."SubscriptionPeriod" AS ENUM ('monthly', 'weekly', 'quarterly');

-- CreateEnum
CREATE TYPE "billing"."InvoiceStatus" AS ENUM ('draft', 'issued', 'paid', 'overdue', 'void');

-- CreateEnum
CREATE TYPE "billing"."PaymentStatus" AS ENUM ('pending', 'success', 'failed');

-- CreateEnum
CREATE TYPE "billing"."BoostPackKey" AS ENUM ('feature_48h', 'feature_72h', 'popup_7d');

-- CreateTable
CREATE TABLE "billing"."subscriptions" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "plan" TEXT NOT NULL,
    "status" "billing"."SubscriptionStatus" NOT NULL DEFAULT 'trialing',
    "period" "billing"."SubscriptionPeriod" NOT NULL DEFAULT 'monthly',
    "priceKes" INTEGER NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "renewsAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "subscriptions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."usage_periods" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "periodStart" TIMESTAMP(3) NOT NULL,
    "periodEnd" TIMESTAMP(3) NOT NULL,
    "units" INTEGER NOT NULL DEFAULT 0,
    "recordedKes" INTEGER NOT NULL DEFAULT 0,
    "feeKes" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "usage_periods_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."usage_invoices" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "periodId" TEXT,
    "status" "billing"."InvoiceStatus" NOT NULL DEFAULT 'draft',
    "totalKes" INTEGER NOT NULL,
    "lines" JSONB NOT NULL,
    "dueAt" TIMESTAMP(3),
    "issuedAt" TIMESTAMP(3),
    "paidAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "usage_invoices_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."payments" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "invoiceId" TEXT,
    "subscriptionId" TEXT,
    "purpose" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "amountKes" INTEGER NOT NULL,
    "status" "billing"."PaymentStatus" NOT NULL DEFAULT 'pending',
    "checkoutRequestId" TEXT NOT NULL,
    "merchantRequestId" TEXT,
    "mpesaReceiptNumber" TEXT,
    "resultDesc" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "boostPurchaseId" TEXT,

    CONSTRAINT "payments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."boost_purchases" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "listingId" TEXT NOT NULL,
    "packKey" "billing"."BoostPackKey" NOT NULL,
    "amountKes" INTEGER NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "startsAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "boost_purchases_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "billing"."rate_card" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "feeBps" INTEGER NOT NULL,
    "minFeeKes" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "updatedBy" TEXT,

    CONSTRAINT "rate_card_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "subscriptions_storeId_key" ON "billing"."subscriptions"("storeId");

-- CreateIndex
CREATE UNIQUE INDEX "usage_periods_storeId_periodStart_key" ON "billing"."usage_periods"("storeId", "periodStart");

-- CreateIndex
CREATE INDEX "usage_invoices_storeId_status_idx" ON "billing"."usage_invoices"("storeId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "payments_checkoutRequestId_key" ON "billing"."payments"("checkoutRequestId");

-- CreateIndex
CREATE UNIQUE INDEX "payments_boostPurchaseId_key" ON "billing"."payments"("boostPurchaseId");

-- CreateIndex
CREATE INDEX "payments_storeId_createdAt_idx" ON "billing"."payments"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "boost_purchases_storeId_createdAt_idx" ON "billing"."boost_purchases"("storeId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "rate_card_key_key" ON "billing"."rate_card"("key");

-- AddForeignKey
ALTER TABLE "billing"."subscriptions" ADD CONSTRAINT "subscriptions_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES "stores"."stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."usage_invoices" ADD CONSTRAINT "usage_invoices_periodId_fkey" FOREIGN KEY ("periodId") REFERENCES "billing"."usage_periods"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."payments" ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "billing"."usage_invoices"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."payments" ADD CONSTRAINT "payments_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "billing"."subscriptions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."payments" ADD CONSTRAINT "payments_boostPurchaseId_fkey" FOREIGN KEY ("boostPurchaseId") REFERENCES "billing"."boost_purchases"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billing"."boost_purchases" ADD CONSTRAINT "boost_purchases_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES "catalog"."listings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

