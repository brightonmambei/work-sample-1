-- Theme editor (Phase 5): draft/preview/publish with one-step rollback.
-- themeDraft holds unpublished tokens; themePrevious keeps the theme that was
-- live before the last publish so a seller can undo it.
ALTER TABLE "stores"."stores" ADD COLUMN     "themeDraft" JSONB,
ADD COLUMN     "themePrevious" JSONB;
