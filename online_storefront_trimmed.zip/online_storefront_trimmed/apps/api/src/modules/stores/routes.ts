import express from "express";
import { createStoreSchema, slugCheckSchema, updateStoreSchema } from "./schemas.js";
import { storesService } from "./service.js";
import { requireAuth } from "../../middleware/auth.js";
import { ok } from "../../middleware/error.js";
import { validateBody } from "../../middleware/validate.js";
import { themeSpecSchema, type ThemeSpec } from "@storesnap/shared";

/** Public store profile routes (Phase 2 storefront bootstrap). */
export const storesRouter = express.Router();

storesRouter.get(
  "/slug-check",
  validateQueryWrapper,
  async (req, res, next) => {
    try {
      const { slug } = slugCheckSchema.parse(req.query);
      const available = await storesService.slugAvailable(slug);
      ok(res, { slug: available ? slug : null, available });
    } catch (err) {
      next(err);
    }
  },
);

storesRouter.get("/:slug", async (req, res, next) => {
  try {
    const store = await storesService.getBySlug(req.params.slug ?? "");
    ok(res, { store });
  } catch (err) {
    next(err);
  }
});

/** Seller store management (one store per seller in Phase 1). */
export const sellerStoreRouter = express.Router();

sellerStoreRouter.get("/", requireAuth, async (req, res, next) => {
  try {
    ok(res, { store: await storesService.getByOwner(req.auth!.userId) });
  } catch (err) {
    next(err);
  }
});

/* ------------------------- theme editor (Phase 5) -------------------------
 * Draft, preview, publish, rollback. The storefront only ever renders the
 * published theme unless the owner asks for a draft preview.
 */

sellerStoreRouter.patch(
  "/theme",
  requireAuth,
  validateBody(themeSpecSchema),
  async (req, res, next) => {
    try {
      const store = await storesService.saveThemeDraft(
        req.auth!.userId,
        req.body as ThemeSpec,
      );
      ok(res, { store });
    } catch (err) {
      next(err);
    }
  },
);

sellerStoreRouter.post("/theme/publish", requireAuth, async (req, res, next) => {
  try {
    ok(res, { store: await storesService.publishTheme(req.auth!.userId) });
  } catch (err) {
    next(err);
  }
});

sellerStoreRouter.post("/theme/discard", requireAuth, async (req, res, next) => {
  try {
    ok(res, { store: await storesService.discardThemeDraft(req.auth!.userId) });
  } catch (err) {
    next(err);
  }
});

sellerStoreRouter.post("/theme/restore", requireAuth, async (req, res, next) => {
  try {
    ok(res, { store: await storesService.restorePreviousTheme(req.auth!.userId) });
  } catch (err) {
    next(err);
  }
});

sellerStoreRouter.post(
  "/",
  requireAuth,
  validateBody(createStoreSchema),
  async (req, res, next) => {
    try {
      ok(res, { store: await storesService.createForOwner(req.auth!.userId, req.body) }, 201);
    } catch (err) {
      next(err);
    }
  },
);

sellerStoreRouter.patch(
  "/",
  requireAuth,
  validateBody(updateStoreSchema),
  async (req, res, next) => {
    try {
      ok(res, { store: await storesService.updateForOwner(req.auth!.userId, req.body) });
    } catch (err) {
      next(err);
    }
  },
);

/** tiny wrapper to surface slug validation errors consistently */
function validateQueryWrapper(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
): void {
  const parsed = slugCheckSchema.safeParse(req.query);
  if (!parsed.success) {
    res.status(422).json({
      ok: false as const,
      error: { code: "VALIDATION", message: "Provide slug as 3-32 url-safe characters." },
    });
    return;
  }
  next();
}
