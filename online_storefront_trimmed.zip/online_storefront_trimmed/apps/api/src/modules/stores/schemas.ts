import { z } from "zod";
import { themeSpecSchema } from "@storesnap/shared";

export const createStoreSchema = z.object({
  name: z.string().trim().min(2, "Store name is too short.").max(60),
  slug: z.string().trim().min(3).max(32),
  tagline: z.string().trim().max(90).optional(),
  whatsappNumber: z
    .string()
    .trim()
    .regex(/^\+?[0-9]{9,14}$/, "Use format 2547xxxxxxxx.")
    .optional(),
  locationLabel: z.string().trim().max(80).optional(),
  themePreset: z.enum(["pro-light", "pro-dark"]).default("pro-light"),
});
export type CreateStoreInput = z.infer<typeof createStoreSchema>;

export const updateStoreSchema = z
  .object({
    name: z.string().trim().min(2).max(60).optional(),
    tagline: z.string().trim().max(90).optional(),
    description: z.string().trim().max(600).optional(),
    whatsappNumber: z
      .string()
      .trim()
      .regex(/^\+?[0-9]{9,14}$/, "Use format 2547xxxxxxxx.")
      .optional(),
    locationLabel: z.string().trim().max(80).optional(),
    theme: themeSpecSchema.optional(),
    onboardingStep: z.number().int().min(0).max(10).optional(),
  })
  .strict();
export type UpdateStoreInput = z.infer<typeof updateStoreSchema>;

export const slugCheckSchema = z.object({
  slug: z.string().trim().min(3).max(32),
});

export const publicStoreSchema = z.object({
  id: z.string().cuid(),
  slug: z.string(),
});
