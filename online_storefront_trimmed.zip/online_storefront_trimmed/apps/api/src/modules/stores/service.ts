import { Prisma } from "@prisma/client";
import { prisma } from "../../lib/prisma.js";
import { normaliseSlug } from "../../lib/host.js";
import { ApiError } from "../../errors.js";
import { themeSpecSchema, type ThemeSpec } from "@storesnap/shared";
import type { CreateStoreInput, UpdateStoreInput } from "./schemas.js";

export interface StorePublic {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  logoUrl: string | null;
  coverUrl: string | null;
  theme: ThemeSpec;
  whatsappNumber: string | null;
  locationLabel: string | null;
  plan: string;
  status: string;
}

/** Owner-only view: published theme plus the draft/publish workflow state. */
export interface StoreOwnerView extends StorePublic {
  themeDraft: ThemeSpec | null;
  themePrevious: ThemeSpec | null;
}

const storeSelection = {
  id: true,
  slug: true,
  name: true,
  tagline: true,
  description: true,
  logoUrl: true,
  coverUrl: true,
  theme: true,
  themeDraft: true,
  themePrevious: true,
  whatsappNumber: true,
  locationLabel: true,
  plan: true,
  status: true,
  onboardingStep: true,
  createdAt: true,
} as const;

type StoreRow = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  logoUrl: string | null;
  coverUrl: string | null;
  theme: unknown;
  themeDraft?: unknown;
  themePrevious?: unknown;
  whatsappNumber: string | null;
  locationLabel: string | null;
  plan: string;
  status: string;
};

/** A store's theme is validated data: any DB corruption snaps to a safe preset. */
function parseTheme(raw: unknown): ThemeSpec {
  const candidate = themeSpecSchema.safeParse(raw);
  if (candidate.success) return candidate.data;
  return { schemaVersion: 1, preset: "pro-light", overrides: {} };
}

function parseNullableTheme(raw: unknown): ThemeSpec | null {
  if (raw === null || raw === undefined) return null;
  const candidate = themeSpecSchema.safeParse(raw);
  return candidate.success ? candidate.data : null;
}

function toPublic(store: StoreRow): StorePublic {
  return {
    id: store.id,
    slug: store.slug,
    name: store.name,
    tagline: store.tagline,
    description: store.description,
    logoUrl: store.logoUrl,
    coverUrl: store.coverUrl,
    whatsappNumber: store.whatsappNumber,
    locationLabel: store.locationLabel,
    plan: store.plan,
    status: store.status,
    theme: parseTheme(store.theme),
  };
}

function toOwnerView(store: StoreRow): StoreOwnerView {
  return {
    ...toPublic(store),
    themeDraft: parseNullableTheme(store.themeDraft),
    themePrevious: parseNullableTheme(store.themePrevious),
  };
}

function slugOrThrow(raw: string): string {
  const slug = normaliseSlug(raw);
  if (!slug) {
    throw new ApiError(
      422,
      "SLUG_INVALID",
      "Use 3-32 lowercase letters, numbers or hyphens (no reserved words).",
    );
  }
  return slug;
}

function slugOr404(raw: string): string {
  const slug = normaliseSlug(raw);
  if (!slug) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");
  return slug;
}

function isUniqueViolation(err: unknown): boolean {
  return (
    typeof err === "object" &&
    err !== null &&
    "code" in err &&
    (err as { code?: string }).code === "P2002"
  );
}

export const storesService = {
  async slugAvailable(raw: string): Promise<boolean> {
    const slug = normaliseSlug(raw);
    if (!slug) return false;
    const found = await prisma.store.findUnique({ where: { slug }, select: { id: true } });
    return found === null;
  },

  async createForOwner(ownerId: string, input: CreateStoreInput): Promise<StorePublic> {
    const slug = slugOrThrow(input.slug);

    const existing = await prisma.store.findUnique({
      where: { ownerId },
      select: { id: true },
    });
    if (existing) {
      throw new ApiError(409, "STORE_EXISTS", "You already have a store.");
    }

    const slugTaken = await prisma.store.findUnique({
      where: { slug },
      select: { id: true },
    });
    if (slugTaken) {
      throw new ApiError(409, "SLUG_TAKEN", "That store address is taken.");
    }

    const theme: ThemeSpec = { schemaVersion: 1, preset: input.themePreset, overrides: {} };

    try {
      const store = await prisma.store.create({
        data: {
          ownerId,
          slug,
          name: input.name,
          tagline: input.tagline ?? null,
          whatsappNumber: input.whatsappNumber ?? null,
          locationLabel: input.locationLabel ?? null,
          theme,
          onboardingStep: 1,
        },
      });
      return toOwnerView(store);
    } catch (err) {
      // Unique-constraint race: two sellers claimed a slug concurrently.
      if (isUniqueViolation(err)) {
        throw new ApiError(409, "SLUG_TAKEN", "That store address is taken.");
      }
      throw err;
    }
  },

  async getByOwner(ownerId: string): Promise<StoreOwnerView | null> {
    const store = await prisma.store.findUnique({
      where: { ownerId },
      select: storeSelection,
    });
    return store ? toOwnerView(store) : null;
  },

  /** Published theme only: the draft must never leak to a public page. */
  async getPublishedThemeForOwner(ownerId: string): Promise<ThemeSpec | null> {
    const store = await prisma.store.findUnique({
      where: { ownerId },
      select: { theme: true, themeDraft: true },
    });
    return store ? parseTheme(store.theme) : null;
  },

  async updateForOwner(ownerId: string, patch: UpdateStoreInput): Promise<StoreOwnerView> {
    const store = await prisma.store.findUnique({
      where: { ownerId },
      select: { id: true },
    });
    if (!store) {
      throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    }

    const updated = await prisma.store.update({
      where: { id: store.id },
      data: {
        ...(patch.name !== undefined ? { name: patch.name } : {}),
        ...(patch.tagline !== undefined ? { tagline: patch.tagline } : {}),
        ...(patch.description !== undefined ? { description: patch.description } : {}),
        ...(patch.whatsappNumber !== undefined ? { whatsappNumber: patch.whatsappNumber } : {}),
        ...(patch.locationLabel !== undefined ? { locationLabel: patch.locationLabel } : {}),
        ...(patch.theme !== undefined ? { theme: patch.theme } : {}),
        ...(patch.onboardingStep !== undefined ? { onboardingStep: patch.onboardingStep } : {}),
      },
      select: storeSelection,
    });
    return toOwnerView(updated);
  },

  /* ------------------------- theme editor (Phase 5) ------------------------- */

  /** Save the draft only: the live storefront keeps the published theme. */
  async saveThemeDraft(ownerId: string, spec: ThemeSpec): Promise<StoreOwnerView> {
    const store = await prisma.store.findUnique({ where: { ownerId }, select: { id: true } });
    if (!store) throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    const updated = await prisma.store.update({
      where: { id: store.id },
      data: { themeDraft: spec },
      select: storeSelection,
    });
    return toOwnerView(updated);
  },

  /**
   * Atomic publish: the draft becomes live, the theme that was live is kept
   * for one-step rollback. Nothing is destroyed, nothing half-applied.
   */
  async publishTheme(ownerId: string): Promise<StoreOwnerView> {
    const store = await prisma.store.findUnique({
      where: { ownerId },
      select: { id: true, theme: true, themeDraft: true },
    });
    if (!store) throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    const draft = parseNullableTheme(store.themeDraft);
    if (draft === null) {
      throw new ApiError(409, "NO_THEME_DRAFT", "There are no unpublished changes to publish.");
    }
    const updated = await prisma.store.update({
      where: { id: store.id },
      data: { theme: draft, themeDraft: Prisma.DbNull, themePrevious: parseTheme(store.theme) },
      select: storeSelection,
    });
    return toOwnerView(updated);
  },

  async discardThemeDraft(ownerId: string): Promise<StoreOwnerView> {
    const store = await prisma.store.findUnique({ where: { ownerId }, select: { id: true } });
    if (!store) throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    const updated = await prisma.store.update({
      where: { id: store.id },
      data: { themeDraft: Prisma.DbNull },
      select: storeSelection,
    });
    return toOwnerView(updated);
  },

  /** Roll back the last publish. Swaps, so pressing it again re-applies. */
  async restorePreviousTheme(ownerId: string): Promise<StoreOwnerView> {
    const store = await prisma.store.findUnique({
      where: { ownerId },
      select: { id: true, theme: true, themePrevious: true },
    });
    if (!store) throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    const previous = parseNullableTheme(store.themePrevious);
    if (previous === null) {
      throw new ApiError(409, "NO_THEME_HISTORY", "There is no earlier theme to restore.");
    }
    const updated = await prisma.store.update({
      where: { id: store.id },
      data: { theme: previous, themePrevious: parseTheme(store.theme), themeDraft: Prisma.DbNull },
      select: storeSelection,
    });
    return toOwnerView(updated);
  },

  async getBySlug(slugRaw: string): Promise<StorePublic> {
    const slug = slugOr404(slugRaw);
    const store = await prisma.store.findUnique({
      where: { slug },
      select: storeSelection,
    });
    if (!store || store.status !== "active") {
      throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");
    }
    return toPublic(store);
  },

  async existsBySlug(slugRaw: string): Promise<boolean> {
    const found = await prisma.store.findUnique({
      where: { slug: slugOr404(slugRaw) },
      select: { id: true },
    });
    return found !== null;
  },

  /**
   * Draft theme for the storefront preview route. Only the owner sees it, and
   * only when they explicitly ask for a draft preview.
   */
  async previewThemeForOwner(slugRaw: string, userId: string | null): Promise<ThemeSpec | null> {
    if (userId === null) return null;
    const store = await prisma.store.findUnique({
      where: { slug: slugOr404(slugRaw) },
      select: { ownerId: true, themeDraft: true },
    });
    if (!store || store.ownerId !== userId) return null;
    return parseNullableTheme(store.themeDraft);
  },
};
