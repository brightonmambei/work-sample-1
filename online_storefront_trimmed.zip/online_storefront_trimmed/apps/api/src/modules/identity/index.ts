import cookieParser from "cookie-parser";
import { authRouter } from "./routes.js";

/**
 * Identity module export. Session refresh uses an httpOnly cookie, so the
 * cookie parser is scoped to the auth router's own mount layer.
 */
export const identityRouter = [cookieParser(), authRouter] as const;
