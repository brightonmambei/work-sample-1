import { prisma } from "../../lib/prisma.js";
import {
  createSession,
  hashPassword,
  revokeAllSessions,
  revokeSession,
  rotateSession,
  signAccessToken,
  verifyPassword,
} from "../../lib/auth.js";
import { ApiError } from "../../errors.js";
import type { LoginInput, RegisterInput } from "./schemas.js";

export const identityService = {
  async register(input: RegisterInput): Promise<AuthResult> {
    const existing = await prisma.user.findUnique({
      where: { email: input.email },
      select: { id: true },
    });
    if (existing) {
      throw new ApiError(409, "EMAIL_TAKEN", "That email already has an account.");
    }

    const passwordHash = await hashPassword(input.password);
    const user = await prisma.user.create({
      data: {
        email: input.email,
        name: input.name,
        passwordHash,
        role: input.intent === "buyer" ? "buyer" : "seller",
      },
    });

    const refreshToken = await createSession(user.id);
    return { user: toPublic(user), refreshToken, accessToken: signAccessToken(user) };
  },

  async login(input: LoginInput): Promise<AuthResult> {
    const user = await prisma.user.findUnique({ where: { email: input.email } });
    if (!user || !(await verifyPassword(user.passwordHash, input.password))) {
      // Same message for both cases: no account enumeration.
      throw new ApiError(401, "BAD_CREDENTIALS", "Email or password is incorrect.");
    }
    if (user.status === "suspended") {
      throw new ApiError(403, "SUSPENDED", "This account is suspended.");
    }

    const refreshToken = await createSession(user.id);
    return { user: toPublic(user), refreshToken, accessToken: signAccessToken(user) };
  },

  async refresh(
    refreshToken: string | undefined,
    meta: { userAgent?: string; ip?: string },
  ): Promise<AuthResult> {
    if (!refreshToken) {
      throw new ApiError(401, "SESSION_INVALID", "No session to refresh.");
    }
    const { userId } = await rotateSession(refreshToken, meta);
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.status === "suspended") {
      throw new ApiError(401, "SESSION_INVALID", "Account unavailable.");
    }
    const freshToken = await createSession(user.id, meta);
    return { user: toPublic(user), refreshToken: freshToken, accessToken: signAccessToken(user) };
  },

  async logout(refreshToken: string | undefined): Promise<void> {
    if (refreshToken) await revokeSession(refreshToken);
  },

  async me(userId: string): Promise<UserPublic> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: publicUserSelection,
    });
    if (!user) throw new ApiError(404, "USER_NOT_FOUND", "Account not found.");
    return user;
  },

  async revokeEverything(userId: string): Promise<void> {
    await revokeAllSessions(userId);
  },
};

const publicUserSelection = {
  id: true,
  email: true,
  name: true,
  role: true,
  status: true,
  createdAt: true,
} as const;

export type UserPublic = {
  id: string;
  email: string;
  name: string;
  role: string;
  status: string;
  createdAt: Date;
};

export interface AuthResult {
  user: UserPublic;
  accessToken: string;
  refreshToken: string;
}

function toPublic(user: {
  id: string;
  email: string;
  name: string;
  role: string;
  status: string;
  createdAt: Date;
}): UserPublic {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    status: user.status,
    createdAt: user.createdAt,
  };
}
