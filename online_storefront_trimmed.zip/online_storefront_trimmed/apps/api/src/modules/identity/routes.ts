import express from "express";
import { registerSchema, loginSchema } from "./schemas.js";
import { identityService } from "./service.js";
import { validateBody } from "../../middleware/validate.js";
import { requireAuth } from "../../middleware/auth.js";
import { ok } from "../../middleware/error.js";
import { REFRESH_COOKIE, refreshCookieOptions } from "../../lib/auth.js";
import type { Request } from "express";

export const authRouter = express.Router();

function requestMeta(req: Request) {
  return {
    userAgent: (req.headers["user-agent"] as string | undefined)?.slice(0, 180) ?? "",
    ip: (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim().slice(0, 60) ?? req.ip ?? "",
  };
}

function setRefreshCookie(res: express.Response, refreshToken: string): void {
  res.cookie(REFRESH_COOKIE, refreshToken, refreshCookieOptions());
}

authRouter.post("/register", validateBody(registerSchema), async (req, res, next) => {
  try {
    const result = await identityService.register(req.body);
    setRefreshCookie(res, result.refreshToken);
    ok(res, { user: result.user, accessToken: result.accessToken }, 201);
  } catch (err) {
    next(err);
  }
});

authRouter.post("/login", validateBody(loginSchema), async (req, res, next) => {
  try {
    const result = await identityService.login(req.body);
    setRefreshCookie(res, result.refreshToken);
    ok(res, { user: result.user, accessToken: result.accessToken });
  } catch (err) {
    next(err);
  }
});

authRouter.post("/refresh", async (req, res, next) => {
  try {
    const result = await identityService.refresh(
      req.cookies?.[REFRESH_COOKIE] as string | undefined,
      requestMeta(req),
    );
    setRefreshCookie(res, result.refreshToken);
    ok(res, { user: result.user, accessToken: result.accessToken });
  } catch (err) {
    res.clearCookie(REFRESH_COOKIE, { path: "/api/v1/auth" });
    next(err);
  }
});

authRouter.post("/logout", async (req, res, next) => {
  try {
    await identityService.logout(req.cookies?.[REFRESH_COOKIE] as string | undefined);
    res.clearCookie(REFRESH_COOKIE, { path: "/api/v1/auth" });
    ok(res, { signedOut: true });
  } catch (err) {
    next(err);
  }
});

authRouter.get("/me", requireAuth, async (req, res, next) => {
  try {
    ok(res, { user: await identityService.me(req.auth!.userId) });
  } catch (err) {
    next(err);
  }
});
