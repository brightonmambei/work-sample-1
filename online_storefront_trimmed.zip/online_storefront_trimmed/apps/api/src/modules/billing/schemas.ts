import { z } from "zod";

export const changePlanSchema = z.object({
  plan: z.enum(["grow", "commerce", "business"]),
  period: z.enum(["monthly", "weekly", "quarterly"]).default("monthly"),
});
export type ChangePlanInput = z.infer<typeof changePlanSchema>;

export const collectSchema = z.object({
  phone: z.string().trim().regex(/^(?:\+?254|0)([17]\d{8})$/, "Use a Safaricom number, e.g. 0712345678."),
});
export type CollectInput = z.infer<typeof collectSchema>;

export const boostSchema = z.object({
  listingId: z.string().min(4),
  packKey: z.enum(["feature_48h", "feature_72h", "popup_7d"]),
  phone: z.string().trim().regex(/^(?:\+?254|0)([17]\d{8})$/, "Use a Safaricom number, e.g. 0712345678."),
});
export type BoostInput = z.infer<typeof boostSchema>;
