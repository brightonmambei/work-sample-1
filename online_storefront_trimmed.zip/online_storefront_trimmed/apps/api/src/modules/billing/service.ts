/**
 * Billing service (Phase 4): subscriptions, the metering engine
 * (bill-on-record), usage invoices over M-Pesa STK, and Boost purchases.
 *
 * Platform revenue = subscriptions + boosts + usage fees. Seller sale money
 * NEVER flows through the platform (invariant 8): usage_events record value,
 * the platform invoices its own fee on top, transparently.
 */
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import type { PlanTier } from "@storesnap/shared";
import { stkPush } from "./mpesa.js";

/** Per-period subscription prices in KSh (AGENTS.md section 11). */
const SUBSCRIPTION_PRICES: Record<Exclude<PlanTier, "grow">, Record<string, number>> = {
  commerce: { monthly: 999, weekly: 300, quarterly: 8500 },
  business: { monthly: 2999, weekly: 900, quarterly: 25500 },
};

export const BOOST_PACKS: Record<
  string,
  { label: string; amountKes: number; hours: number }
> = {
  feature_48h: { label: "Featured for 48 hours", amountKes: 60, hours: 48 },
  feature_72h: { label: "Featured for 72 hours", amountKes: 100, hours: 72 },
  popup_7d: { label: "Pop-up pack, 7 days", amountKes: 500, hours: 168 },
};

const DEFAULT_RATE_CARDS: Array<{ key: string; label: string; feeBps: number; minFeeKes: number }> = [
  {
    key: "usage_fee_recorded_sales",
    label: "Fee on platform-recorded sales (Business tier)",
    feeBps: 100,
    minFeeKes: 20,
  },
];

const DUNNING_GRACE_DAYS = 7;

export const billingService = {
  /** Idempotent boot seeding: the rate card is DB-owned config. */
  async ensureDefaults(): Promise<void> {
    for (const card of DEFAULT_RATE_CARDS) {
      await prisma.rateCard.upsert({
        where: { key: card.key },
        create: card,
        update: {},
      });
    }
  },

  /* ---------------------------- subscriptions ---------------------------- */

  async changePlan(storeId: string, plan: PlanTier, period: string): Promise<Record<string, unknown>> {
    if (!["grow", "commerce", "business"].includes(plan)) {
      throw new ApiError(422, "VALIDATION", "Unknown plan.");
    }
    if (!["monthly", "weekly", "quarterly"].includes(period)) {
      throw new ApiError(422, "VALIDATION", "Unknown billing period.");
    }

    if (plan === "grow") {
      // Downgrade to Grow: subscription ends; storefront and catalog stay.
      await prisma.billingSubscription.deleteMany({ where: { storeId } });
      await prisma.store.update({ where: { id: storeId }, data: { plan: "grow" } });
      return { plan: "grow", status: "none" };
    }

    const priceKes = SUBSCRIPTION_PRICES[plan]?.[period] ?? 0;
    const sub = await prisma.billingSubscription.upsert({
      where: { storeId },
      create: {
        storeId,
        plan,
        period: period as "monthly",
        status: "active",
        priceKes,
        renewsAt: renewalFor(period),
      },
      update: { plan, period: period as "monthly", status: "active", priceKes },
    });
    await prisma.store.update({ where: { id: storeId }, data: { plan } });
    return sub;
  },

  async subscriptionFor(storeId: string): Promise<Record<string, unknown> | null> {
    const sub = await prisma.billingSubscription.findUnique({ where: { storeId } });
    if (sub === null) {
      const store = await prisma.store.findUnique({ where: { id: storeId }, select: { plan: true } });
      return { plan: (store?.plan ?? "grow") as string, status: "none", priceKes: 0 };
    }
    return sub;
  },

  /* ----------------------- metering (bill-on-record) ---------------------- */

  /**
   * Nightly aggregation: usage_events -> usage_periods for the closed month.
   * Idempotent: upsert per (storeId, periodStart); the ledger is untouched.
   */
  async aggregateUsage(now = new Date()): Promise<number> {
    const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1));
    const monthEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));

    const grouped = await prisma.billingUsageEvent.groupBy({
      by: ["storeId"],
      where: { createdAt: { gte: monthStart, lt: monthEnd } },
      _count: true,
      _sum: { amountKes: true },
    });

    let periods = 0;
    for (const row of grouped) {
      const feeKes = await this.feeFor(row.storeId, row._sum.amountKes ?? 0);
      await prisma.usagePeriod.upsert({
        where: { storeId_periodStart: { storeId: row.storeId, periodStart: monthStart } },
        create: {
          storeId: row.storeId,
          periodStart: monthStart,
          periodEnd: monthEnd,
          units: row._count,
          recordedKes: row._sum.amountKes ?? 0,
          feeKes,
        },
        update: {
          units: row._count,
          recordedKes: row._sum.amountKes ?? 0,
          // Recompute on every pass so the period tracks the live rate card.
          feeKes,
        },
      });
      periods += 1;
    }
    return periods;
  },

  async feeFor(storeId: string, recordedKes: number): Promise<number> {
    const store = await prisma.store.findUnique({ where: { id: storeId }, select: { plan: true } });
    if ((store?.plan ?? "grow") !== "business") return 0;
    const card = await prisma.rateCard.findUnique({ where: { key: "usage_fee_recorded_sales" } });
    if (card === null || !card.active) return 0;
    const fee = Math.round((recordedKes * card.feeBps) / 10_000);
    return Math.max(fee, card.minFeeKes);
  },

  /** Draft the usage invoice for a store's last aggregated period. */
  async draftUsageInvoice(storeId: string): Promise<Record<string, unknown>> {
    const period = await prisma.usagePeriod.findFirst({
      where: { storeId },
      orderBy: { periodStart: "desc" },
    });
    if (period === null) {
      throw new ApiError(404, "NO_USAGE", "No recorded usage to invoice yet.");
    }
    const existing = await prisma.usageInvoice.findFirst({
      where: {
        storeId,
        periodId: period.id,
        status: { notIn: ["void"] },
      },
    });
    if (existing !== null) {
      throw new ApiError(409, "INVOICE_EXISTS", "An invoice for this period already exists.");
    }
    const line = {
      label: `Recorded sales ${period.recordedKes.toLocaleString("en-KE")} KSh x metered fee`,
      amountKes: period.feeKes,
    };
    return prisma.usageInvoice.create({
      data: {
        storeId,
        periodId: period.id,
        status: "draft",
        totalKes: period.feeKes,
        lines: { items: [line] },
      },
    });
  },

  /** Release = issue to the seller and collect over M-Pesa STK push. */
  async collectInvoice(storeId: string, invoiceId: string, phone: string): Promise<Record<string, unknown>> {
    const invoice = await prisma.usageInvoice.findFirst({
      where: { id: invoiceId, storeId, status: { in: ["draft", "overdue"] } },
    });
    if (invoice === null) throw new ApiError(404, "INVOICE_NOT_FOUND", "Invoice not collectable.");

    await prisma.usageInvoice.update({
      where: { id: invoice.id },
      data: { status: "issued", issuedAt: new Date(), dueAt: new Date(Date.now() + 7 * 86400_000) },
    });

    return this.requestPayment({
      storeId,
      purpose: "invoice",
      invoiceId: invoice.id,
      phone,
      amountKes: invoice.totalKes,
      accountReference: `Inv ${invoice.id.slice(-6).toUpperCase()}`,
      description: "StoreSnap usage invoice",
      callbackPath: "/api/v1/webhooks/mpesa",
    });
  },

  /**
   * Create the STK payment row and push (or stub-complete in dev).
   * Returns the payment record; caller surfaces CheckoutRequestID.
   */
  async requestPayment(input: {
    storeId: string;
    purpose: "invoice" | "subscription" | "boost";
    phone: string;
    amountKes: number;
    accountReference: string;
    description: string;
    callbackPath: string;
    invoiceId?: string;
    subscriptionId?: string;
    boostPurchaseId?: string;
  }): Promise<Record<string, unknown>> {
    const amount = Math.max(1, Math.round(input.amountKes));
    if (amount <= 0) throw new ApiError(422, "VALIDATION", "Amount must be positive.");

    const initiation = await stkPush({
      phone: input.phone,
      amountKes: amount,
      accountReference: input.accountReference,
      description: input.description,
      callbackPath: input.callbackPath,
    });

    const payment = await prisma.mpesaPayment.create({
      data: {
        storeId: input.storeId,
        invoiceId: input.invoiceId ?? null,
        subscriptionId: input.subscriptionId ?? null,
        boostPurchaseId: input.boostPurchaseId ?? null,
        purpose: input.purpose,
        phone: input.phone,
        amountKes: amount,
        checkoutRequestId: initiation.checkoutRequestId,
        merchantRequestId: initiation.merchantRequestId,
        status: "pending",
      },
    });

    if (initiation.mode === "stub") {
      // Dev: the "customer" confirms instantly.
      return this.settlePayment(initiation.checkoutRequestId, {
        success: true,
        receipt: `STUB${Date.now()}`,
      }).then(() => ({ ...payment, status: "success" }));
    }
    return payment;
  },

  /**
   * Single settlement path for both live webhooks and stub completion:
   * payment -> effect (invoice paid / subscription active / boost starts).
   */
  async settlePayment(
    checkoutRequestId: string,
    result: { success: boolean; receipt: string | null; desc?: string | null },
  ): Promise<Record<string, unknown> | null> {
    const payment = await prisma.mpesaPayment.findUnique({
      where: { checkoutRequestId },
      select: { id: true, status: true, purpose: true, invoiceId: true, subscriptionId: true, storeId: true, amountKes: true },
    });
    if (payment === null || payment.status !== "pending") return payment;

    await prisma.mpesaPayment.update({
      where: { id: payment.id },
      data: {
        status: result.success ? "success" : "failed",
        mpesaReceiptNumber: result.receipt,
        resultDesc: result.desc ?? null,
      },
    });

    if (result.success && payment.purpose === "invoice" && payment.invoiceId !== null) {
      await prisma.usageInvoice.update({
        where: { id: payment.invoiceId },
        data: { status: "paid", paidAt: new Date() },
      });
    }

    if (result.success && payment.purpose === "subscription" && payment.subscriptionId !== null) {
      const sub = await prisma.billingSubscription.findUnique({
        where: { id: payment.subscriptionId },
        select: { plan: true, period: true },
      });
      await prisma.billingSubscription.update({
        where: { id: payment.subscriptionId },
        data: { status: "active", renewsAt: renewalFor(sub?.period ?? "monthly") },
      });
      await prisma.store.update({
        where: { id: payment.storeId },
        data: { plan: (sub?.plan ?? "grow") as "grow" },
      });
    }

    if (result.success && payment.purpose === "boost") {
      const boost = await prisma.boostPurchase.findFirst({
        where: { mpesaPayment: { id: payment.id } },
        select: { id: true, listingId: true, packKey: true },
      });
      if (boost !== null) {
        const pack = BOOST_PACKS[boost.packKey];
        const startsAt = new Date();
        const packHours = pack === undefined ? 48 : pack.hours;
        const expiresAt = new Date(Date.now() + packHours * 3600_000);
        await prisma.boostPurchase.update({
          where: { id: boost.id },
          data: { status: "paid", startsAt, expiresAt },
        });
        // Extend an existing featured window rather than resetting it.
        const listing = await prisma.listing.findUnique({
          where: { id: boost.listingId },
          select: { boostedUntil: true },
        });
        const base = listing?.boostedUntil !== null && listing !== null && listing.boostedUntil > startsAt
          ? listing.boostedUntil
          : startsAt;
        await prisma.listing.update({
          where: { id: boost.listingId },
          data: { boostedUntil: new Date(base.getTime() + packHours * 3600_000) },
        });
      }
    }

    return prisma.mpesaPayment.findUnique({ where: { id: payment.id } });
  },

  /* -------------------------------- dunning ------------------------------- */

  /**
   * Proportionate enforcement (AGENTS.md section 11): overdue invoices get
   * flagged, subscriptions go past_due, boost purchases pause. The catalog
   * and storefront always stay up, for every seller, forever.
   */
  async enforceOverdue(now = new Date()): Promise<{ flagged: number; pastDue: number }> {
    const overdue = await prisma.usageInvoice.updateMany({
      where: { status: "issued", dueAt: { lt: now } },
      data: { status: "overdue" },
    });

    // Storefronts on Grow stay untouched: no invoices exist for them.
    const flaggedRows = await prisma.usageInvoice.findMany({
      where: { status: "overdue" },
      select: { storeId: true },
      distinct: ["storeId"],
    });
    const pastDueCutoff = new Date(now.getTime() - (DUNNING_GRACE_DAYS + 7) * 86400_000);
    const unpaid = await prisma.usageInvoice.findMany({
      where: { status: "overdue", createdAt: { lt: pastDueCutoff } },
      select: { storeId: true },
      distinct: ["storeId"],
    });

    const pastDue = unpaid.length;
    for (const row of unpaid) {
      await prisma.billingSubscription.updateMany({
        where: { storeId: row.storeId, status: "active" },
        data: { status: "past_due" },
      });
    }

    return { flagged: overdue.count + flaggedRows.length, pastDue };
  },

  /* --------------------------------- boosts ------------------------------- */

  async purchaseBoost(
    storeId: string,
    listingId: string,
    packKey: string,
    phone: string,
  ): Promise<Record<string, unknown>> {
    const pack = BOOST_PACKS[packKey];
    if (pack === undefined) {
      throw new ApiError(422, "VALIDATION", "Unknown boost pack.");
    }
    const store = await prisma.store.findUnique({
      where: { id: storeId },
      select: { plan: true, status: true },
    });
    if (store === null) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");

    // Proportionate enforcement: past-due sellers pause boost tools only.
    const sub = await prisma.billingSubscription.findUnique({ where: { storeId } });
    if (sub?.status === "past_due") {
      throw new ApiError(402, "ACCOUNT_PAST_DUE", "Settle your usage invoice to re-enable boosts. Your storefront stays live.");
    }

    const listing = await prisma.listing.findFirst({
      where: { id: listingId, storeId, status: { in: ["active", "paused", "sold_out"] } },
      select: { id: true },
    });
    if (listing === null) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Publish the item before boosting it.");
    }

    const boost = await prisma.boostPurchase.create({
      data: { storeId, listingId, packKey: packKey as "feature_48h", amountKes: pack.amountKes },
    });

    // Stub mode settles instantly; live mode returns a pending payment and the
    // boost activates when the Safaricom callback lands.
    await this.requestPayment({
      storeId,
      purpose: "boost",
      phone,
      amountKes: pack.amountKes,
      accountReference: `Boost ${boost.id.slice(-6).toUpperCase()}`,
      description: pack.label,
      callbackPath: "/api/v1/webhooks/mpesa",
      boostPurchaseId: boost.id,
    });

    const after = await prisma.boostPurchase.findUnique({ where: { id: boost.id } });
    return after ?? boost;
  },
};

function renewalFor(period: string): Date {
  const days = period === "weekly" ? 7 : period === "quarterly" ? 90 : 30;
  return new Date(Date.now() + days * 86400_000);
}
