import express, { type Request, type Response, type NextFunction } from "express";
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { ok } from "../../middleware/error.js";
import { requireRole } from "../../middleware/auth.js";
import { requireStoreOwnership } from "../../middleware/store.js";
import { validateBody } from "../../middleware/validate.js";
import { changePlanSchema, boostSchema, collectSchema } from "./schemas.js";
import { billingService, BOOST_PACKS } from "./service.js";
import { parseStkCallback } from "./mpesa.js";
import { config } from "../../config.js";

/* ------------------------------ seller routes ----------------------------- */

export const sellerBillingRouter = express.Router();
sellerBillingRouter.use(requireRole("seller", "platform_owner"), requireStoreOwnership);

sellerBillingRouter.get("/billing", async (req, res, next) => {
  try {
    const storeId = req.storeOwnership!.storeId;
    const [subscription, usageSummary, invoices, boosts] = await Promise.all([
      billingService.subscriptionFor(storeId),
      ordersServiceUsage(storeId),
      prisma.usageInvoice.findMany({
        where: { storeId },
        orderBy: { createdAt: "desc" },
        take: 24,
      }),
      prisma.boostPurchase.findMany({
        where: { storeId },
        orderBy: { createdAt: "desc" },
        take: 24,
        select: {
          id: true, listingId: true, packKey: true, amountKes: true,
          status: true, startsAt: true, expiresAt: true, createdAt: true,
        },
      }),
    ]);
    ok(res, { subscription, usage: usageSummary, invoices, boosts, packs: BOOST_PACKS });
  } catch (err) {
    next(err);
  }
});

sellerBillingRouter.post(
  "/billing/plan",
  validateBody(changePlanSchema),
  async (req, res, next) => {
    try {
      const sub = await billingService.changePlan(
        req.storeOwnership!.storeId,
        req.body.plan,
        req.body.period,
      );
      ok(res, { subscription: sub });
    } catch (err) {
      next(err);
    }
  },
);

/** STK collect for a released usage invoice (or retry an overdue one). */
sellerBillingRouter.post(
  "/billing/invoices/:id/collect",
  validateBody(collectSchema),
  async (req, res, next) => {
    try {
      const result = await billingService.collectInvoice(
        req.storeOwnership!.storeId,
        String(req.params.id ?? ""),
        req.body.phone,
      );
      ok(res, { payment: result });
    } catch (err) {
      next(err);
    }
  },
);

sellerBillingRouter.post(
  "/boosts",
  validateBody(boostSchema),
  async (req, res, next) => {
    try {
      const result = await billingService.purchaseBoost(
        req.storeOwnership!.storeId,
        req.body.listingId,
        req.body.packKey,
        req.body.phone,
      );
      ok(res, { boost: result }, 201);
    } catch (err) {
      next(err);
    }
  },
);

/* ------------------------------- webhook --------------------------------- */

/**
 * Safaricom STK callback. Security: anyone can POST, so the settlement only
 * trusting a CheckoutRequestID this API created (unique + pending) is the
 * authentication: no transaction can be claimed that was not initiated here.
 */
export const mpesaWebhookRouter = express.Router();

mpesaWebhookRouter.post("/mpesa", (req: Request, res: Response, next: NextFunction) => {
  try {
    const parsed = parseStkCallback(req.body as never);
    void billingService
      .settlePayment(parsed.checkoutRequestId, {
        success: parsed.success,
        receipt: parsed.receipt,
        desc: parsed.desc,
      })
      .catch((err) => config.env !== "test" && console.error(err));
    // Safaricom always wants a 200, fast.
    res.status(200).json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (err) {
    next(err);
  }
});

async function ordersServiceUsage(storeId: string): Promise<{ units: number; recordedKes: number; currentFeeKes: number }> {
  const events = await prisma.billingUsageEvent.aggregate({
    where: { storeId },
    _count: true,
    _sum: { amountKes: true },
  });
  // THIS MONTH only, not lifetime: the engine aggregates per period.
  const monthStart = new Date();
  monthStart.setUTCDate(1);
  monthStart.setUTCHours(0, 0, 0, 0);
  const month = await prisma.billingUsageEvent.aggregate({
    where: { storeId, createdAt: { gte: monthStart } },
    _count: true,
    _sum: { amountKes: true },
  });
  void events;
  const fee = await billingService.feeFor(storeId, month._sum.amountKes ?? 0);
  return {
    units: month._count,
    recordedKes: month._sum.amountKes ?? 0,
    currentFeeKes: fee,
  };
}

/* Manual settlement helper for stub mode (dev + tests): pay a pending payment. */
export async function settleStub(checkoutRequestId: string): Promise<void> {
  if (config.mpesa.mode !== "stub") {
    throw new ApiError(403, "FORBIDDEN", "Only available in stub mode.");
  }
  await billingService.settlePayment(checkoutRequestId, {
    success: true,
    receipt: `STUB${Date.now()}`,
  });
}
