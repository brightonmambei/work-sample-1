/**
 * M-Pesa Daraja STK push client (AGENTS.md section 11).
 *
 * MPESA_MODE=stub (default in dev): the collect completes instantly and we
 * mark the payment successful. Nothing leaves the machine.
 * MPESA_MODE=live: real Daraja OAuth + STK push; the payment stays pending
 * until the Safaricom webhook lands (routes/webhook below).
 */
import { config } from "../../config.js";
import { logger } from "../../lib/logger.js";

export interface StkInitiation {
  mode: "stub" | "live";
  checkoutRequestId: string;
  merchantRequestId: string | null;
  live: boolean;
}

function timestamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    String(d.getFullYear()) +
    p(d.getMonth() + 1) +
    p(d.getDate()) +
    p(d.getHours()) +
    p(d.getMinutes()) +
    p(d.getSeconds())
  );
}

function darajaBase(): string {
  return config.mpesa.env === "production"
    ? "https://api.safaricom.co.ke"
    : "https://sandbox.safaricom.co.ke";
}

async function accessToken(): Promise<string> {
  const key = config.mpesa.consumerKey ?? "";
  const secret = config.mpesa.consumerSecret ?? "";
  const auth = Buffer.from(`${key}:${secret}`).toString("base64");
  const res = await fetch(`${darajaBase()}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
  });
  if (!res.ok) throw new Error(`Daraja OAuth failed: ${res.status}`);
  const body = (await res.json()) as { access_token: string };
  return body.access_token;
}

export async function stkPush(input: {
  phone: string;
  amountKes: number;
  accountReference: string;
  description: string;
  callbackPath: string; // e.g. /api/v1/webhooks/mpesa
}): Promise<StkInitiation> {
  if (config.mpesa.mode === "stub") {
    // Deterministic, clearly-marked dev payment id.
    const id = `stub-${Date.now()}-${input.amountKes}`;
    return { mode: "stub", checkoutRequestId: id, merchantRequestId: null, live: false };
  }

  const shortcode = config.mpesa.shortcode ?? "";
  const passkey = config.mpesa.passkey ?? "";
  const ts = timestamp();
  const password = Buffer.from(`${shortcode}${passkey}${ts}`).toString("base64");
  const token = await accessToken();

  const res = await fetch(`${darajaBase()}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: input.amountKes,
      PartyA: input.phone,
      PartyB: shortcode,
      PhoneNumber: input.phone,
      CallBackURL: `${config.mpesa.publicApiUrl}${input.callbackPath}`,
      AccountReference: input.accountReference.slice(0, 12),
      TransactionDesc: input.description.slice(0, 40),
    }),
  });

  if (!res.ok) {
    logger.error({ status: res.status }, "daraja stk push failed");
    throw new Error("M-Pesa collect could not be started. Try again shortly.");
  }
  const body = (await res.json()) as {
    MerchantRequestID?: string;
    CheckoutRequestID?: string;
    ResponseCode?: string;
  };
  if (body.ResponseCode !== "0" || !body.CheckoutRequestID) {
    throw new Error("M-Pesa collect was rejected by Safaricom.");
  }
  return {
    mode: "live",
    checkoutRequestId: body.CheckoutRequestID,
    merchantRequestId: body.MerchantRequestID ?? null,
    live: true,
  };
}

export interface StkCallbackBody {
  Body?: {
    stkCallback?: {
      MerchantRequestID?: string;
      CheckoutRequestID?: string;
      ResultCode?: number;
      ResultDesc?: string;
      CallbackMetadata?: {
        Item?: Array<{ Name: string; Value?: string | number }>;
      };
    };
  };
}

export function parseStkCallback(
  body: StkCallbackBody,
): { checkoutRequestId: string; success: boolean; receipt: string | null; desc: string | null } {
  const cb = body.Body?.stkCallback;
  if (!cb?.CheckoutRequestID) {
    throw new Error("Malformed STK callback");
  }
  const receipt =
    cb.CallbackMetadata?.Item?.find((i) => i.Name === "MpesaReceiptNumber")?.Value ?? null;
  return {
    checkoutRequestId: cb.CheckoutRequestID,
    success: cb.ResultCode === 0,
    receipt: receipt === null ? null : String(receipt),
    desc: cb.ResultDesc ?? null,
  };
}
