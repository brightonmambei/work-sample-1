/**
 * Seller-side drop management (AGENTS.md section 8): build a curated set from
 * the catalog grid in one pass and get a single shareable link plus its
 * caption back. Buyer-facing reads live on /market (host-resolved) and the
 * canonical unfurl lives at /p/{code}.
 */
import express from "express";
import { requireRole } from "../../middleware/auth.js";
import { requireStoreOwnership } from "../../middleware/store.js";
import { validateBody } from "../../middleware/validate.js";
import { ok } from "../../middleware/error.js";
import {
  createCollectionSchema,
  setCollectionItemsSchema,
  updateCollectionSchema,
} from "./schemas.js";
import { collectionsService } from "./service.js";

export const sellerCollectionsRouter = express.Router();
sellerCollectionsRouter.use(requireRole("seller", "platform_owner"), requireStoreOwnership);
sellerCollectionsRouter.use(express.json());

sellerCollectionsRouter.post(
  "/",
  validateBody(createCollectionSchema),
  async (req, res, next) => {
    try {
      const collection = await collectionsService.create(req.storeOwnership!.storeId, req.body);
      ok(res, { collection }, 201);
    } catch (err) {
      next(err);
    }
  },
);

sellerCollectionsRouter.get("/", async (req, res, next) => {
  try {
    const collections = await collectionsService.list(req.storeOwnership!.storeId);
    ok(res, { collections });
  } catch (err) {
    next(err);
  }
});

sellerCollectionsRouter.get("/:id", async (req, res, next) => {
  try {
    const collection = await collectionsService.detail(
      req.storeOwnership!.storeId,
      String(req.params.id ?? ""),
    );
    ok(res, { collection });
  } catch (err) {
    next(err);
  }
});

sellerCollectionsRouter.patch(
  "/:id",
  validateBody(updateCollectionSchema),
  async (req, res, next) => {
    try {
      const collection = await collectionsService.update(
        req.storeOwnership!.storeId,
        String(req.params.id ?? ""),
        req.body,
      );
      ok(res, { collection });
    } catch (err) {
      next(err);
    }
  },
);

sellerCollectionsRouter.put(
  "/:id/items",
  validateBody(setCollectionItemsSchema),
  async (req, res, next) => {
    try {
      const collection = await collectionsService.setItems(
        req.storeOwnership!.storeId,
        String(req.params.id ?? ""),
        req.body.listingIds,
      );
      ok(res, { collection });
    } catch (err) {
      next(err);
    }
  },
);

/** Archive: the link stays alive (invariant 5), it just reads as ended. */
sellerCollectionsRouter.delete("/:id", async (req, res, next) => {
  try {
    await collectionsService.archive(req.storeOwnership!.storeId, String(req.params.id ?? ""));
    ok(res, { archived: true });
  } catch (err) {
    next(err);
  }
});

/** Force WhatsApp to re-scrape the drop card (same tool as the item refresh). */
sellerCollectionsRouter.post("/:id/refresh", async (req, res, next) => {
  try {
    const storeId = req.storeOwnership!.storeId;
    const id = String(req.params.id ?? "");
    await collectionsService.bumpOgVersion(storeId, id);
    await collectionsService.refreshCard(id);
    const collection = await collectionsService.detail(storeId, id);
    ok(res, { collection });
  } catch (err) {
    next(err);
  }
});
