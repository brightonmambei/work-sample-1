/**
 * Collections ("drops", AGENTS.md section 8): a curated set of listings with
 * ONE canonical share link, so twenty items travel through a WhatsApp group as
 * a single post instead of twenty. Collections are owned by a store, reuse the
 * share module for the link, and render their own 1200x630 unfurl collage.
 */
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { config } from "../../config.js";
import { Prisma } from "@prisma/client";
import { newCollectionCode } from "../catalog/codes.js";
import { toPublicMedia } from "../catalog/service.js";
import { composeDropCaption } from "../share/caption.js";
import { renderDropCard } from "../share/dropcard.js";
import { deleteObjects, getObject, putObject } from "../../lib/objectstore.js";
import { storage } from "../media/storage.js";
import { logger } from "../../lib/logger.js";

const MAX_ITEMS = 60;

const itemInclude = {
  items: {
    orderBy: [{ sortOrder: "asc" as const }, { id: "asc" as const }],
    include: {
      listing: {
        include: {
          media: { orderBy: [{ isHero: "desc" as const }, { sortOrder: "asc" as const }] },
        },
      },
    },
  },
} as const satisfies Prisma.CollectionInclude;

type CollectionRow = Prisma.CollectionGetPayload<{ include: typeof itemInclude }>;
type ItemRow = CollectionRow["items"][number];
type StoreCardInfo = { name: string; theme: unknown };
type CardRow = CollectionRow & { store: StoreCardInfo };

/** Buyer-visible states; drafts and archived items never surface in a drop. */
const VISIBLE_STATUSES = ["active", "paused", "sold_out"];

function visibleItems(row: CollectionRow): ItemRow[] {
  return row.items.filter((item) => VISIBLE_STATUSES.includes(item.listing.status));
}

function priceBounds(items: ItemRow[]): { min: number; max: number } {
  if (items.length === 0) return { min: 0, max: 0 };
  const prices = items.map((i) => i.listing.priceKes);
  return { min: Math.min(...prices), max: Math.max(...prices) };
}

function cardUrl(key: string | null): string | null {
  return key === null ? null : storage.urlFor(key);
}

/** Seller-facing summary: everything the grid and share sheet need. */
function toSummary(row: CollectionRow, store: { name: string; locationLabel: string | null }) {
  const items = visibleItems(row);
  const { min, max } = priceBounds(items);
  const url = `${config.siteUrl}/p/${row.code}`;
  return {
    id: row.id,
    code: row.code,
    title: row.title,
    description: row.description,
    status: row.status,
    itemCount: items.length,
    listingIds: items.map((i) => i.listingId),
    minPriceKes: min,
    maxPriceKes: max,
    shareUrl: url,
    caption: composeDropCaption({
      title: row.title,
      itemCount: items.length,
      minPriceKes: min,
      maxPriceKes: max,
      storeName: store.name,
      locationLabel: store.locationLabel,
      url,
    }),
    cardUrl: cardUrl(row.cardKey),
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * A drop card needs photos and photos live in the bucket, so the collage is
 * rendered here (sharp + SVG, same approach as the status poster). Keys are
 * stable per collection; cache busting rides the ?v= unfurl version so the
 * bucket never accumulates one object per edit.
 */
function cardKeyFor(collectionId: string): string {
  return `share/collections/${collectionId}/card.webp`;
}

async function renderCard(row: CardRow): Promise<Buffer | null> {
  const items = visibleItems(row).filter((i) => i.listing.media.length > 0).slice(0, 4);
  if (items.length === 0) return null;

  const keys = items
    .map((i) => {
      const media = i.listing.media.find((m) => m.isHero) ?? i.listing.media[0];
      return media?.cardKey ?? media?.fullKey ?? media?.thumbKey ?? null;
    })
    .filter((k): k is string => k !== null);
  if (keys.length === 0) return null;

  const photos: Buffer[] = [];
  for (const key of keys) {
    try {
      photos.push(await getObject(key));
    } catch (err) {
      logger.warn({ err, key }, "drop card: photo fetch failed, skipping tile");
    }
  }
  if (photos.length === 0) return null;

  const { min, max } = priceBounds(visibleItems(row));
  return renderDropCard({
    photos,
    title: row.title,
    storeName: row.store.name,
    itemCount: visibleItems(row).length,
    minPriceKes: min,
    maxPriceKes: max,
    theme: row.store.theme,
  });
}

export const collectionsService = {
  /**
   * Rebuild the unfurl collage for a collection. Never throws: a failed render
   * leaves the previous card (or no card) in place; the drop page still works.
   */
  async refreshCard(collectionId: string): Promise<string | null> {
    const row = await prisma.collection.findUnique({
      where: { id: collectionId },
      include: { ...itemInclude, store: { select: { name: true, theme: true } } },
    });
    if (!row) return null;

    const key = cardKeyFor(collectionId);
    try {
      const card = await renderCard(row);
      if (card === null) {
        if (row.cardKey !== null) {
          await deleteObjects([row.cardKey]).catch(() => undefined);
          await prisma.collection.update({ where: { id: collectionId }, data: { cardKey: null } });
        }
        return null;
      }
      await putObject(key, card);
      await prisma.collection.update({ where: { id: collectionId }, data: { cardKey: key } });
      return key;
    } catch (err) {
      logger.warn({ err, collectionId }, "drop card render failed");
      return row.cardKey;
    }
  },

  async create(
    storeId: string,
    input: { title: string; description?: string | null; listingIds?: string[] },
  ): Promise<Record<string, unknown>> {
    const store = await prisma.store.findUnique({
      where: { id: storeId },
      select: { id: true, name: true, locationLabel: true },
    });
    if (!store) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");

    const listingIds = await this.assertOwnedListings(storeId, input.listingIds ?? []);
    const code = await newCollectionCode();

    const created = await prisma.$transaction(async (tx) => {
      const collection = await tx.collection.create({
        data: {
          storeId,
          code,
          title: input.title,
          description: input.description ?? null,
        },
      });
      if (listingIds.length > 0) {
        await tx.collectionItem.createMany({
          data: listingIds.map((listingId, i) => ({
            collectionId: collection.id,
            listingId,
            sortOrder: i,
          })),
        });
      }
      // The share link is created up-front: /p/{code} is the drop's identity
      // from the moment it exists, so attribution works on the very first post.
      await tx.shareLink.create({ data: { collectionId: collection.id, code } });
      return collection.id;
    });

    await this.refreshCard(created);
    return this.detail(storeId, created, store);
  },

  async list(storeId: string): Promise<Array<Record<string, unknown>>> {
    const store = await prisma.store.findUnique({
      where: { id: storeId },
      select: { name: true, locationLabel: true },
    });
    const rows = await prisma.collection.findMany({
      where: { storeId, status: "active" },
      orderBy: { createdAt: "desc" },
      include: itemInclude,
    });
    return rows.map((row) => toSummary(row, store ?? { name: "", locationLabel: null }));
  },

  async detail(
    storeId: string,
    collectionId: string,
    storeInfo?: { name: string; locationLabel: string | null },
  ): Promise<Record<string, unknown>> {
    const row = await prisma.collection.findFirst({
      where: { id: collectionId, storeId },
      include: { ...itemInclude, store: { select: { name: true, locationLabel: true } } },
    });
    if (!row) throw new ApiError(404, "COLLECTION_NOT_FOUND", "Drop not found.");
    return toSummary(row, storeInfo ?? row.store);
  },

  async update(
    storeId: string,
    collectionId: string,
    input: { title?: string; description?: string | null },
  ): Promise<Record<string, unknown>> {
    await this.assertExists(storeId, collectionId);
    await prisma.collection.update({
      where: { id: collectionId },
      data: {
        ...(input.title !== undefined ? { title: input.title } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
      },
    });
    // The title sits on the card and in the caption, so re-render.
    await this.refreshCard(collectionId);
    return this.detail(storeId, collectionId);
  },

  /** Replace the drop's contents, in order. Empty is allowed (restocking). */
  async setItems(
    storeId: string,
    collectionId: string,
    listingIds: string[],
  ): Promise<Record<string, unknown>> {
    await this.assertExists(storeId, collectionId);
    const ordered = await this.assertOwnedListings(storeId, listingIds);

    await prisma.$transaction(async (tx) => {
      await tx.collectionItem.deleteMany({ where: { collectionId } });
      if (ordered.length > 0) {
        await tx.collectionItem.createMany({
          data: ordered.map((listingId, i) => ({ collectionId, listingId, sortOrder: i })),
        });
      }
      // Touch the row so updatedAt (and with it the unfurl version) moves even
      // when the same items come back in a new order.
      await tx.collection.update({ where: { id: collectionId }, data: { updatedAt: new Date() } });
    });

    await this.refreshCard(collectionId);
    return this.detail(storeId, collectionId);
  },

  /**
   * Archive, never hard-delete: a posted drop link must keep resolving
   * (invariant 5), and the old posts keep working with a "this drop ended"
   * landing instead of a 404.
   */
  async archive(storeId: string, collectionId: string): Promise<void> {
    await this.assertExists(storeId, collectionId);
    await prisma.collection.update({
      where: { id: collectionId },
      data: { status: "archived", updatedAt: new Date() },
    });
  },

  /** Manual unfurl refresh, mirroring listings.ogVersion. */
  async bumpOgVersion(storeId: string, collectionId: string): Promise<void> {
    await this.assertExists(storeId, collectionId);
    await prisma.collection.update({
      where: { id: collectionId },
      data: { ogVersion: new Date(), updatedAt: new Date() },
    });
  },

  async assertExists(storeId: string, collectionId: string): Promise<void> {
    const row = await prisma.collection.findFirst({
      where: { id: collectionId, storeId },
      select: { id: true },
    });
    if (!row) throw new ApiError(404, "COLLECTION_NOT_FOUND", "Drop not found.");
  },

  /** Drops only ever contain items from the same store (the one body guard). */
  async assertOwnedListings(storeId: string, listingIds: string[]): Promise<string[]> {
    if (listingIds.length === 0) return [];
    const unique = Array.from(new Set(listingIds)).slice(0, MAX_ITEMS);
    const rows = await prisma.listing.findMany({
      where: { id: { in: unique }, storeId },
      select: { id: true },
    });
    const owned = new Set(rows.map((r) => r.id));
    const foreign = unique.filter((id) => !owned.has(id));
    if (foreign.length > 0) {
      throw new ApiError(403, "FORBIDDEN", "That item is not in your catalog.");
    }
    return unique;
  },

  /* ---------------------------- buyer side ---------------------------- */

  /**
   * Public read for the SPA drop page and the /p/{code} unfurl. Archived
   * collections resolve too (state "ended") so group posts never die.
   */
  async getPublicByCode(rawCode: string): Promise<{
    state: "live" | "ended" | "gone";
    store: { slug: string; name: string; locationLabel: string | null } | null;
    collection: Record<string, unknown> | null;
  }> {
    const code = rawCode.toLowerCase();
    const row = await prisma.collection.findUnique({
      where: { code },
      include: {
        ...itemInclude,
        store: {
          select: { slug: true, name: true, locationLabel: true, status: true },
        },
      },
    });

    if (!row || row.store.status !== "active") {
      return { state: "gone", store: null, collection: null };
    }

    const store = {
      slug: row.store.slug,
      name: row.store.name,
      locationLabel: row.store.locationLabel,
    };
    const items = visibleItems(row);
    const { min, max } = priceBounds(items);

    const collection = {
      code: row.code,
      title: row.title,
      description: row.description,
      status: row.status,
      itemCount: items.length,
      minPriceKes: min,
      maxPriceKes: max,
      items: items.map((item) => ({
        ...publicCard(item.listing),
        sortOrder: item.sortOrder,
      })),
    };

    return {
      state: row.status === "archived" ? "ended" : "live",
      store,
      collection,
    };
  },
};

/** Buyer-facing card shape for a listing (mirrors catalogService.listPublic). */
function publicCard(row: {
  code: string;
  title: string;
  description: string | null;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  badgeText: string | null;
  sizes: string[];
  colors: string[];
  createdAt: Date;
  media: Array<{
    id: string;
    thumbKey: string | null;
    cardKey: string | null;
    fullKey: string | null;
    width: number | null;
    height: number | null;
    isHero: boolean;
    sortOrder: number;
  }>;
}): Record<string, unknown> {
  return {
    code: row.code,
    title: row.title,
    description: row.description,
    priceKes: row.priceKes,
    compareAtKes: row.compareAtKes,
    condition: row.condition,
    conditionGrade: row.conditionGrade,
    stock: row.stock,
    badgeText: row.badgeText,
    sizes: row.sizes,
    colors: row.colors,
    createdAt: row.createdAt.toISOString(),
    media: row.media.map(toPublicMedia),
  };
}
