import { z } from "zod";

/* ---------------- seller-facing contracts ---------------- */

/** A drop needs a title; contents can come later (restocking is fine). */
export const createCollectionSchema = z.object({
  title: z.string().trim().min(2, "Give the drop a short title.").max(140),
  description: z.string().trim().max(600).nullable().default(null),
  listingIds: z.array(z.string().min(1)).max(60).default([]),
});
export type CreateCollectionInput = z.infer<typeof createCollectionSchema>;

export const updateCollectionSchema = createCollectionSchema
  .pick({ title: true, description: true })
  .partial();
export type UpdateCollectionInput = z.infer<typeof updateCollectionSchema>;

/** Set (replace) the drop contents. Order is the order shown to buyers. */
export const setCollectionItemsSchema = z.object({
  listingIds: z.array(z.string().min(1)).max(60),
});
export type SetCollectionItemsInput = z.infer<typeof setCollectionItemsSchema>;
