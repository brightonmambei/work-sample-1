/**
 * Caption composer (AGENTS.md section 8): the sheet that gets pasted into a
 * WhatsApp group. One source of truth, server-side, so the wizard, the catalog
 * grid and (later) bulk post packs all produce identical text.
 *
 * House style: plain text, no emojis, no em-dashes. Sellers edit it freely;
 * we just make the first draft a good one.
 */

export interface CaptionInput {
  title: string;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  storeName: string;
  locationLabel: string | null;
  url: string;
}

const MAX_TITLE = 70;
const LOW_STOCK = 3;

function kes(amount: number): string {
  return `KSh ${amount.toLocaleString("en-KE")}`;
}

export function composeCaption(input: CaptionInput): string {
  const title =
    input.title.length <= MAX_TITLE
      ? input.title
      : `${input.title.slice(0, MAX_TITLE - 3).trimEnd()}...`;

  const price =
    input.compareAtKes !== null && input.compareAtKes > input.priceKes
      ? `${kes(input.priceKes)} (was ${kes(input.compareAtKes)})`
      : kes(input.priceKes);

  const condition =
    input.condition === "thrift"
      ? input.conditionGrade === null
        ? "Thrift"
        : `Thrift, grade ${input.conditionGrade}/5`
      : "Brand new";

  const where =
    input.locationLabel === null || input.locationLabel.trim() === ""
      ? input.storeName
      : `${input.storeName}, ${input.locationLabel.trim()}`;

  // Never nag about stock when there is plenty, and never with a stale "0".
  const scarcity =
    input.stock > 0 && input.stock <= LOW_STOCK ? `Only ${input.stock} left` : "";

  return [title, price, `${condition} - ${where}`, scarcity, `Order: ${input.url}`]
    .filter((line) => line !== "")
    .join("\n");
}

export interface DropCaptionInput {
  title: string;
  itemCount: number;
  minPriceKes: number;
  maxPriceKes: number;
  storeName: string;
  locationLabel: string | null;
  url: string;
}

/**
 * A drop is one post for many items, so the caption leads with what is inside
 * and the price range instead of a single price. Same house style: plain text,
 * no emojis, no em-dashes.
 */
export function composeDropCaption(input: DropCaptionInput): string {
  const title =
    input.title.length <= MAX_TITLE
      ? input.title
      : `${input.title.slice(0, MAX_TITLE - 3).trimEnd()}...`;

  const count =
    input.itemCount === 1 ? "1 item" : `${input.itemCount} items`;
  const range =
    input.itemCount === 0
      ? "Restocking"
      : input.minPriceKes === input.maxPriceKes
        ? kes(input.minPriceKes)
        : `${kes(input.minPriceKes)} - ${kes(input.maxPriceKes)}`;

  const where =
    input.locationLabel === null || input.locationLabel.trim() === ""
      ? input.storeName
      : `${input.storeName}, ${input.locationLabel.trim()}`;

  return [title, `${count} · ${range}`, where, `Browse: ${input.url}`].join("\n");
}

