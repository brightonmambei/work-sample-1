/**
 * Collection drop card (AGENTS.md section 8): the 1200x630 unfurl for a drop
 * link. A collage of up to four item photos, the drop title, how many items
 * are inside, the price range and the store name, tinted with the store
 * accent. Rendered with sharp + an SVG overlay, same approach as the status
 * poster, so the API needs no extra image deps and never touches originals.
 */
import sharp from "sharp";
import type { OverlayOptions } from "sharp";
import { resolveThemeTokens, themeSpecSchema, type ThemeSpec } from "@storesnap/shared";

export const DROP_W = 1200;
export const DROP_H = 630;
const GUTTER = 4;
const MAX_TILES = 4;

export interface DropCardSpec {
  /** Up to four item photos, in collection order. Fewer is fine. */
  photos: Buffer[];
  title: string;
  storeName: string;
  itemCount: number;
  minPriceKes: number;
  maxPriceKes: number;
  theme: unknown;
}

function xmlEscape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Corrupt/unknown themes snap back to the default preset (never break). */
function accentOf(theme: unknown): string {
  const parsed = themeSpecSchema.safeParse(theme);
  const spec: ThemeSpec =
    parsed.success ? parsed.data : { schemaVersion: 1, preset: "pro-light", overrides: {} };
  return resolveThemeTokens(spec).accent;
}

function priceRange(min: number, max: number): string {
  const low = min.toLocaleString("en-KE");
  if (min === max) return `KSh ${low}`;
  return `KSh ${low} - ${max.toLocaleString("en-KE")}`;
}

/** Font sizes step down as the title grows so it always fits two lines. */
function titleFontSize(title: string): number {
  if (title.length <= 22) return 66;
  if (title.length <= 34) return 54;
  return 44;
}

/** Hard-wrap a title onto at most two lines. */
function wrapTitle(title: string, perLine: number): string[] {
  const words = title.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current === "" ? word : `${current} ${word}`;
    if (candidate.length <= perLine || current === "") {
      current = candidate;
    } else {
      lines.push(current);
      current = word;
    }
  }
  if (current !== "") lines.push(current);
  if (lines.length <= 2) return lines;
  const kept = lines.slice(0, 2);
  kept[1] = `${kept[1]!.slice(0, Math.max(0, perLine - 3)).trimEnd()}...`;
  return kept;
}

function dropSvg(spec: DropCardSpec, accent: string): string {
  const font = titleFontSize(spec.title);
  const perLine = Math.floor((DROP_W - 112) / (font * 0.52));
  const lines = wrapTitle(spec.title, perLine);
  const firstLineY = lines.length > 1 ? 496 : 528;
  const titleLines = lines
    .map(
      (line, i) =>
        `<text x="56" y="${firstLineY + i * (font + 6)}" font-family="sans-serif" font-size="${font}" font-weight="700" fill="#FFFFFF">${xmlEscape(line)}</text>`,
    )
    .join("\n  ");
  const meta = `${xmlEscape(spec.storeName.toUpperCase())}  ·  ${priceRange(spec.minPriceKes, spec.maxPriceKes)}`;
  const countLabel = spec.itemCount === 1 ? "1 ITEM" : `${spec.itemCount} ITEMS`;
  const chipWidth = 40 + countLabel.length * 24;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${DROP_W}" height="${DROP_H}">
  <defs>
    <linearGradient id="scrim" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#000000" stop-opacity="0"/>
      <stop offset="0.55" stop-color="#000000" stop-opacity="0.55"/>
      <stop offset="1" stop-color="#000000" stop-opacity="0.92"/>
    </linearGradient>
  </defs>
  <rect x="0" y="300" width="${DROP_W}" height="330" fill="url(#scrim)"/>
  <rect x="56" y="352" width="${chipWidth}" height="62" rx="14" fill="${accent}"/>
  <text x="${56 + chipWidth / 2}" y="393" text-anchor="middle" font-family="sans-serif" font-size="30" font-weight="700" letter-spacing="3" fill="#FFFFFF">${xmlEscape(countLabel)}</text>
  ${titleLines}
  <text x="56" y="602" font-family="sans-serif" font-size="30" font-weight="600" letter-spacing="2" fill="rgba(255,255,255,0.92)">${meta}</text>
</svg>`;
}

/** Tile geometry: one big frame for a single photo, 2x2 from two upwards. */
function tileLayout(count: number): Array<{ left: number; top: number; width: number; height: number }> {
  if (count <= 1) return [{ left: 0, top: 0, width: DROP_W, height: DROP_H }];
  if (count === 2) {
    const w = Math.floor((DROP_W - GUTTER) / 2);
    return [
      { left: 0, top: 0, width: w, height: DROP_H },
      { left: w + GUTTER, top: 0, width: DROP_W - w - GUTTER, height: DROP_H },
    ];
  }
  const w = Math.floor((DROP_W - GUTTER) / 2);
  const h = Math.floor((DROP_H - GUTTER) / 2);
  const layout = [
    { left: 0, top: 0, width: w, height: h },
    { left: w + GUTTER, top: 0, width: DROP_W - w - GUTTER, height: h },
    { left: 0, top: h + GUTTER, width: w, height: DROP_H - h - GUTTER },
    { left: w + GUTTER, top: h + GUTTER, width: DROP_W - w - GUTTER, height: DROP_H - h - GUTTER },
  ];
  return layout.slice(0, Math.min(count, MAX_TILES));
}

export async function renderDropCard(spec: DropCardSpec): Promise<Buffer> {
  const accent = accentOf(spec.theme);
  const photos = spec.photos.slice(0, MAX_TILES);
  const canvas = sharp({
    create: {
      width: DROP_W,
      height: DROP_H,
      channels: 3,
      background: { r: 24, g: 24, b: 27 },
    },
  });

  const composites: OverlayOptions[] = [];
  if (photos.length > 0) {
    const layout = tileLayout(photos.length);
    const tiles = await Promise.all(
      photos.map(async (photo, i) => {
        const tile = layout[i]!;
        return sharp(photo, { failOn: "none" })
          .resize(tile.width, tile.height, { fit: "cover", position: "attention" })
          .toBuffer();
      }),
    );
    tiles.forEach((buffer, i) => {
      const tile = layout[i]!;
      composites.push({ input: buffer, left: tile.left, top: tile.top });
    });
  }

  composites.push({ input: Buffer.from(dropSvg(spec, accent)), left: 0, top: 0 });

  return canvas.composite(composites).webp({ quality: 80, effort: 4 }).toBuffer();
}
