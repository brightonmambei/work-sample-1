/**
 * Share module v1: canonical /p/:code links for every listing.
 * Bots (WhatsApp/Telegram/Facebook scrapers) get server-rendered OG HTML;
 * humans get redirected to the SPA product page.
 */
import express from "express";
import { requireAuth } from "../../middleware/auth.js";
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { ok } from "../../middleware/error.js";
import { config } from "../../config.js";
import { getObject, putObject } from "../../lib/objectstore.js";
import { renderStatusPoster } from "./poster.js";
import { composeCaption } from "./caption.js";
import { publicBaseUrl, storage } from "../media/storage.js";
import { collectionsService } from "../collections/service.js";

export const shareRouter = express.Router();

const BOT_PATTERNS = [
  "WhatsApp",
  "facebookexternalhit",
  "Facebot",
  "TelegramBot",
  "Slackbot",
  "Twitterbot",
  "LinkedInBot",
  "embedly",
  "vkShare",
];

export function isBot(userAgent: string | undefined): boolean {
  if (!userAgent) return false;
  const ua = userAgent.toLowerCase();
  return BOT_PATTERNS.some((p) => ua.includes(p.toLowerCase()));
}

/** Escape for the small SSR snippet; no full HTML renderer in Phase 2. */
function escapeHtml(text: string): string {
  return text
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function truncate(text: string, max: number): string {
  return text.length <= max ? text : `${text.slice(0, max - 1).trimEnd()}...`;
}


/** Preserve the attribution tag through the attacker-safe redirect. */
function channelParam(channel: string): string {
  return channel ? `?r=${encodeURIComponent(channel)}` : "";
}

/**
 * A canonical code belongs to exactly one subject: an item or a collection
 * (drop). Share links are created lazily for items, so a code can be posted
 * before its link row exists; resolve through both tables either way.
 */
type ShareSubject =
  | { kind: "listing"; id: string; linkId: string | null }
  | { kind: "collection"; id: string; linkId: string | null };

async function resolveShareSubject(code: string): Promise<ShareSubject | null> {
  const link = await prisma.shareLink.findUnique({
    where: { code },
    select: { id: true, listingId: true, collectionId: true },
  });
  if (link?.collectionId) return { kind: "collection", id: link.collectionId, linkId: link.id };
  if (link?.listingId) return { kind: "listing", id: link.listingId, linkId: link.id };

  const listing = await prisma.listing.findUnique({ where: { code }, select: { id: true } });
  if (listing) return { kind: "listing", id: listing.id, linkId: null };
  const collection = await prisma.collection.findUnique({ where: { code }, select: { id: true } });
  if (collection) return { kind: "collection", id: collection.id, linkId: null };
  return null;
}

/** The tiny SSR snippet scrapers read. No app shell, no JS. */
function sendOgHtml(
  res: express.Response,
  page: {
    title: string;
    description: string;
    imageUrl: string;
    siteName: string;
    type: string;
    redirectTo: string;
  },
): void {
  res
    .status(200)
    .set("Content-Type", "text/html; charset=utf-8")
    .set("Cache-Control", "public, max-age=300")
    .send(
      [
        "<!doctype html>",
        '<html lang="en"><head><meta charset="utf-8">',
        `<title>${escapeHtml(page.title)}</title>`,
        `<meta property="og:title" content="${escapeHtml(page.title)}">`,
        `<meta property="og:description" content="${escapeHtml(page.description)}">`,
        page.imageUrl ? `<meta property="og:image" content="${escapeHtml(page.imageUrl)}">` : "",
        `<meta property="og:site_name" content="${escapeHtml(page.siteName)}">`,
        `<meta property="og:type" content="${page.type}">`,
        `<meta name="twitter:card" content="summary_large_image">`,
        `<meta http-equiv="refresh" content="0;url=${escapeHtml(page.redirectTo)}">`,
        "</head><body></body></html>",
      ]
        .filter(Boolean)
        .join("\n"),
    );
}

/** Sold items keep their page; drafts and archived ones fall back to the store. */
async function serveItemUnfurl(opts: {
  code: string;
  channel: string;
  listingId: string;
  req: express.Request;
  res: express.Response;
}): Promise<void> {
  const { code, channel, req, res } = opts;
  const listing = await prisma.listing.findUnique({
    where: { id: opts.listingId },
    select: {
      title: true,
      description: true,
      priceKes: true,
      compareAtKes: true,
      condition: true,
      stock: true,
      status: true,
      updatedAt: true,
      ogVersion: true,
      store: {
        select: { slug: true, name: true, tagline: true, status: true },
      },
      media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" }], take: 1 },
    },
  });

  if (!listing || listing.store.status !== "active") {
    throw new ApiError(404, "LISTING_NOT_FOUND", "Item link not found.");
  }

  const humanPath = `/s/${listing.store.slug}/p/${code}`;

  // Sold items keep their link alive: no dead group-chat links (invariant 5).
  if (listing.status === "archived" || (listing.status === "sold_out" && listing.stock <= 0)) {
    res.redirect(302, `${humanPath}${channelParam(channel)}`);
    return;
  }
  if (listing.status !== "active") {
    res.redirect(302, `/s/${listing.store.slug}`);
    return;
  }

  if (isBot(req.headers["user-agent"])) {
    const img = listing.media[0]?.cardKey ?? listing.media[0]?.thumbKey ?? null;
    // Version suffix: WhatsApp caches unfurls aggressively, so the card URL
    // changes whenever the item does (or when the seller asks for a refresh).
    const version = unfurlVersion(listing.updatedAt, listing.ogVersion);
    const imageUrl = img ? `${publicBaseUrl()}/${img}?v=${version}` : "";
    const priceLine = `KSh ${listing.priceKes.toLocaleString("en-KE")}${
      listing.compareAtKes && listing.compareAtKes > listing.priceKes
        ? ` (was KSh ${listing.compareAtKes.toLocaleString("en-KE")})`
        : ""
    }`;
    const conditionLine = listing.condition === "thrift" ? "Thrift condition" : "Brand new";
    sendOgHtml(res, {
      title: truncate(listing.title, 60),
      description: truncate(`${priceLine} - ${conditionLine} - ${listing.store.name}`, 160),
      imageUrl,
      siteName: listing.store.name,
      type: "product",
      redirectTo: humanPath + channelParam(channel),
    });
    return;
  }

  // Human: through to the SPA route (humanPath) with a lightweight relink.
  res.redirect(302, humanPath + channelParam(channel));
}

/**
 * A drop unfurls as one post for many items: the generated collage is the
 * og:image and the description carries the item count and price range.
 */
async function serveCollectionUnfurl(opts: {
  code: string;
  channel: string;
  collectionId: string;
  req: express.Request;
  res: express.Response;
}): Promise<void> {
  const { code, channel, req, res } = opts;
  const row = await prisma.collection.findUnique({
    where: { id: opts.collectionId },
    select: {
      title: true,
      status: true,
      cardKey: true,
      updatedAt: true,
      ogVersion: true,
      store: { select: { slug: true, name: true, status: true } },
      items: {
        orderBy: [{ sortOrder: "asc" }, { id: "asc" }],
        select: {
          listing: {
            select: {
              title: true,
              priceKes: true,
              status: true,
              media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" }], take: 1 },
            },
          },
        },
      },
    },
  });

  if (!row || row.store.status !== "active") {
    throw new ApiError(404, "COLLECTION_NOT_FOUND", "Drop link not found.");
  }

  const humanPath = `/s/${row.store.slug}/c/${code}`;
  const items = row.items
    .map((i) => i.listing)
    .filter((l) => ["active", "paused", "sold_out"].includes(l.status));
  const prices = items.map((i) => i.priceKes);
  const min = prices.length > 0 ? Math.min(...prices) : 0;
  const max = prices.length > 0 ? Math.max(...prices) : 0;

  // Prefer the collage; fall back to the first item's photo so a drop is never
  // imageless in a group chat (a plain link converts far worse).
  const fallbackImg =
    items.map((i) => i.media[0]?.cardKey ?? i.media[0]?.thumbKey ?? null).find((k) => k !== null) ??
    null;
  const imgKey = row.cardKey ?? fallbackImg;
  const version = unfurlVersion(row.updatedAt, row.ogVersion);
  const imageUrl = imgKey ? `${publicBaseUrl()}/${imgKey}?v=${version}` : "";

  const kes = (n: number): string => `KSh ${n.toLocaleString("en-KE")}`;
  const range =
    items.length === 0 ? "" : min === max ? kes(min) : `${kes(min)} - ${kes(max)}`;
  const title = truncate(row.title, 60);
  const description =
    row.status === "archived"
      ? truncate(`This drop has ended - ${row.store.name}`, 160)
      : items.length === 0
        ? truncate(`Restocking - ${row.store.name}`, 160)
        : truncate(
            `${items.length === 1 ? "1 item" : `${items.length} items`} - ${range} - ${row.store.name}`,
            160,
          );

  if (isBot(req.headers["user-agent"])) {
    sendOgHtml(res, {
      title,
      description,
      imageUrl,
      siteName: row.store.name,
      type: "website",
      redirectTo: humanPath + channelParam(channel),
    });
    return;
  }

  res.redirect(302, humanPath + channelParam(channel));
}

shareRouter.get("/:code", async (req, res, next) => {
  try {
    const code = (req.params.code ?? "").toLowerCase();
    const channel = typeof req.query.r === "string" ? req.query.r.slice(0, 40) : "";

    const subject = await resolveShareSubject(code);
    if (!subject) {
      throw new ApiError(404, "SHARE_LINK_NOT_FOUND", "This link is not available.");
    }

    // Attribution event: fire-and-log; a failed write never blocks the buyer.
    if (subject.linkId !== null) {
      const linkId = subject.linkId;
      void prisma.shareEvent
        .create({ data: { shareLinkId: linkId, type: "view", channel } })
        .catch(() => undefined);
    }

    if (subject.kind === "collection") {
      await serveCollectionUnfurl({ code, channel, collectionId: subject.id, req, res });
      return;
    }
    await serveItemUnfurl({ code, channel, listingId: subject.id, req, res });
  } catch (err) {
    next(err);
  }
});

/**
 * Cache-busting version for og:image. Content edits move it through updatedAt;
 * an explicit "refresh preview" moves it further. Base36 keeps it short.
 */
function unfurlVersion(updatedAt: Date, ogVersion: Date | null): string {
  const stamp = Math.max(updatedAt.getTime(), ogVersion?.getTime() ?? 0);
  return stamp.toString(36);
}

/** Seller-side: fetch (or lazily create) the share link for one listing. */
export const sellerShareRouter = express.Router();
sellerShareRouter.use(requireAuth);
sellerShareRouter.use(express.json());

/** Generate the 9:16 status poster (1080x1920) from the hero photo. */
sellerShareRouter.post("/poster", async (req, res, next) => {
  try {
    const listingId = typeof req.body?.listingId === "string" ? req.body.listingId : "";
    const listing = await prisma.listing.findUnique({
      where: { id: listingId },
      select: {
        id: true,
        priceKes: true,
        compareAtKes: true,
        condition: true,
        conditionGrade: true,
        storeId: true,
        store: { select: { ownerId: true, name: true, theme: true } },
        media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" }], take: 1 },
      },
    });
    if (!listing) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    if (listing.store.ownerId !== req.auth?.userId) {
      throw new ApiError(403, "FORBIDDEN", "Not your item.");
    }

    const hero = listing.media[0];
    const heroKey = hero?.fullKey ?? hero?.cardKey ?? hero?.thumbKey ?? null;
    if (heroKey === null) {
      throw new ApiError(422, "NO_HERO_PHOTO", "Add a photo before generating a poster.");
    }

    // Versioned key: each regeneration gets a fresh cache identity, so the
    // group never sticks to a stale preview (WhatsApp caches unfurls hard).
    const version = Date.now().toString(36);
    const key = `share/${listing.id}/poster/${version}.webp`;
    const photo = await getObject(heroKey);
    const buffer = await renderStatusPoster({
      photo,
      storeName: listing.store.name,
      priceKes: listing.priceKes,
      compareAtKes: listing.compareAtKes,
      condition: listing.condition,
      conditionGrade: listing.conditionGrade,
      theme: listing.store.theme,
    });
    await putObject(key, buffer);

    ok(res, { posterUrl: storage.urlFor(key), key, version });
  } catch (err) {
    next(err);
  }
});

sellerShareRouter.get("/links/:listingId", async (req, res, next) => {
  try {
    const listing = await prisma.listing.findFirst({
      where: { id: req.params.listingId ?? "" },
      select: {
        id: true,
        code: true,
        storeId: true,
        title: true,
        priceKes: true,
        compareAtKes: true,
        condition: true,
        conditionGrade: true,
        stock: true,
        store: { select: { ownerId: true, name: true, locationLabel: true } },
      },
    });
    if (!listing) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    if (!listing.store || listing.store.ownerId !== req.auth?.userId) {
      throw new ApiError(403, "FORBIDDEN", "Not your item.");
    }

    // Canonical link (AGENTS.md section 8): the copied link is the bot
    // unfurl route (/p/{code}), which serves OG HTML to WhatsApp/Telegram
    // scrapers and 302s humans to the slug storefront item page. Copying the
    // SPA path directly would unfurl as a bare title: scrapers do not run JS.
    const shareUrl = `${config.siteUrl}/p/${listing.code.toLowerCase()}`;

    const existing = await prisma.shareLink.findUnique({
      where: { code: listing.code.toLowerCase() },
      select: { id: true },
    });
    const shareLinkId =
      existing?.id ??
      (await prisma.shareLink.create({ data: { listingId: listing.id, code: listing.code.toLowerCase() } }))
        .id;

    ok(res, {
      shareUrl,
      shareLinkId,
      listingCode: listing.code.toLowerCase(),
      caption: composeCaption({
        title: listing.title,
        priceKes: listing.priceKes,
        compareAtKes: listing.compareAtKes,
        condition: listing.condition,
        conditionGrade: listing.conditionGrade,
        stock: listing.stock,
        storeName: listing.store.name,
        locationLabel: listing.store.locationLabel,
        url: shareUrl,
      }),
    });
  } catch (err) {
    next(err);
  }
});

/**
 * Refresh the unfurl: bump the version suffix on the og:image so the next
 * scrape (and any group that re-reads the link) picks up new media or copy
 * instead of WhatsApp's cached card. Works for items and drops alike.
 */
sellerShareRouter.post("/refresh", async (req, res, next) => {
  try {
    const collectionId = typeof req.body?.collectionId === "string" ? req.body.collectionId : "";
    if (collectionId !== "") {
      const collection = await prisma.collection.findFirst({
        where: { id: collectionId },
        select: { id: true, code: true, storeId: true, store: { select: { ownerId: true } } },
      });
      if (!collection) {
        throw new ApiError(404, "COLLECTION_NOT_FOUND", "Drop not found.");
      }
      if (collection.store?.ownerId !== req.auth?.userId) {
        throw new ApiError(403, "FORBIDDEN", "Not your drop.");
      }
      const version = new Date();
      await prisma.collection.update({
        where: { id: collection.id },
        data: { ogVersion: version, updatedAt: version },
      });
      // Re-render too: a refresh is exactly when stale photos must be replaced.
      await collectionsService.refreshCard(collection.id);
      ok(res, {
        shareUrl: `${config.siteUrl}/p/${collection.code.toLowerCase()}`,
        refreshedAt: version.toISOString(),
      });
      return;
    }

    const listingId = typeof req.body?.listingId === "string" ? req.body.listingId : "";
    const listing = await prisma.listing.findFirst({
      where: { id: listingId },
      select: { id: true, code: true, store: { select: { ownerId: true } } },
    });
    if (!listing) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    if (!listing.store || listing.store.ownerId !== req.auth?.userId) {
      throw new ApiError(403, "FORBIDDEN", "Not your item.");
    }

    const version = new Date();
    await prisma.listing.update({ where: { id: listing.id }, data: { ogVersion: version } });
    ok(res, {
      shareUrl: `${config.siteUrl}/p/${listing.code.toLowerCase()}`,
      refreshedAt: version.toISOString(),
    });
  } catch (err) {
    next(err);
  }
});

/** Attribution beacon on the human product page (tap-through counting). */
shareRouter.post("/:code/event", async (req, res, next) => {
  try {
    const code = (req.params.code ?? "").toLowerCase();
    const body = req.body as { type?: unknown; channel?: unknown };
    const type = body.type === "tap" ? "tap" : "view";
    const channel = typeof body.channel === "string" ? body.channel.slice(0, 40) : "";

    const link = await prisma.shareLink.findUnique({
      where: { code },
      select: { id: true },
    });
    if (!link) {
      ok(res, { recorded: false });
      return;
    }
    await prisma.shareEvent.create({
      data: { shareLinkId: link.id, type, channel },
    });
    ok(res, { recorded: true });
  } catch (err) {
    // Eventual telemetry: never surface to buyers.
    res.status(200).json({ ok: true, data: { recorded: false } });
    void next;
  }
});
