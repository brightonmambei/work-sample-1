/**
 * Share attribution (AGENTS.md section 8): view events are logged at the
 * share-link redirect; the buyer actually landing on the item page (SPA
 * fetch) is the tap. Fire-and-log: attribution must never block a buyer.
 */
import { prisma } from "../../lib/prisma.js";

export const shareService = {
  /** Record a tap event for a resolved share link. Silently best-effort. */
  recordTap(shareLinkId: string | null, channel: string): void {
    if (shareLinkId === null) return;
    void prisma.shareEvent
      .create({
        data: { shareLinkId, type: "tap", channel: channel.slice(0, 40) },
      })
      .catch(() => undefined);
  },
};
