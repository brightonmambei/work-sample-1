/**
 * 9:16 status poster (AGENTS.md section 8): the auto-generated version of a
 * seller's hand-made Canva poster for Instagram/WhatsApp status. Full-bleed
 * garment photo, price in the store's accent, condition line, store name.
 * Rendered with sharp + an SVG overlay so the worker/API needs no extra
 * image deps; originals are never modified.
 */
import sharp from "sharp";
import { resolveThemeTokens, themeSpecSchema, type ThemeSpec } from "@storesnap/shared";

export const POSTER_W = 1080;
export const POSTER_H = 1920;

export interface PosterSpec {
  photo: Buffer;
  storeName: string;
  priceKes: number;
  compareAtKes: number | null;
  condition: string;
  conditionGrade: number | null;
  theme: unknown;
}

function xmlEscape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Corrupt/unknown themes snap back to the default preset (never break). */
function accentOf(theme: unknown): string {
  const parsed = themeSpecSchema.safeParse(theme);
  const spec: ThemeSpec =
    parsed.success ? parsed.data : { schemaVersion: 1, preset: "pro-light", overrides: {} };
  return resolveThemeTokens(spec).accent;
}

function conditionLine(spec: PosterSpec): string {
  if (spec.condition === "thrift") {
    const grade =
      spec.conditionGrade !== null ? ` - GRADE ${spec.conditionGrade}` : "";
    return `THRIFT FIND${grade}`;
  }
  return "BRAND NEW";
}

function posterSvg(spec: PosterSpec, accent: string): string {
  const kes = spec.priceKes.toLocaleString("en-KE");
  const compare =
    spec.compareAtKes !== null && spec.compareAtKes > spec.priceKes
      ? `<text x="${POSTER_W - 80}" y="1566" text-anchor="end" font-family="sans-serif" font-size="52" fill="rgba(255,255,255,0.72)" text-decoration="line-through">KES ${spec.compareAtKes.toLocaleString("en-KE")}</text>`
      : "";
  const store = xmlEscape(spec.storeName.toUpperCase());

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${POSTER_W}" height="${POSTER_H}">
  <defs>
    <linearGradient id="scrim" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#000000" stop-opacity="0"/>
      <stop offset="1" stop-color="#000000" stop-opacity="0.88"/>
    </linearGradient>
  </defs>

  <!-- readable top pill: item stays the hero of the frame -->
  <rect x="0" y="0" width="${POSTER_W}" height="340" fill="url(#scrim)" opacity="0.4"/>
  <text x="80" y="196" font-family="sans-serif" font-size="46" font-weight="600" letter-spacing="10" fill="#FFFFFF">${conditionLine(spec)}</text>

  <!-- lower third: price, accent rule, store -->
  <rect x="0" y="1180" width="${POSTER_W}" height="${POSTER_H - 1180}" fill="url(#scrim)"/>
  <rect x="80" y="1690" width="196" height="72" rx="14" fill="${accent}"/>
  <text x="130" y="1738" font-family="sans-serif" font-size="44" font-weight="600" letter-spacing="6" fill="#FFFFFF">KES</text>
  <text x="312" y="1786" font-family="sans-serif" font-size="150" font-weight="700" fill="#FFFFFF">${kes}</text>
  ${compare}
  <text x="80" y="1876" font-family="sans-serif" font-size="44" fill="rgba(255,255,255,0.92)">${store}</text>
</svg>`;
}

/**
 * Compose the 1080x1920 poster: subject-aware cover crop keeps the garment
 * framed, the overlay carries the numbers. WebP q80- mirrors the variant
 * pipeline; versioned keys (timestamp) keep WhatsApp's cache honest.
 */
export async function renderStatusPoster(spec: PosterSpec): Promise<Buffer> {
  const accent = accentOf(spec.theme);
  const overlay = Buffer.from(posterSvg(spec, accent));
  return sharp(spec.photo, { failOn: "none" })
    .resize(POSTER_W, POSTER_H, { fit: "cover", position: "attention" })
    .composite([{ input: overlay }])
    .webp({ quality: 80, effort: 4 })
    .toBuffer();
}
