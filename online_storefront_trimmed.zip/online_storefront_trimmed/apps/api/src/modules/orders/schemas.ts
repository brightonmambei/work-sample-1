import { z } from "zod";

/* ------------------------------- contracts ------------------------------- */

export const checkoutItemSchema = z.object({
  listingId: z.string().min(4),
  quantity: z.number().int().min(1).max(10).default(1),
  size: z.string().max(24).optional(),
  color: z.string().max(24).optional(),
});
export type CheckoutItem = z.infer<typeof checkoutItemSchema>;

/** Buyer checkout: minimum friction, server validates stock and snapshots. */
export const createOrderSchema = z.object({
  buyerName: z.string().trim().min(2, "Give the buyer a readable name.").max(80),
  buyerPhone: z
    .string()
    .trim()
    .regex(/^[+0-9 ()-]{9,20}$/, "Use a reachable phone number."),
  buyerLocation: z.string().trim().max(120).optional().nullable(),
  fulfillment: z.enum(["pickup", "delivery"]).default("pickup"),
  paymentMethod: z.enum(["mpesa", "pochi", "cash", "other"]).default("mpesa"),
  note: z.string().trim().max(500).optional().nullable(),
  items: z.array(checkoutItemSchema).min(1, "Add at least one item.").max(20),
});
export type CreateOrderInput = z.infer<typeof createOrderSchema>;

export const orderTransitionSchema = z.object({
  status: z.enum(["confirmed", "out", "fulfilled", "cancelled"]),
});
export type OrderTransition = z.infer<typeof orderTransitionSchema>;

/* Sale Recorder: self-reported book of WhatsApp-settled sales (Phase 3 MVP). */
export const selfReportSchema = z.object({
  title: z.string().trim().min(1).max(140),
  amountKes: z.number().int().min(1).max(10_000_000),
  quantity: z.number().int().min(1).max(500).default(1),
  buyerName: z.string().trim().max(80).optional().nullable(),
  buyerPhone: z.string().trim().max(20).optional().nullable(),
  listingId: z.string().optional().nullable(),
  note: z.string().trim().max(500).optional().nullable(),
});
export type SelfReportInput = z.infer<typeof selfReportSchema>;

export const holdSchema = z.object({
  listingId: z.string().min(4),
  quantity: z.number().int().min(1).max(5).default(1),
  size: z.string().max(24).optional(),
  color: z.string().max(24).optional(),
});
export type HoldInput = z.infer<typeof holdSchema>;

/* --------------------------- buyer-facing shape -------------------------- */

export const publicOrderSchema = z.object({
  token: z.string(),
  status: z.string(),
  buyerName: z.string(),
  buyerPhone: z.string(),
  buyerLocation: z.string().nullable(),
  fulfillment: z.enum(["pickup", "delivery"]),
  paymentMethod: z.string(),
  note: z.string().nullable(),
  totalKes: z.number(),
  createdAt: z.string(),
  store: z.object({ slug: z.string(), name: z.string(), whatsappNumber: z.string().nullable() }),
  items: z.array(
    z.object({
      title: z.string(),
      priceKes: z.number(),
      compareAtKes: z.number().nullable(),
      condition: z.string(),
      quantity: z.number(),
      size: z.string().nullable(),
      color: z.string().nullable(),
    }),
  ),
});
export type PublicOrder = z.infer<typeof publicOrderSchema>;
