import express from "express";
import { ApiError } from "../../errors.js";
import { ok } from "../../middleware/error.js";
import { requireRole } from "../../middleware/auth.js";
import { requireStoreOwnership } from "../../middleware/store.js";
import { validateBody } from "../../middleware/validate.js";
import {
  createOrderSchema,
  holdSchema,
  orderTransitionSchema,
  selfReportSchema,
} from "./schemas.js";
import { ordersService } from "./service.js";

function requireStoreContext(res: express.Response): string {
  const storeId = res.locals?.storeId as string | undefined;
  if (!storeId) {
    throw new ApiError(404, "STORE_NOT_FOUND", "Store not found for this address.");
  }
  return storeId;
}

/**
 * Buyer-side orders: reuses the /market host resolution that runs before this
 * router (tenant scope), zero auth, screenshot-out confirmation flow.
 */
export const publicOrdersRouter = express.Router();

publicOrdersRouter.post("/orders", validateBody(createOrderSchema), async (req, res, next) => {
  try {
    const storeId = requireStoreContext(res);
    const result = await ordersService.create(storeId, req.body);
    const order = await ordersService.byToken(result.token);
    ok(res, { order: { token: result.token, ...order } }, 201);
  } catch (err) {
    next(err);
  }
});

/** Buyer tracking by unguessable token (no login shareable link). */
publicOrdersRouter.get("/orders/:token", async (req, res, next) => {
  try {
    const order = await ordersService.byToken(req.params.token ?? "");
    if (order === null) {
      throw new ApiError(404, "ORDER_NOT_FOUND", "We could not find that order. Check the link.");
    }
    ok(res, { order });
  } catch (err) {
    next(err);
  }
});

/** Checkout-readiness for one item (live stock minus holds). */
publicOrdersRouter.get("/checkout/:listingId", async (req, res, next) => {
  try {
    const storeId = requireStoreContext(res);
    const listing = await ordersService.listingForCheckout(storeId, req.params.listingId ?? "");
    if (listing === null) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    ok(res, {
      listing: {
        id: listing.id,
        code: listing.code,
        title: listing.title,
        stock: listing.stock,
        sizes: listing.sizes,
        colors: listing.colors,
        priceKes: listing.priceKes,
        compareAtKes: listing.compareAtKes,
        condition: listing.condition,
      },
    });
  } catch (err) {
    next(err);
  }
});

/* ------------------------------- seller side ----------------------------- */

export const sellerOrdersRouter = express.Router();
sellerOrdersRouter.use(requireRole("seller", "platform_owner"), requireStoreOwnership);

sellerOrdersRouter.get("/orders", async (req, res, next) => {
  try {
    const status = typeof req.query.status === "string" ? req.query.status : undefined;
    ok(res, { orders: await ordersService.listForStore(req.storeOwnership!.storeId, status) });
  } catch (err) {
    next(err);
  }
});

sellerOrdersRouter.post(
  "/orders/:id/transition",
  validateBody(orderTransitionSchema),
  async (req, res, next) => {
    try {
      await ordersService.transition(req.storeOwnership!.storeId, String(req.params.id ?? ""), req.body.status);
      ok(res, { updated: true });
    } catch (err) {
      next(err);
    }
  },
);

/** Sale Recorder (self-report, book entries, feeds usage ledger). */
sellerOrdersRouter.post(
  "/sales/self-report",
  validateBody(selfReportSchema),
  async (req, res, next) => {
    try {
      const created = await ordersService.selfReport(req.storeOwnership!.storeId, req.body);
      ok(res, { sale: created }, 201);
    } catch (err) {
      next(err);
    }
  },
);

sellerOrdersRouter.get("/usage/summary", async (req, res, next) => {
  try {
    ok(res, { usage: await ordersService.usageSummary(req.storeOwnership!.storeId) });
  } catch (err) {
    next(err);
  }
});

/** Tier-gated 15-minute hold (Commerce+). */
sellerOrdersRouter.post("/holds", validateBody(holdSchema), async (req, res, next) => {
  try {
    const hold = await ordersService.hold(req.storeOwnership!.storeId, req.body);
    ok(res, { hold }, 201);
  } catch (err) {
    next(err);
  }
});
