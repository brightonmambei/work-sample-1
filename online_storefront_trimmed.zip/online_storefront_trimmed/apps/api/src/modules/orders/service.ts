/**
 * Orders service: the transactional core of Phase 3.
 *
 * Checkout runs inside ONE transaction:
 *   validate active listings -> validate stock (minus live holds for Pro
 *   tiers) -> snapshot prices -> decrement stock -> create order + items.
 * Oversell is a bug class, not a corner case (invariant 2); prices are
 * snapshotted at order time and never re-read (invariant 1).
 *
 * Money never moves through this module: `paymentMethod` is annotation only.
 */
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { plans } from "@storesnap/shared";
import type { OrderStatus } from "@prisma/client";
import type { CreateOrderInput, SelfReportInput } from "./schemas.js";

function newToken(): string {
  return cryptoRandomUrl();
}

/* 18-char unguessable tracking token. */
function cryptoRandomUrl(): string {
  const bytes = new Uint8Array(14);
  globalThis.crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += "abcdefghijkmnpqrstuvwxyz23456789"[b % 30]!;
  return out;
}

function activeHoldQuantity(listingId: string): Promise<number> {
  return prisma.hold
    .aggregate({
      where: { listingId, expiresAt: { gt: new Date() } },
      _sum: { quantity: true },
    })
    .then((r) => r._sum.quantity ?? 0);
}

export const ordersService = {
  /**
   * Transactional checkout. Caller passes a host-resolved storeId so buyers
   * on `{slug}.shops...` can only order that store's items.
   */
  async create(storeId: string, input: CreateOrderInput): Promise<{ token: string; id: string }> {
    // The storefront's public shape only carries the share code, so cart items
    // arrive keyed by code; older clients/tests may send real ids. Accept both.
    const listingIds = input.items.map((i) => i.listingId);
    const rows = await prisma.listing.findMany({
      where: {
        OR: [{ id: { in: listingIds } }, { code: { in: listingIds } }],
        storeId,
        status: "active",
      },
      select: {
        id: true, code: true, title: true, priceKes: true, compareAtKes: true,
        condition: true, stock: true, sizes: true, colors: true,
      },
    });
    const byId = new Map(rows.map((r) => [r.id, r]));
    const byCode = new Map(rows.map((r) => [r.code, r]));
    const resolveListing = (key: string) => byCode.get(key) ?? byId.get(key);

    const tier = await prisma.store
      .findUnique({ where: { id: storeId }, select: { plan: true } })
      .then((s) => (s?.plan ?? "grow") as keyof typeof plans);
    const holdsEnabled = plans[tier]?.holdTimers === true;

    // Bulked holds lookup: all live holds for these listings (real ids).
    const holdRows = holdsEnabled
      ? await prisma.hold.groupBy({
          by: ["listingId"],
          where: {
            listingId: { in: rows.map((r) => r.id) },
            expiresAt: { gt: new Date() },
          },
          _sum: { quantity: true },
        })
      : [];
    const holdsByListing = new Map(holdRows.map((h) => [h.listingId, h._sum.quantity ?? 0]));

    // Validate quantities and requested variants up front (cheap reads).
    for (const item of input.items) {
      const listing = resolveListing(item.listingId);
      if (!listing) {
        throw new ApiError(404, "LISTING_NOT_FOUND", "One of the items is no longer available.");
      }
      if (listing.stock <= 0) {
        throw new ApiError(409, "SOLD_OUT", `${listing.title} is sold out.`);
      }
      const available = listing.stock - (holdsByListing.get(listing.id) ?? 0);
      if (item.quantity > available) {
        throw new ApiError(
          409,
          "INSUFFICIENT_STOCK",
          `Only ${Math.max(available, 0)} of ${listing.title} left.`,
        );
      }
      if (item.size !== undefined && listing.sizes.length > 0 && !listing.sizes.includes(item.size)) {
        throw new ApiError(422, "VALIDATION", `${listing.title} does not come in ${item.size}.`);
      }
      if (item.color !== undefined && listing.colors.length > 0 && !listing.colors.includes(item.color)) {
        throw new ApiError(422, "VALIDATION", `${listing.title} does not come in ${item.color}.`);
      }
    }

    const token = newToken();

    // One transaction: price snapshot + stock decrement + order row.
    // The listing update guards stock with a direct WHERE stock >= qty.
    const order = await prisma.$transaction(async (tx) => {
      let total = 0;
      const itemsPayload: Array<{
        listingId: string;
        title: string;
        priceKes: number;
        compareAtKes: number | null;
        condition: string;
        quantity: number;
        size: string | null;
        color: string | null;
      }> = [];

      for (const item of input.items) {
        const listing = resolveListing(item.listingId)!;
        // Conditional decrement: row-level guard against racing checkouts.
        const updated = await tx.listing.updateMany({
          where: { id: listing.id, stock: { gte: item.quantity } },
          data: { stock: { decrement: item.quantity } },
        });
        if (updated.count !== 1) {
          throw new ApiError(409, "INSUFFICIENT_STOCK", `${listing.title} just sold out.`);
        }
        // Invariant 1: snapshot what the buyer actually saw.
        itemsPayload.push({
          listingId: listing.id,
          title: listing.title,
          priceKes: listing.priceKes,
          compareAtKes: listing.compareAtKes,
          condition: listing.condition,
          quantity: item.quantity,
          size: item.size ?? null,
          color: item.color ?? null,
        });
        total += listing.priceKes * item.quantity;
      }

      const created = await tx.order.create({
        data: {
          storeId,
          buyerName: input.buyerName,
          buyerPhone: input.buyerPhone,
          buyerLocation: input.buyerLocation ?? null,
          fulfillment: input.fulfillment,
          paymentMethod: input.paymentMethod,
          note: input.note ?? null,
          source: "web",
          buyerToken: token,
          totalKes: total,
          items: { create: itemsPayload },
        },
        select: { id: true },
      });

      // Platform-recorded sale -> immutable usage ledger entry (bill-on-record).
      await tx.billingUsageEvent.create({
        data: {
          storeId,
          orderId: created.id,
          type: "order_recorded",
          amountKes: total,
        },
      });

      return created;
    });

    return { token, id: order.id };
  },

  /** Buyer tracking page, addressed by the unguessable token. */
  async byToken(token: string): Promise<Record<string, unknown> | null> {
    const order = await prisma.order.findUnique({
      where: { buyerToken: token },
      select: {
        buyerToken: true,
        status: true,
        buyerName: true,
        buyerPhone: true,
        buyerLocation: true,
        fulfillment: true,
        paymentMethod: true,
        note: true,
        totalKes: true,
        createdAt: true,
        store: { select: { slug: true, name: true, whatsappNumber: true } },
        items: {
          select: {
            title: true,
            priceKes: true,
            compareAtKes: true,
            condition: true,
            quantity: true,
            size: true,
            color: true,
          },
          orderBy: { id: "asc" },
        },
      },
    });
    if (!order) return null;
    return {
      ...order,
      createdAt: order.createdAt.toISOString(),
    };
  },

  /* ------------------------------ seller side ----------------------------- */

  async listForStore(storeId: string, status?: string): Promise<Array<Record<string, unknown>>> {
    const filtered: OrderStatus[] | undefined =
      status && (["pending", "confirmed", "out", "fulfilled", "cancelled"] as const).includes(status as OrderStatus)
        ? [status as OrderStatus]
        : undefined;
    const rows = await prisma.order.findMany({
      where: {
        storeId,
        ...(filtered !== undefined ? { status: { in: filtered } } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true,
        buyerName: true,
        buyerPhone: true,
        buyerLocation: true,
        fulfillment: true,
        paymentMethod: true,
        status: true,
        source: true,
        note: true,
        totalKes: true,
        createdAt: true,
        items: {
          select: { id: true, title: true, priceKes: true, quantity: true, size: true, color: true, condition: true },
        },
      },
    });
    return rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
  },

  async transition(storeId: string, orderId: string, status: string): Promise<void> {
    const allowed = ["confirmed", "out", "fulfilled", "cancelled"] as const;
    if (!allowed.includes(status as (typeof allowed)[number])) {
      throw new ApiError(422, "VALIDATION", "Unknown order status.");
    }
    const order = await prisma.order.findFirst({
      where: { id: orderId, storeId },
      select: { id: true, status: true },
    });
    if (!order) throw new ApiError(404, "ORDER_NOT_FOUND", "Order not found.");

    // Restock exactly when an active order gets cancelled.
    if (status === "cancelled" && ["pending", "confirmed", "out"].includes(order.status)) {
      await prisma.$transaction(async (tx) => {
        const items = await tx.orderItem.findMany({
          where: { orderId },
          select: { listingId: true, quantity: true },
        });
        for (const item of items) {
          if (item.listingId === null) continue;
          await tx.listing.update({
            where: { id: item.listingId },
            data: { stock: { increment: item.quantity } },
          });
        }
        await tx.order.update({ where: { id: orderId }, data: { status: "cancelled" as const } });
      });
      return;
    }

    await prisma.order.update({ where: { id: orderId }, data: { status: status as "confirmed" } });
  },

  /**
   * Sale Recorder: self-report a WhatsApp-settled sale. It doubles as the
   * seller's CRM book and feeds the (immutable) usage ledger honestly.
   */
  async selfReport(storeId: string, input: SelfReportInput): Promise<{ id: string }> {
    // amountKes is the unit price; the recorded sale value is unit x quantity.
    const totalKes = input.amountKes * Math.max(1, input.quantity);
    const order = await prisma.order.create({
      data: {
        storeId,
        source: "self_report",
        status: "fulfilled",
        buyerName: input.buyerName ?? "Booked sale",
        buyerPhone: input.buyerPhone ?? "",
        fulfillment: "delivery",
        paymentMethod: "mpesa",
        totalKes,
        note: input.note ?? null,
        buyerToken: newToken(),
        items: input.listingId
          ? {
              create: [
                {
                  listingId: input.listingId,
                  title: "Listed item",
                  priceKes: input.amountKes,
                  condition: "new",
                  quantity: input.quantity,
                },
              ],
            }
          : {
              create: [
                {
                  title: input.title,
                  priceKes: input.amountKes,
                  condition: "new",
                  quantity: input.quantity,
                },
              ],
            },
      },
      select: { id: true },
    });

    if (input.listingId) {
      const listing = await prisma.listing.findFirst({
        where: { id: input.listingId, storeId },
        select: { title: true },
      });
      if (listing) {
        await prisma.orderItem.updateMany({
          where: { orderId: order.id },
          data: { title: listing.title },
        });
        await prisma.listing.update({
          where: { id: input.listingId },
          data: { stock: { decrement: input.quantity } },
        });
      }
    }

    await prisma.billingUsageEvent.create({
      data: { storeId, orderId: order.id, type: "sale_recorded", amountKes: totalKes },
    });

    return { id: order.id };
  },

  async usageSummary(storeId: string): Promise<{ units: number; recordedKes: number }> {
    const events = await prisma.billingUsageEvent.aggregate({
      where: { storeId, type: { in: ["order_recorded", "sale_recorded"] } },
      _count: true,
      _sum: { amountKes: true },
    });
    return {
      units: events._count,
      recordedKes: events._sum.amountKes ?? 0,
    };
  },

  /* -------------------------------- holds -------------------------------- */

  /** Pro-tier 15-minute reservations; expiry releases stock implicitly. */
  async hold(storeId: string, input: { listingId: string; quantity: number; size?: string; color?: string }): Promise<{ token: string; expiresAt: string }> {
    const tier = await prisma.store
      .findUnique({ where: { id: storeId }, select: { plan: true } })
      .then((s) => (s?.plan ?? "grow") as keyof typeof plans);
    if (plans[tier]?.holdTimers !== true) {
      throw new ApiError(402, "PLAN_REQUIRED", "Holds are available on the Commerce plan and above.");
    }
    const listing = await prisma.listing.findFirst({
      where: { id: input.listingId, storeId, status: "active" },
      select: { id: true, stock: true, title: true },
    });
    if (!listing) throw new ApiError(404, "LISTING_NOT_FOUND", "Item not available.");

    const held = await activeHoldQuantity(listing.id);
    const available = Math.max(listing.stock - held, 0);
    if (input.quantity > available) {
      throw new ApiError(409, "INSUFFICIENT_STOCK", `Only ${available} of ${listing.title} left.`);
    }
    const token = newToken();
    await prisma.hold.create({
      data: {
        listingId: listing.id,
        quantity: input.quantity,
        size: input.size ?? null,
        color: input.color ?? null,
        buyerToken: token,
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      },
    });
    return { token, expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString() };
  },

  /** Public item detail for checkout readiness (stock + variant options). */
  async listingForCheckout(storeId: string, listingId: string) {
    // Accept the share code or the raw id (the SPA only has codes publicly).
    return prisma.listing.findFirst({
      where: { OR: [{ id: listingId }, { code: listingId }], storeId, status: "active" },
      select: {
        id: true, code: true, title: true, stock: true, sizes: true, colors: true,
        priceKes: true, compareAtKes: true, condition: true,
      },
    });
  },
};
