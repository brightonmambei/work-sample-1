/**
 * Canonical listing codes: unambiguous base32 (Crockford), 10 chars, checked
 * against the DB. The code never changes for the life of the item; it is the
 * share-link identity (AGENTS.md section 8).
 */
import crypto from "node:crypto";
import { prisma } from "../../lib/prisma.js";

const ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // no I, L, O, U
const CODE_LEN = 10;

function randomCode(): string {
  const bytes = crypto.randomBytes(CODE_LEN);
  let out = "";
  for (let i = 0; i < CODE_LEN; i += 1) {
    const byte = bytes[i] ?? 0;
    out += ALPHABET[byte % ALPHABET.length];
  }
  return out.toLowerCase();
}

export async function newListingCode(): Promise<string> {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = randomCode();
    const taken = await prisma.listing.findUnique({
      where: { code },
      select: { id: true },
    });
    if (!taken) return code;
  }
  throw new Error("code generation exhausted retries");
}

/**
 * Collection codes share the public namespace with listing codes and live
 * share links, so uniqueness has to hold across all three tables: a drop code
 * must never collide with an item code that has not been shared yet.
 */
export async function newCollectionCode(): Promise<string> {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = randomCode();
    const [listing, collection, link] = await Promise.all([
      prisma.listing.findUnique({ where: { code }, select: { id: true } }),
      prisma.collection.findUnique({ where: { code }, select: { id: true } }),
      prisma.shareLink.findUnique({ where: { code }, select: { id: true } }),
    ]);
    if (!listing && !collection && !link) return code;
  }
  throw new Error("code generation exhausted retries");
}

/** Reserved-looking patterns stay out of the public namespace. */
const BLOCKED_CODE_PREFIXES = ["admin", "api", "www", "test", "demo", "null", "void"];

export function isCodeSafe(code: string): boolean {
  return !BLOCKED_CODE_PREFIXES.some((p) => code.startsWith(p));
}
