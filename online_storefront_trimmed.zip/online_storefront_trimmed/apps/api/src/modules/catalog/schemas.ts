import { z } from "zod";
import { productConditionSchema, productStatusSchema } from "./public.js";

/* ---------------- seller-facing contracts ---------------- */

export const productMediaInputSchema = z.object({
  uploadId: z.string().min(6),
  sortOrder: z.number().int().min(0).max(99).default(0),
  isHero: z.boolean().default(false),
});
export type ProductMediaInput = z.infer<typeof productMediaInputSchema>;

export const productVariantInputSchema = z.object({
  sizes: z.array(z.string().trim().min(1).max(24)).max(24).default([]),
  colors: z.array(z.string().trim().min(1).max(24)).max(24).default([]),
});
export type ProductVariantInput = z.infer<typeof productVariantInputSchema>;

/** The seller's minimum path: photos + price + condition. Everything else defaults. */
export const createProductSchema = z.object({
  title: z.string().trim().min(2, "Give the item a short title.").max(140),
  priceKes: z.number().int().min(1).max(10_000_000),
  compareAtKes: z.number().int().min(1).max(10_000_000).nullable().default(null),
  categoryId: z.string().min(1),
  condition: productConditionSchema,
  conditionGrade: z.number().int().min(1).max(5).nullable().default(null),
  stock: z.number().int().min(0).max(10_000).default(1),
  description: z.string().trim().max(2000).nullable().default(null),
  sizes: z.array(z.string().trim().min(1).max(24)).max(24).default([]),
  colors: z.array(z.string().trim().min(1).max(24)).max(24).default([]),
  status: productStatusSchema.default("draft"),
  publishNow: z.boolean().default(false),
  media: z.array(productMediaInputSchema).max(12).default([]),
});
export type CreateProductInput = z.infer<typeof createProductSchema>;

export const updateProductSchema = createProductSchema
  .partial()
  .extend({ archive: z.boolean().optional() });
export type UpdateProductInput = z.infer<typeof updateProductSchema>;

export const presignSchema = z.object({
  mime: z.enum(["image/jpeg", "image/png", "image/webp", "image/avif", "image/heic"]),
  sizeBytes: z.number().int().min(1).max(12 * 1024 * 1024), // 12 MB
});
export type PresignInput = z.infer<typeof presignSchema>;

export const confirmUploadSchema = z.object({
  key: z.string().min(4).max(400),
  mime: z.string().min(3).max(60),
  sizeBytes: z.number().int().min(1),
  productId: z.string().optional(),
});
export type ConfirmUploadInput = z.infer<typeof confirmUploadSchema>;
