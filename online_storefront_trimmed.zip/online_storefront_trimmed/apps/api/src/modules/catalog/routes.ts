import express from "express";
import {
  createProductSchema,
  updateProductSchema,
} from "./schemas.js";
import { catalogService } from "./service.js";
import { requireRole } from "../../middleware/auth.js";
import { requireStoreOwnership } from "../../middleware/store.js";
import { validateBody } from "../../middleware/validate.js";
import { ok } from "../../middleware/error.js";
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";

/** Seller catalog management. */
export const sellerCatalogRouter = express.Router();
sellerCatalogRouter.use(requireRole("seller", "platform_owner"), requireStoreOwnership);

sellerCatalogRouter.post(
  "/products",
  validateBody(createProductSchema),
  async (req, res, next) => {
    try {
      const created = await catalogService.create(req.storeOwnership!.storeId, req.body);
      ok(res, { listing: created }, 201);
    } catch (err) {
      next(err);
    }
  },
);

sellerCatalogRouter.get("/products", async (req, res, next) => {
  try {
    const page = Math.max(1, Number(req.query.page ?? 1) || 1);
    const pageSize = Math.min(48, Math.max(1, Number(req.query.pageSize ?? 24) || 24));
    const status = typeof req.query.status === "string" ? req.query.status : undefined;
    const result = await catalogService.listForStore(req.storeOwnership!.storeId, {
      page,
      pageSize,
      status,
    });
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

sellerCatalogRouter.patch("/products/:id", validateBody(updateProductSchema), async (req, res, next) => {
  try {
    await catalogService.update(req.storeOwnership!.storeId, String(req.params.id ?? ""), req.body);
    ok(res, { updated: true });
  } catch (err) {
    next(err);
  }
});

sellerCatalogRouter.get("/products/:id", async (req, res, next) => {
  try {
    const listing = await prisma.listing.findFirst({
      where: { id: String(req.params.id ?? ""), storeId: req.storeOwnership!.storeId },
      include: { media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" }] } },
    });
    if (!listing) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    ok(res, {
      listing: {
        id: listing.id,
        code: listing.code,
        title: listing.title,
        priceKes: listing.priceKes,
        compareAtKes: listing.compareAtKes,
        stock: listing.stock,
        status: listing.status,
      },
    });
  } catch (err) {
    next(err);
  }
});

/* ------------------------------ public ------------------------------ */

/**
 * Buyer-facing catalog. The store context comes from host resolution
 * (subdomain / custom domain / dev escape hatch) and lands in res.locals.
 */
export const publicCatalogRouter = express.Router();

function requireStoreContext(res: express.Response): string {
  const storeId = res.locals?.storeId as string | undefined;
  if (!storeId) {
    throw new ApiError(404, "STORE_NOT_FOUND", "Store not found for this address.");
  }
  return storeId;
}

publicCatalogRouter.get("/products", async (req, res, next) => {
  try {
    const storeId = requireStoreContext(res);
    const page = Math.max(1, Number(req.query.page ?? 1) || 1);
    const pageSize = Math.min(48, Math.max(1, Number(req.query.pageSize ?? 24) || 24));
    const result = await catalogService.listPublic(storeId, {
      category: typeof req.query.category === "string" ? req.query.category : undefined,
      condition: typeof req.query.condition === "string" ? req.query.condition : undefined,
      q: typeof req.query.q === "string" ? req.query.q : undefined,
      sort: typeof req.query.sort === "string" ? req.query.sort : "new",
      page,
      pageSize,
    });
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

publicCatalogRouter.get("/products/:code", async (req, res, next) => {
  try {
    const storeId = requireStoreContext(res);
    const listingId = await catalogService.idByCode(req.params.code ?? "");
    if (listingId === null) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    const listing = await catalogService.getPublic(storeId, listingId);
    if (listing === null) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");
    }
    ok(res, { listing });
  } catch (err) {
    next(err);
  }
});
