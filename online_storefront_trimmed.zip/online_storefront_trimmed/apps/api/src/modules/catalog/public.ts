import { z } from "zod";

/* ---------------- shared value enums ---------------- */

export const productConditionSchema = z.enum(["new", "thrift"]);
export type ProductCondition = z.infer<typeof productConditionSchema>;

export const productStatusSchema = z.enum(["draft", "active", "paused", "sold_out", "archived"]);
export type ProductStatus = z.infer<typeof productStatusSchema>;

/* ---------------- public (buyer) contracts ---------------- */

export const publicListingSchema = z.object({
  code: z.string(),
  title: z.string(),
  priceKes: z.number(),
  compareAtKes: z.number().nullable(),
  condition: productConditionSchema,
  conditionGrade: z.number().int().nullable(),
  stock: z.number(),
  badgeText: z.string().nullable(),
  categorySlug: z.string(),
  storeSlug: z.string(),
  coverUrl: z.string().nullable(),
  images: z.array(
    z.object({
      id: z.string(),
      thumbUrl: z.string().nullable(),
      cardUrl: z.string().nullable(),
      fullUrl: z.string().nullable(),
      width: z.number().int().nullable(),
      height: z.number().int().nullable(),
      sortOrder: z.number().int(),
    }),
  ),
  sizes: z.array(z.string()),
  colors: z.array(z.string()),
  description: z.string().nullable(),
});
export type PublicListing = z.infer<typeof publicListingSchema>;

export const categorySchema = z.object({
  id: z.string(),
  slug: z.string(),
  label: z.string(),
  itemCount: z.number().int(),
});
export type PublicCategory = z.infer<typeof categorySchema>;

export const listingQuerySchema = z.object({
  category: z.string().optional(),
  condition: z.enum(["new", "thrift"]).optional(),
  q: z.string().max(80).optional(),
  sort: z.enum(["new", "price_asc", "price_desc"]).default("new"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(24),
});
export type ListingQuery = z.infer<typeof listingQuerySchema>;

export const shareCodeSchema = z
  .string()
  .regex(/^[1-9A-HJ-NP-Za-km-z]{8,14}$/, "malformed code");