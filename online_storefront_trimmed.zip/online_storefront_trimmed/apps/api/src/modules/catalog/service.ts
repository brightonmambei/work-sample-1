/**
 * Catalog service: listing CRUD within a store, free-tier quota enforcement,
 * and buyer-facing queries. All stock-touching writes are transactional
 * (AGENTS.md invariant 2); prices are integers in KSh.
 */
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { Prisma, ListingStatus, ListingCondition } from "@prisma/client";
import { plans } from "@storesnap/shared";
import type { CreateProductInput, UpdateProductInput } from "./schemas.js";
import { newListingCode } from "./codes.js";
import { variantKey } from "../media/storage.js";
import { storage } from "../media/storage.js";

const listingInclude: Prisma.ListingInclude = {
  media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" }] },
};

type MediaRow = {
  id: string;
  thumbKey: string | null;
  cardKey: string | null;
  fullKey: string | null;
  width: number | null;
  height: number | null;
  isHero: boolean;
  sortOrder: number;
};

function mediaUrl(key: string | null): string | null {
  return key !== null && key !== "" ? storage.urlFor(key) : null;
}

/**
 * Variant keys for an upload whose renditions are already done. Keys are
 * deterministic (variantKey of the original key), so a listing media row
 * created after the worker finishes still lands complete; pending uploads
 * contribute nothing and get their keys from attachVariants later.
 */
async function readyVariantKeys(
  uploadId: string,
): Promise<{ thumbKey?: string; cardKey?: string; fullKey?: string }> {
  const upload = await prisma.upload.findUnique({
    where: { id: uploadId },
    select: { status: true, key: true },
  });
  if (!upload || upload.status !== "ready") return {};
  return {
    thumbKey: variantKey(upload.key, "thumb"),
    cardKey: variantKey(upload.key, "card"),
    fullKey: variantKey(upload.key, "full"),
  };
}

export function toPublicMedia(media: MediaRow) {
  return {
    id: media.id,
    thumbUrl: mediaUrl(media.thumbKey),
    cardUrl: mediaUrl(media.cardKey),
    fullUrl: mediaUrl(media.fullKey),
    originalUrl: mediaUrl(media.fullKey ?? media.cardKey ?? media.thumbKey),
    width: media.width,
    height: media.height,
    isHero: media.isHero,
    sortOrder: media.sortOrder,
  };
}

export const catalogService = {
  /* ---------------------------- seller side ---------------------------- */

  async assertQuota(storeId: string): Promise<void> {
    const store = await prisma.store.findUnique({
      where: { id: storeId },
      select: { plan: true },
    });
    const plan = plans[(store?.plan ?? "grow") as keyof typeof plans] ?? plans.grow;
    if (plan.activeListings === null) return;

    const active = await prisma.listing.count({
      where: { storeId, status: { in: ["active", "paused", "sold_out"] } },
    });
    if (active >= plan.activeListings) {
      throw new ApiError(
        402,
        "QUOTA_REACHED",
        `Your ${plan.label} plan allows ${plan.activeListings} live items. Archive something or upgrade (Phase 4 billing).`,
      );
    }
  },

  async create(
    storeId: string,
    input: CreateProductInput,
  ): Promise<{ id: string; code: string }> {
    await this.assertQuota(storeId);

    const category = await prisma.category.findUnique({
      where: { id: input.categoryId },
      select: { id: true },
    });
    if (!category) {
      throw new ApiError(422, "VALIDATION", "Pick a valid category.");
    }

    const duplicateMedia = new Set(input.media.map((m) => m.uploadId));
    if (duplicateMedia.size !== input.media.length) {
      throw new ApiError(422, "VALIDATION", "Each photo can only be attached once.");
    }
    for (const m of input.media) {
      await this.assertMedia(storeId, m.uploadId);
    }

    const status = input.publishNow ? "active" : input.status;

    const code = await newListingCode();
    const heroUploadId =
      input.media.find((m) => m.isHero)?.uploadId ?? input.media[0]?.uploadId ?? null;
    const heroKey = heroUploadId
      ? (
          await prisma.upload.findUnique({
            where: { id: heroUploadId },
            select: { key: true },
          })
        )?.key ?? null
      : null;

    // Variant keys are derived from the object key, so an upload whose
    // variants already finished (confirm fired before the listing row
    // existed) self-heals at attach time; fresh uploads stay null until the
    // worker's attachVariants writes them back.

    const listing = await prisma.listing.create({
      data: {
        storeId,
        categoryId: input.categoryId,
        code,
        title: input.title,
        description: input.description ?? null,
        priceKes: input.priceKes,
        compareAtKes: input.compareAtKes ?? null,
        condition: input.condition,
        conditionGrade: input.conditionGrade ?? null,
        stock: input.stock,
        status,
        sizes: input.sizes,
        colors: input.colors,
        coverKey: heroKey,
        shareLinks: {
          // The canonical /p/:code link exists the moment the item does.
          create: { code: code.toLowerCase() },
        },
        media: {
          create: await Promise.all(
            input.media.map(async (m, idx) => ({
              uploadId: m.uploadId,
              ...(await readyVariantKeys(m.uploadId)),
              isHero: Boolean(m.isHero || (idx === 0 && !input.media.some((x) => x.isHero))),
              sortOrder: idx,
            })),
          ),
        },
      },
      select: { id: true, code: true },
    });

    return listing;
  },

  async assertMedia(storeId: string, uploadId: string): Promise<void> {
    const upload = await prisma.upload.findUnique({
      where: { id: uploadId },
      select: { storeId: true, status: true },
    });
    if (!upload || upload.storeId !== storeId || upload.status !== "ready") {
      throw new ApiError(400, "MEDIA_NOT_READY", "Finish or re-start that image upload.");
    }
  },

  async update(
    storeId: string,
    listingId: string,
    patch: UpdateProductInput,
  ): Promise<void> {
    const listing = await prisma.listing.findFirst({
      where: { id: listingId, storeId },
      select: { id: true, status: true },
    });
    if (!listing) throw new ApiError(404, "LISTING_NOT_FOUND", "Item not found.");

    if (patch.media) {
      for (const m of patch.media) {
        await this.assertMedia(storeId, m.uploadId);
      }
    }

    const status = patch.archive === true ? "archived" : patch.publishNow === true ? "active" : undefined;

    await prisma.$transaction(async (tx) => {
      if (patch.media) {
        await tx.listingMedia.deleteMany({ where: { listingId } });
        if (patch.media.length > 0) {
          await tx.listingMedia.createMany({
            data: await Promise.all(
              patch.media.map(async (m, idx) => ({
                listingId,
                uploadId: m.uploadId,
                ...(await readyVariantKeys(m.uploadId)),
                isHero: Boolean(m.isHero || (idx === 0 && !patch.media!.some((x) => x.isHero))),
                sortOrder: idx,
              })),
            ),
          });
        }
      }

      await tx.listing.update({
        where: { id: listingId },
        data: {
          ...(patch.title !== undefined ? { title: patch.title } : {}),
          ...(patch.description !== undefined ? { description: patch.description } : {}),
          ...(patch.priceKes !== undefined ? { priceKes: patch.priceKes } : {}),
          ...(patch.compareAtKes !== undefined ? { compareAtKes: patch.compareAtKes } : {}),
          ...(patch.condition !== undefined ? { condition: patch.condition } : {}),
          ...(patch.conditionGrade !== undefined ? { conditionGrade: patch.conditionGrade } : {}),
          ...(patch.stock !== undefined ? { stock: patch.stock } : {}),
          ...(patch.categoryId !== undefined ? { categoryId: patch.categoryId } : {}),
          ...(patch.sizes !== undefined ? { sizes: patch.sizes } : {}),
          ...(patch.colors !== undefined ? { colors: patch.colors } : {}),
          ...(status !== undefined ? { status } : {}),
        },
      });

      if (patch.media !== undefined) {
        // Recompute the cover object key from the hero's upload key.
        const fresh = await tx.listing.findUnique({
          where: { id: listingId },
          select: {
            media: {
              orderBy: [{ isHero: "desc" as const }, { sortOrder: "asc" as const }],
              take: 1,
              select: { upload: { select: { key: true } } },
            },
          },
        });
        await tx.listing.update({
          where: { id: listingId },
          data: { coverKey: fresh?.media[0]?.upload?.key ?? null },
        });
      }
    });
  },

  async listForStore(
    storeId: string,
    opts: { status?: string; page: number; pageSize: number },
  ): Promise<{ items: Array<Record<string, unknown>>; total: number }> {
    const where: Prisma.ListingWhereInput = {
      storeId,
      ...(opts.status && ListingStatus[opts.status as keyof typeof ListingStatus]
        ? { status: opts.status as ListingStatus }
        : {}),
    };
    const [rows, total] = await Promise.all([
      prisma.listing.findMany({
        where,
        orderBy: { createdAt: "desc" },
        include: listingInclude,
        skip: (opts.page - 1) * opts.pageSize,
        take: opts.pageSize,
      }),
      prisma.listing.count({ where }),
    ]);

    return {
      items: rows.map((r) => ({
        id: r.id,
        code: r.code,
        title: r.title,
        priceKes: r.priceKes,
        compareAtKes: r.compareAtKes,
        condition: r.condition,
        conditionGrade: r.conditionGrade,
        stock: r.stock,
        status: r.status,
        badgeText: r.badgeText,
        sizes: r.sizes,
        colors: r.colors,
        description: r.description,
        createdAt: r.createdAt,
        media: r.media.map(toPublicMedia),
      })),
      total,
    };
  },

  /* ---------------------------- buyer side ---------------------------- */

  async listPublic(
    storeId: string,
    query: { category?: string; condition?: string; q?: string; sort: string; page: number; pageSize: number },
  ): Promise<{ items: Array<Record<string, unknown>>; total: number }> {
    const categoryId = query.category
      ? (await prisma.category.findUnique({ where: { slug: query.category }, select: { id: true } }))?.id
      : undefined;
    if (query.category && !categoryId) {
      return { items: [], total: 0 };
    }

    const where: Prisma.ListingWhereInput = {
      storeId,
      status: "active",
      ...(categoryId !== undefined ? { categoryId } : {}),
      ...(query.condition === "new" || query.condition === "thrift"
        ? { condition: query.condition satisfies ListingCondition }
        : {}),
      ...(query.q
        ? {
            OR: [
              { title: { contains: query.q, mode: "insensitive" as const } },
              { description: { contains: query.q, mode: "insensitive" as const } },
            ],
          }
        : {}),
    };

    const orderBy =
      query.sort === "price_asc"
        ? { priceKes: "asc" as const }
        : query.sort === "price_desc"
          ? { priceKes: "desc" as const }
          : { createdAt: "desc" as const };

    const [rows, total] = await Promise.all([
      prisma.listing.findMany({
        where,
        orderBy,
        include: listingInclude,
        skip: (query.page - 1) * query.pageSize,
        take: query.pageSize,
      }),
      prisma.listing.count({ where }),
    ]);

    return {
      items: rows.map(toPublicCard),
      total,
    };
  },

  async getPublic(storeId: string, listingId: string): Promise<Record<string, unknown> | null> {
    const row = await prisma.listing.findFirst({
      where: { id: listingId, storeId },
      include: { ...listingInclude, category: { select: { slug: true } } },
    });
    if (!row || row.status === "archived" || row.status === "draft") return null;
    return toPublicDetail(row);
  },

  /* ---------------------------- worker hooks ---------------------------- */

  /**
   * Called by the media worker after variant generation; writes denormalised
   * media URLs onto the listing media rows (keys only; URL building at read).
   */
  async attachVariants(
    uploadId: string,
    keys: { thumbKey?: string; cardKey?: string; fullKey?: string; width?: number; height?: number },
  ): Promise<void> {
    await prisma.listingMedia.updateMany({
      where: { uploadId },
      data: {
        thumbKey: keys.thumbKey ?? null,
        cardKey: keys.cardKey ?? null,
        fullKey: keys.fullKey ?? null,
        width: keys.width ?? null,
        height: keys.height ?? null,
      },
    });
    // Cover keys are the hero's card variant, resolved lazily at read time.
  },

  /** Fetch by canonical code for share-link routing. */
  async idByCode(code: string): Promise<string | null> {
    const row = await prisma.listing.findUnique({ where: { code }, select: { id: true } });
    return row?.id ?? null;
  },

  /**
   * Resolve a share code or listing code from ANY host into the item a
   * buyer should land on: the human redirect for /p/:shortId points at the
   * SPA item route and needs the item plus its store (AGENTS.md section 8).
   */
  async resolvePublicByCode(
    rawCode: string,
  ): Promise<{
    state: "live" | "sold" | "gone";
    store: ShareStoreInfo | null;
    listing: Record<string, unknown> | null;
  }> {
    const code = rawCode.toLowerCase();
    const link = await prisma.shareLink.findUnique({
      where: { code },
      select: { id: true, listingId: true },
    });

    const row = (await prisma.listing.findUnique({
      // Share links now point at an item OR a collection; a drop code simply
      // resolves no listing here and reports "gone" for the item page.
      where: link?.listingId ? { id: link.listingId } : { code },
      include: shareInclude,
    })) as ShareListingRow | null;

    if (!row || row.store.status !== "active") {
      return { state: "gone", store: null, listing: null };
    }

    const store: ShareStoreInfo = {
      slug: row.store.slug,
      name: row.store.name,
      tagline: row.store.tagline,
      whatsappNumber: row.store.whatsappNumber,
    };

    if (row.status === "archived" || (row.status === "sold_out" && row.stock <= 0)) {
      // Sold items keep their public detail: the sold page shows their face.
      return { state: "sold", store, listing: toPublicDetail(row) };
    }
    if (row.status !== "active") {
      return { state: "gone", store, listing: null };
    }
    return { state: "live", store, listing: toPublicDetail(row) };
  },
};

/* ---------------------------- shape mapping ---------------------------- */

/** Store facts the public item page needs (buyer-facing only). */
export interface ShareStoreInfo {
  slug: string;
  name: string;
  tagline: string | null;
  whatsappNumber: string | null;
}

/** Listing include for share-code resolution: media + buyer-facing store. */
const shareInclude = {
  media: { orderBy: [{ isHero: "desc" }, { sortOrder: "asc" as const }] },
  store: {
    select: {
      slug: true,
      name: true,
      tagline: true,
      whatsappNumber: true,
      status: true,
    },
  },
} as const satisfies Prisma.ListingInclude;
type ShareListingRow = Prisma.ListingGetPayload<{ include: typeof shareInclude }>;

type ListingRow = {
  id: string;
  code: string;
  title: string;
  description: string | null;
  priceKes: number;
  compareAtKes: number | null;
  condition: "new" | "thrift";
  conditionGrade: number | null;
  stock: number;
  status: string;
  badgeText: string | null;
  sizes: string[];
  colors: string[];
  createdAt: Date;
  category?: { slug: string } | null;
  media: MediaRow[];
};

function publicShape(row: ListingRow) {
  return {
    code: row.code,
    title: row.title,
    description: row.description,
    priceKes: row.priceKes,
    compareAtKes: row.compareAtKes,
    condition: row.condition,
    conditionGrade: row.conditionGrade,
    stock: row.stock,
    badgeText: row.badgeText,
    sizes: row.sizes,
    colors: row.colors,
    media: row.media.map(toPublicMedia),
    createdAt: row.createdAt.toISOString(),
  };
}

function toPublicCard(row: ListingRow): Record<string, unknown> {
  const { category, ...rest } = row as ListingRow & { category?: { slug: string } | null };
  return { ...publicShape(rest), categorySlug: category?.slug ?? null };
}

function toPublicDetail(row: ListingRow): Record<string, unknown> {
  const { category, ...rest } = row as ListingRow & { category?: { slug: string } | null };
  return {
    ...publicShape(rest),
    categorySlug: category?.slug ?? null,
  };
}
