/**
 * Catalog module taxonomy: seeded by taxonomyService.seedDefaults() on boot
 * (idempotent); the admin console owns edits from Phase 4 onward.
 * Endpoints serve categories from the DB, never from code (blueprint section 5).
 */

import { prisma } from "../../lib/prisma.js";

export interface SeedCategory {
  slug: string;
  label: string;
  sortOrder: number;
}

export const DEFAULT_CATEGORIES: SeedCategory[] = [
  { slug: "thrift-clothes", label: "Thrift Clothes", sortOrder: 10 },
  { slug: "clothes", label: "Clothes", sortOrder: 20 },
  { slug: "sneakers", label: "Shoes and Sneakers", sortOrder: 30 },
  { slug: "wigs", label: "Wigs and Hair", sortOrder: 40 },
  { slug: "perfumes", label: "Perfumes and Beauty", sortOrder: 50 },
  { slug: "bags", label: "Bags", sortOrder: 60 },
  { slug: "accessories", label: "Accessories", sortOrder: 70 },
  { slug: "electronics", label: "Electronics", sortOrder: 80 },
  { slug: "general", label: "General", sortOrder: 90 },
];

export const taxonomyService = {
  /** Idempotent seeding so the whole taxonomy is DB-owned from the start. */
  async seedDefaults(): Promise<void> {
    for (const cat of DEFAULT_CATEGORIES) {
      await prisma.category.upsert({
        where: { slug: cat.slug },
        create: cat,
        update: { label: cat.label, sortOrder: cat.sortOrder },
      });
    }
  },

  async listActive(): Promise<
    Array<{ id: string; slug: string; label: string; sortOrder: number }>
  > {
    return prisma.category.findMany({
      orderBy: { sortOrder: "asc" },
      select: { id: true, slug: true, label: true, sortOrder: true },
    });
  },

  async slugToId(slug: string): Promise<string | null> {
    const category = await prisma.category.findUnique({
      where: { slug },
      select: { id: true },
    });
    return category?.id ?? null;
  },

  async labelFor(id: string): Promise<string | null> {
    const category = await prisma.category.findUnique({
      where: { id },
      select: { label: true },
    });
    return category?.label ?? null;
  },
};
