import express from "express";
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { ok } from "../../middleware/error.js";
import { requireRole } from "../../middleware/auth.js";
import { billingService } from "../billing/service.js";
import { plans, type PlanTier } from "@storesnap/shared";
import type { Prisma } from "@prisma/client";

/**
 * Minimal admin console API (Phase 4). Every mutating action writes to the
 * immutable audit_log (invariant 9). Impersonation and moderation land in the
 * full Phase 7 console.
 */

export const adminRouter = express.Router();

export function audit(
  req: { auth?: { userId: string } | null },
  action: string,
  targetType: string,
  targetId: string,
  detail: Record<string, unknown> = {},
): void {
  void (async () => {
    let email = "";
    if (req.auth !== undefined && req.auth !== null) {
      const user = await prisma.user.findUnique({
        where: { id: req.auth.userId },
        select: { email: true },
      });
      email = user?.email ?? "";
    }
    await prisma.auditLog.create({
      data: {
        actorId: req.auth?.userId ?? "unknown",
        actorEmail: email,
        action,
        targetType,
        targetId,
        detail: detail as Prisma.InputJsonValue,
      },
    });
  })().catch((err) => console.error("audit log failed", err));
}

adminRouter.use(requireRole("platform_owner"));

/* ------------------------------- overview -------------------------------- */

adminRouter.get("/overview", async (_req, res, next) => {
  try {
    const [stores, users, subs, invoices, boosts, sales] = await Promise.all([
      prisma.store.findMany({ select: { plan: true, status: true } }),
      prisma.user.findMany({ select: { id: true }, where: { role: "seller" } }),
      prisma.billingSubscription.findMany({ where: { status: "active" }, select: { plan: true, priceKes: true, period: true } }),
      prisma.usageInvoice.findMany({ select: { status: true, totalKes: true } }),
      prisma.boostPurchase.findMany({ where: { status: "paid" }, select: { amountKes: true } }),
      prisma.billingUsageEvent.aggregate({ _count: true, _sum: { amountKes: true } }),
    ]);

    // Monthly recurring revenue, normalized to a monthly price.
    const mrr = subs.reduce((sum, s) => {
      if (s.plan === "grow") return sum;
      const monthly =
        s.period === "weekly" ? s.priceKes * 4.33 : s.period === "quarterly" ? s.priceKes / 3 : s.priceKes;
      return sum + Math.round(monthly);
    }, 0);

    const boostRevenue = boosts.reduce((n, b) => n + b.amountKes, 0);
    const invoicesPaid = invoices.filter((i) => i.status === "paid").reduce((n, i) => n + i.totalKes, 0);

    const planCounts: Record<string, number> = { grow: 0, commerce: 0, business: 0 };
    for (const s of stores) planCounts[s.plan] = (planCounts[s.plan] ?? 0) + 1;

    ok(res, {
      overview: {
        activeStores: stores.filter((s) => s.status === "active").length,
        suspendedStores: stores.filter((s) => s.status !== "active").length,
        sellers: users.length,
        planCounts,
        mrrKes: mrr,
        boostRevenueKes: boostRevenue,
        invoiceRevenueKes: invoicesPaid,
        overdueInvoices: invoices.filter((i) => i.status === "overdue").length,
        openInvoices: invoices.filter((i) => ["issued", "draft"].includes(i.status)).length,
        recordedSales: { units: sales._count, valueKes: sales._sum.amountKes ?? 0 },
        tierPrices: {
          commerce: plans.commerce.priceKesMonthly,
          business: plans.business.priceKesMonthly,
        },
      },
    });
  } catch (err) {
    next(err);
  }
});

/* --------------------------------- stores -------------------------------- */

adminRouter.get("/stores", async (_req, res, next) => {
  try {
    const stores = await prisma.store.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true, slug: true, name: true, plan: true, status: true,
        createdAt: true, _count: { select: { listings: true, orders: true } },
      },
    });
    ok(res, { stores });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/stores/:id/plan", async (req, res, next) => {
  try {
    const plan = req.body?.plan as PlanTier;
    if (!["grow", "commerce", "business"].includes(plan)) {
      throw new ApiError(422, "VALIDATION", "Unknown plan.");
    }
    const store = await prisma.store.findUnique({ where: { id: String(req.params.id) }, select: { id: true, slug: true } });
    if (store === null) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");
    const sub = await billingService.changePlan(store.id, plan, "monthly");
    audit(req, "store.plan_change", "store", store.id, { plan, slug: store.slug });
    ok(res, { subscription: sub, store: { id: store.id, plan } });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/stores/:id/suspend", async (req, res, next) => {
  try {
    const store = await prisma.store.findUnique({ where: { id: String(req.params.id) } });
    if (store === null) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");
    await prisma.store.update({ where: { id: store.id }, data: { status: "suspended" } });
    audit(req, "store.suspend", "store", store.id, { slug: store.slug });
    ok(res, { suspended: true });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/stores/:id/restore", async (req, res, next) => {
  try {
    const store = await prisma.store.findUnique({ where: { id: String(req.params.id) } });
    if (store === null) throw new ApiError(404, "STORE_NOT_FOUND", "Store not found.");
    await prisma.store.update({ where: { id: store.id }, data: { status: "active" } });
    audit(req, "store.restore", "store", store.id, { slug: store.slug });
    ok(res, { restored: true });
  } catch (err) {
    next(err);
  }
});

/* -------------------------------- billing -------------------------------- */

adminRouter.get("/invoices", async (req, res, next) => {
  try {
    const status = typeof req.query.status === "string" ? req.query.status : undefined;
    const [invoices, stores] = await Promise.all([
      prisma.usageInvoice.findMany({
        where: status !== undefined ? { status: status as "draft" } : undefined,
        orderBy: { createdAt: "desc" },
        take: 100,
        include: { period: true },
      }),
      prisma.store.findMany({
        select: { id: true, slug: true, name: true },
      }),
    ]);
    const storeSlugById = new Map(stores.map((s) => [s.id, s.slug]));
    const storeNameById = new Map(stores.map((s) => [s.id, s.name]));
    // Periods are optional in the relation; flatten for the console table.
    ok(res, {
      invoices: invoices.map((i) => ({
        id: i.id,
        storeSlug: storeSlugById.get(i.storeId) ?? i.storeId,
        storeName: storeNameById.get(i.storeId) ?? "",
        status: i.status,
        totalKes: i.totalKes,
        issuedAt: i.issuedAt,
        paidAt: i.paidAt,
        dueAt: i.dueAt,
        periodUnits: i.period?.units ?? null,
        periodRecordedKes: i.period?.recordedKes ?? null,
      })),
    });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/invoices/:id/release", async (req, res, next) => {
  try {
    const invoice = await prisma.usageInvoice.findUnique({
      where: { id: String(req.params.id) },
      select: { id: true, status: true, storeId: true, totalKes: true, lines: true },
    });
    if (invoice === null) throw new ApiError(404, "INVOICE_NOT_FOUND", "Invoice not found.");
    if (invoice.status !== "draft") {
      throw new ApiError(409, "INVALID_STATE", "Only draft invoices can be released.");
    }
    await prisma.usageInvoice.update({
      where: { id: invoice.id },
      data: { status: "issued", issuedAt: new Date(), dueAt: new Date(Date.now() + 7 * 86400_000) },
    });
    audit(req, "invoice.release", "invoice", invoice.id, { totalKes: invoice.totalKes });
    ok(res, { released: true });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/invoices/:id/void", async (req, res, next) => {
  try {
    const invoice = await prisma.usageInvoice.findUnique({ where: { id: String(req.params.id) } });
    if (invoice === null) throw new ApiError(404, "INVOICE_NOT_FOUND", "Invoice not found.");
    if (invoice.status === "paid") {
      throw new ApiError(409, "INVALID_STATE", "Paid invoices cannot be voided; issue a credit instead.");
    }
    await prisma.usageInvoice.update({ where: { id: invoice.id }, data: { status: "void" } });
    audit(req, "invoice.void", "invoice", invoice.id, { totalKes: invoice.totalKes });
    ok(res, { voided: true });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/invoices/:id/adjust", async (req, res, next) => {
  try {
    const deltaKes = Number(req.body?.deltaKes);
    if (!Number.isFinite(deltaKes) || deltaKes === 0) {
      throw new ApiError(422, "VALIDATION", "Adjustment must be nonzero.");
    }
    const invoice = await prisma.usageInvoice.findUnique({ where: { id: String(req.params.id) } });
    if (invoice === null) throw new ApiError(404, "INVOICE_NOT_FOUND", "Invoice not found.");
    if (invoice.status === "void") throw new ApiError(409, "INVALID_STATE", "Voided invoices cannot be adjusted.");
    // Corrections happen ON the invoice, never on the usage ledger (invariant 7).
    const updated = await prisma.usageInvoice.update({
      where: { id: invoice.id },
      data: { totalKes: Math.max(0, invoice.totalKes + Math.round(deltaKes)) },
    });
    audit(req, "invoice.adjust", "invoice", invoice.id, { deltaKes });
    ok(res, { invoice: { id: updated.id, totalKes: updated.totalKes } });
  } catch (err) {
    next(err);
  }
});

/* ------------------------------- rate card -------------------------------- */

adminRouter.get("/rate-card", async (_req, res, next) => {
  try {
    ok(res, { cards: await prisma.rateCard.findMany({ orderBy: { key: "asc" } }) });
  } catch (err) {
    next(err);
  }
});

adminRouter.put("/rate-card/:key", async (req, res, next) => {
  try {
    const key = String(req.params.key);
    const card = await prisma.rateCard.findUnique({ where: { key } });
    if (card === null) throw new ApiError(404, "RATE_CARD_NOT_FOUND", "Unknown rate card key.");

    const feeBps = Number(req.body?.feeBps);
    const minFeeKes = req.body?.minFeeKes !== undefined ? Number(req.body.minFeeKes) : card.minFeeKes;
    const active = req.body?.active !== undefined ? Boolean(req.body.active) : card.active;
    if (!Number.isInteger(feeBps) || feeBps < 0 || feeBps > 2000) {
      throw new ApiError(422, "VALIDATION", "Fee must be 0 to 2000 basis points (0 to 20%).");
    }

    const updated = await prisma.rateCard.update({
      where: { key },
      data: { feeBps, minFeeKes: Math.max(0, Math.round(minFeeKes)), active },
    });
    audit(req, "rate_card.update", "rate_card", key, { feeBps, minFeeKes, active });
    ok(res, { card: updated });
  } catch (err) {
    next(err);
  }
});

/* --------------------------------- audit ---------------------------------- */

adminRouter.get("/audit", async (_req, res, next) => {
  try {
    const entries = await prisma.auditLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    ok(res, { entries });
  } catch (err) {
    next(err);
  }
});

/* ----------------------- metering operations (jobs) ----------------------- */

/** Nightly aggregation is scheduled via pg-boss; this runs it on demand. */
adminRouter.post("/usage/aggregate", async (req, res, next) => {
  try {
    const periods = await billingService.aggregateUsage();
    audit(req, "usage.aggregate", "system", "metering", { periods });
    ok(res, { periods });
  } catch (err) {
    next(err);
  }
});

adminRouter.post("/billing/enforce-overdue", async (req, res, next) => {
  try {
    const result = await billingService.enforceOverdue();
    audit(req, "billing.enforce_overdue", "system", "dunning", result);
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/* ------------------------------ media storage ----------------------------- */

/**
 * Bucket storage overview: DB ledger aggregates per store plus a live scan
 * of the bucket contents (objects the ledger does not know about, like
 * share posters, show up here too).
 */
adminRouter.get("/storage", async (_req, res, next) => {
  try {
    const { listObjects } = await import("../../lib/objectstore.js");

    const [uploads, stores, objects] = await Promise.all([
      prisma.upload.findMany({
        select: {
          id: true,
          storeId: true,
          key: true,
          sizeBytes: true,
          status: true,
          createdAt: true,
          _count: { select: { listingMedia: true } },
        },
      }),
      prisma.store.findMany({ select: { id: true, slug: true, name: true } }),
      listObjects({ maxKeys: 5000 }),
    ]);

    const perStore = stores.map((s) => ({
      storeId: s.id,
      slug: s.slug,
      name: s.name,
      uploads: 0,
      attachedUploads: 0,
      orphanUploads: 0,
      bytes: 0,
    }));
    const byId = new Map(perStore.map((r) => [r.storeId, r]));
    for (const u of uploads) {
      const row = byId.get(u.storeId);
      if (!row) continue;
      row.uploads += 1;
      row.bytes += u.sizeBytes;
      if (u._count.listingMedia > 0) row.attachedUploads += 1;
      else row.orphanUploads += 1;
    }
    perStore.sort((a, b) => b.bytes - a.bytes);

    const dbLedgerBytes = uploads.reduce((s, u) => s + u.sizeBytes, 0);
    // The variant pipeline deterministically emits thumb/card/full per ready
    // upload; failures show up as a bucket-live/ledger gap, which is the
    // honest signal this console needs.
    const variantEstimate = uploads.filter((u) => u.status === "ready").length * 3;
    const bucketKeyCount = objects.length;
    const bucketBytes = objects.reduce((s, o) => s + o.bytes, 0);

    ok(res, {
      bucket: process.env.S3_BUCKET ?? "storesnap-media",
      ledger: {
        uploads: uploads.length,
        ledgerBytes: dbLedgerBytes,
        estimatedObjects: uploads.length + variantEstimate,
        stalePending: uploads.filter(
          (u) => u.status === "pending" && Date.now() - u.createdAt.getTime() > 7 * 86400_000,
        ).length,
        orphanUploads: uploads.filter((u) => u._count.listingMedia === 0).length,
      },
      bucketLive: {
        objectCount: bucketKeyCount,
        totalBytes: bucketBytes,
        unledgeredObjects: Math.max(0, bucketKeyCount - uploads.length - variantEstimate),
      },
      stores: perStore.filter((r) => r.uploads > 0),
    });
  } catch (err) {
    next(err);
  }
});

/** Global orphan sweep (24h guard protects fresh uploads). Audit-logged. */
adminRouter.post("/storage/gc", async (req, res, next) => {
  try {
    const { mediaService } = await import("../media/service.js");
    const result = await mediaService.garbageCollect();
    audit(req, "media.gc", "store", "bucket", { ...result });
    ok(res, result);
  } catch (err) {
    next(err);
  }
});
