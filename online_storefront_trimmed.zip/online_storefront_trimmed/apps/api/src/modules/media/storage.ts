/**
 * Media storage boundary (AGENTS.md section 4): all object-storage access goes
 * through this module. The API never streams file bytes; browsers upload
 * directly to the bucket with presigned PUTs, and the worker reads originals
 * for processing. Buckets are modular: MinIO in dev, S3/B2 in prod via env.
 */
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { randomBytes } from "node:crypto";
import { config } from "../../config.js";
import { logger } from "../../lib/logger.js";

export const MAX_UPLOAD_BYTES = 12 * 1024 * 1024; // 12 MB
export const ALLOWED_MIME = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/avif",
  "image/heic",
] as const;
export type AllowedMime = (typeof ALLOWED_MIME)[number];

let client: S3Client | null = null;
let presignClient: S3Client | null = null;

const ORIGIN_RE = /^(https?:\/\/[^/]+)/;

/**
 * The presigning client must sign against a host the browser can reach
 * (dev containers expose the bucket on localhost; prod signs the CDN/bucket
 * origin). Bucket operations use the internal endpoint directly.
 */
function presignS3(): S3Client {
  if (presignClient === null) {
    // Presigning always targets the bucket/CDN host: uploads never flow
    // through our origin, whatever MEDIA_SERVE_MODE says about reads.
    const signEndpoint =
      config.s3.signEndpoint ??
      (config.s3.publicBaseUrl !== undefined ? ORIGIN_RE.exec(config.s3.publicBaseUrl)?.[1] : undefined) ??
      config.s3.endpoint;
    presignClient = new S3Client({
      region: config.s3.region,
      endpoint: signEndpoint || undefined,
      forcePathStyle: config.s3.forcePathStyle,
      credentials:
        config.s3.accessKey && config.s3.secretKey
          ? {
              accessKeyId: config.s3.accessKey,
              secretAccessKey: config.s3.secretKey,
            }
          : undefined,
    });
  }
  return presignClient;
}

function s3(): S3Client {
  if (client === null) {
    client = new S3Client({
      region: config.s3.region,
      endpoint: config.s3.endpoint || undefined,
      forcePathStyle: config.s3.forcePathStyle,
      credentials:
        config.s3.accessKey && config.s3.secretKey
          ? {
              accessKeyId: config.s3.accessKey,
              secretAccessKey: config.s3.secretKey,
            }
          : undefined,
    });
  }
  return client;
}

function bucket(): string {
  return config.s3.bucket;
}

/**
 * Pure URL-base decision so the bucket/proxy switch is unit-testable without
 * re-importing config. bucket: direct bucket or CDN origin. proxy: our own
 * origin, where the API streams derived renditions at /media/{key}.
 */
export function mediaBaseUrl(
  serveMode: "bucket" | "proxy",
  siteUrl: string,
  directBase: string,
): string {
  if (serveMode === "proxy") return `${siteUrl.replace(/\/+$/, "")}/media`;
  return directBase.replace(/\/+$/, "");
}

export function publicBaseUrl(): string {
  return mediaBaseUrl(config.s3.serveMode, config.siteUrl, bucketBaseUrl());
}

/** Direct bucket/CDN origin. Presigning and bucket ops must target this. */
export function bucketBaseUrl(): string {
  return (config.s3.publicBaseUrl ?? config.s3.endpoint ?? "").replace(/\/+$/, "");
}

const KEY_RE = /^[a-z0-9][a-z0-9/._-]{2,240}$/;

export function validateKey(key: string): string {
  if (!KEY_RE.test(key)) {
    throw new Error("invalid media key");
  }
  if (key.includes("..")) throw new Error("invalid media key");
  return key;
}

export function buildMediaKey(parts: {
  storeId: string;
  uploadId: string;
  ext: string;
}): string {
  const { storeId, uploadId, ext } = parts;
  return validateKey(`uploads/${storeId}/${uploadId}.${ext}`);
}

export function variantKey(originalKey: string, variant: "thumb" | "card" | "full"): string {
  const dot = originalKey.lastIndexOf(".");
  const base = dot > 0 ? originalKey.slice(0, dot) : originalKey;
  return validateKey(`${base}.${variant}.webp`);
}

export interface PresignedUpload {
  key: string;
  uploadUrl: string;
  expiresIn: number;
}

export async function presignUpload(key: string, mime: AllowedMime): Promise<PresignedUpload> {
  validateKey(key);
  const command = new PutObjectCommand({
    Bucket: bucket(),
    Key: key,
    ContentType: mime,
  });
  const uploadUrl = await getSignedUrl(presignS3(), command, { expiresIn: 600 });
  return { key, uploadUrl, expiresIn: 600 };
}

export function mimeToExt(mime: string): string {
  switch (mime) {
    case "image/jpeg":
      return "jpg";
    case "image/png":
      return "png";
    case "image/webp":
      return "webp";
    case "image/avif":
      return "avif";
    case "image/heic":
      return "heic";
    default:
      return "bin";
  }
}

/** Deterministic but unguessable upload id (no seeding / enumeration). */
export function newUploadId(): string {
  return randomBytes(12).toString("base64url").toLowerCase().replace(/[^a-z0-9]/g, "");
}

/** Wide facade used by callers that just need keys turned into public URLs. */
export const storage = {
  urlFor(key: string): string {
    return `${publicBaseUrl()}/${key.replace(/^\/+/, "")}`;
  },
  publicBaseUrl,
};

/**
 * Dev/prod boot strap: wait for the object store, then make sure the bucket
 * exists with anonymous download (public image URLs). Idempotent; failures
 * after the bucket exists only warn (public policy can be fixed by hand).
 */
export async function ensureBucket(attempts = 15, delayMs = 2000): Promise<void> {
  const {
    HeadBucketCommand,
    CreateBucketCommand,
    PutBucketPolicyCommand,
    PutBucketCorsCommand,
  } = await import("@aws-sdk/client-s3");
  const b = bucket();
  const publicRead = {
    Version: "2012-10-17",
    Statement: [
      {
        Effect: "Allow",
        Principal: { AWS: ["*"] },
        Action: ["s3:GetObject"],
        Resource: [`arn:aws:s3:::${b}/*`],
      },
    ],
  };
  // Browser uploads are cross-origin (SPA origin vs bucket origin), so the
  // bucket MUST answer preflights or every photo upload dies client-side
  // even though the server-side PUT would succeed.
  const browserCors:
    import("@aws-sdk/client-s3").PutBucketCorsCommandInput["CORSConfiguration"] = {
    CORSRules: [
      {
        AllowedOrigins: ["*"],
        AllowedMethods: ["GET", "PUT", "HEAD"] as const,
        AllowedHeaders: ["*"] as const,
        ExposeHeaders: ["ETag"] as const,
        MaxAgeSeconds: 3600,
      },
    ],
  };

  // Step 1: the bucket must exist. This is the only part worth retrying -
  // boot races against the stack's storage container coming up.
  for (let i = 0; i < attempts; i += 1) {
    try {
      try {
        await s3().send(new HeadBucketCommand({ Bucket: b }));
      } catch (err) {
        const code = (err as { name?: string }).name ?? "";
        if (!["NotFound", "NoSuchBucket", "404"].includes(code)) throw err;
        await s3().send(new CreateBucketCommand({ Bucket: b }));
      }
      break;
    } catch (err) {
      if (i === attempts - 1) throw err;
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  // Step 3: public-read policy + browser CORS, best effort and never
  // retried to death. Providers differ here (iDriveE2 denies the policy API
  // entirely; visibility is toggled in their console), so a failure only
  // warns - it must not stall every boot by 30 seconds.
  try {
    await s3().send(new PutBucketPolicyCommand({ Bucket: b, Policy: JSON.stringify(publicRead) }));
  } catch (err) {
    logger.warn({ err }, "bucket public-read policy not applied (may be provider-limited)");
  }
  try {
    await s3().send(new PutBucketCorsCommand({ Bucket: b, CORSConfiguration: browserCors }));
  } catch (err) {
    logger.warn({ err }, "bucket CORS not applied (may be provider-limited)");
  }
}
