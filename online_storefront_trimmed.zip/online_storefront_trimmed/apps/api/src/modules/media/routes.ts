import express from "express";
import { ApiError } from "../../errors.js";
import { mediaService } from "./service.js";
import { requireRole } from "../../middleware/auth.js";
import { requireStoreOwnership } from "../../middleware/store.js";
import { validateBody } from "../../middleware/validate.js";
import { ok } from "../../middleware/error.js";
import { presignSchema } from "../catalog/schemas.js";

export const mediaRouter = express.Router();

mediaRouter.use(requireRole("seller", "platform_owner"), requireStoreOwnership);

mediaRouter.post(
  "/presign",
  requireRole("seller", "platform_owner"),
  validateBody(presignSchema),
  async (req, res, next) => {
    try {
      const result = await mediaService.presign(
        req.storeOwnership!.storeId,
        req.auth!.userId,
        req.body,
      );
      ok(res, result, 201);
    } catch (err) {
      next(err);
    }
  },
);

mediaRouter.post("/confirm", requireRole("seller", "platform_owner"), async (req, res, next) => {
  try {
    const body = req.body as { key?: unknown; width?: unknown; height?: unknown };
    if (typeof body.key !== "string" || body.key.length < 4) {
      throw new ApiError(422, "VALIDATION", "Media key is required.");
    }
    const result = await mediaService.confirm(
      req.storeOwnership!.storeId,
      body.key,
      {
        width: typeof body.width === "number" ? Math.round(body.width) : undefined,
        height: typeof body.height === "number" ? Math.round(body.height) : undefined,
      },
    );
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/* --------------------------- media library (v1) --------------------------- */

mediaRouter.get("/", requireRole("seller", "platform_owner"), async (req, res, next) => {
  try {
    const page = Number(req.query.page) > 0 ? Number(req.query.page) : 1;
    const limit = Number(req.query.limit) > 0 ? Number(req.query.limit) : 24;
    const filter =
      req.query.filter === "orphan" || req.query.filter === "attached"
        ? (req.query.filter as "orphan" | "attached")
        : "all";
    const result = await mediaService.list(req.storeOwnership!.storeId, { page, limit, filter });
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/** Remove this media from the library AND the bucket (hard delete). */
mediaRouter.delete("/:uploadId", requireRole("seller", "platform_owner"), async (req, res, next) => {
  try {
    await mediaService.removeMedia(req.storeOwnership!.storeId, String(req.params.uploadId));
    ok(res, { deleted: true });
  } catch (err) {
    next(err);
  }
});

/** Clean up unattached/stale uploads for THIS store only. */
mediaRouter.post("/gc", requireRole("seller", "platform_owner"), async (req, res, next) => {
  try {
    const result = await mediaService.garbageCollect(req.storeOwnership!.storeId);
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/**
 * Bucket inventory scoped to this store's uploads prefix: real bucket
 * contents (originals and generated variants) so sellers can see exactly
 * what is physically stored. Read-only.
 */
mediaRouter.get("/bucket", requireRole("seller", "platform_owner"), async (req, res, next) => {
  try {
    const { listObjects } = await import("../../lib/objectstore.js");
    const objects = await listObjects({ prefix: `uploads/${req.storeOwnership!.storeId}/`, maxKeys: 500 });
    ok(res, { bucket: process.env.S3_BUCKET ?? "storesnap-media", objects });
  } catch (err) {
    next(err);
  }
});
