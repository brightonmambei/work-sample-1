/**
 * Media module service: upload records are the provenance ledger between
 * presigned upload and listing attachment. Variants are produced by the
 * worker (sharp WebP policy); confirm marks readiness.
 */
import { prisma } from "../../lib/prisma.js";
import { ApiError } from "../../errors.js";
import { deleteObjects } from "../../lib/objectstore.js";
import { publicBaseUrl, storage, variantKey, type AllowedMime } from "./storage.js";
import { sendVariantsJob } from "../../lib/queue.js";
import {
  ALLOWED_MIME,
  MAX_UPLOAD_BYTES,
  buildMediaKey,
  mimeToExt,
  newUploadId,
  presignUpload,
} from "./storage.js";

export interface MediaLibraryItem {
  id: string;
  key: string;
  url: string;
  cardUrl: string;
  mime: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  status: string;
  createdAt: string;
  attachedTo: Array<{ listingId: string; code: string; title: string; status: string }>;
  totalBytes: number;
}

export interface MediaLibraryPage {
  items: MediaLibraryItem[];
  pagination: { page: number; limit: number; total: number; totalPages: number };
  summary: { totalObjects: number; orphanCount: number; totalBytes: number };
}

export interface GcResult {
  deletedUploads: number;
  deletedObjects: number;
}

export interface PresignResult {
  uploadId: string;
  key: string;
  uploadUrl: string;
  expiresIn: number;
}

export const mediaService = {
  async presign(
    storeId: string,
    userId: string,
    input: { mime: string; sizeBytes: number },
  ): Promise<PresignResult> {
    if (input.sizeBytes > MAX_UPLOAD_BYTES) {
      throw new ApiError(413, "FILE_TOO_LARGE", "Images can be up to 12 MB.");
    }
    if (!ALLOWED_MIME.includes(input.mime as AllowedMime)) {
      throw new ApiError(415, "UNSUPPORTED_TYPE", "Use JPEG, PNG, WebP, AVIF or HEIC images.");
    }

    const uploadId = newUploadId();
    const key = buildMediaKey({
      storeId,
      uploadId,
      ext: mimeToExt(input.mime),
    });

    const presigned = await presignUpload(key, input.mime as AllowedMime);

    await prisma.upload.create({
      data: {
        id: uploadId,
        storeId,
        ownerUserId: userId,
        key,
        mime: input.mime,
        sizeBytes: input.sizeBytes,
        status: "pending",
      },
    });

    return {
      uploadId,
      key,
      uploadUrl: presigned.uploadUrl,
      expiresIn: presigned.expiresIn,
    };
  },

  /** Called after the browser finishes the presigned PUT: enqueue WebP variants. */
  async confirm(
    storeId: string,
    key: string,
    dims?: { width?: number; height?: number },
  ): Promise<{ uploadId: string }> {
    const upload = await prisma.upload.findFirst({
      where: { storeId, key, status: "pending" },
      select: { id: true },
    });
    if (!upload) {
      throw new ApiError(404, "UPLOAD_NOT_FOUND", "Start the upload again (it may have expired).");
    }

    await prisma.upload.update({
      where: { id: upload.id },
      data: { status: "ready", width: dims?.width ?? null, height: dims?.height ?? null },
    });

    // Fire-and-forget: variant generation never blocks the upload flow.
    await sendVariantsJob({ uploadId: upload.id, key });

    return { uploadId: upload.id };
  },

  async countPending(): Promise<number> {
    return prisma.upload.count({ where: { status: "pending" } });
  },
  async assertUploadOwned(storeId: string, uploadId: string): Promise<void> {
    const upload = await prisma.upload.findUnique({
      where: { id: uploadId },
      select: { storeId: true, key: true, status: true },
    });
    if (!upload || upload.storeId !== storeId || upload.status !== "ready") {
      throw new ApiError(400, "MEDIA_NOT_READY", "Finish or re-start that image upload.");
    }
  },

  /**
   * Media library (bucket-LEDGER view): uploads are the source of truth for
   * what the store owns; attachment info comes from listing_media.
   */
  async list(
    storeId: string,
    opts: { page?: number; limit?: number; filter?: "all" | "orphan" | "attached" } = {},
  ): Promise<MediaLibraryPage> {
    const page = Math.max(1, opts.page ?? 1);
    const limit = Math.min(60, Math.max(5, opts.limit ?? 24));

    const uploads = await prisma.upload.findMany({
      where: { storeId },
      orderBy: { createdAt: "desc" },
      include: {
        listingMedia: { include: { listing: { select: { id: true, code: true, title: true, status: true } } } },
      },
    });

    const mapped = uploads.map((u) => {
      const thumbUrl = publicBaseUrl() ? storage.urlFor(variantKey(u.key, "thumb")) : "";
      const cardUrl = publicBaseUrl() ? storage.urlFor(variantKey(u.key, "card")) : "";
      return {
        id: u.id,
        key: u.key,
        url: thumbUrl,
        cardUrl,
        mime: u.mime,
        sizeBytes: u.sizeBytes,
        width: u.width,
        height: u.height,
        status: u.status,
        createdAt: u.createdAt.toISOString(),
        attachedTo: u.listingMedia.map((lm) => ({
          listingId: lm.listing.id,
          code: lm.listing.code,
          title: lm.listing.title,
          status: lm.listing.status,
        })),
        totalBytes: u.sizeBytes,
      };
    });

    const filtered = mapped.filter((m) =>
      opts.filter === "orphan" ? m.attachedTo.length === 0 :
      opts.filter === "attached" ? m.attachedTo.length > 0 : true,
    );

    const start = (page - 1) * limit;
    const items = filtered.slice(start, start + limit);
    const orphanCount = mapped.filter((m) => m.attachedTo.length === 0).length;
    const totalBytes = mapped.reduce((s, m) => s + m.sizeBytes, 0);

    return {
      items,
      pagination: {
        page,
        limit,
        total: filtered.length,
        totalPages: Math.max(1, Math.ceil(filtered.length / limit)),
      },
      summary: {
        totalObjects: mapped.length,
        orphanCount,
        totalBytes,
      },
    };
  },

  /**
   * Delete one upload: DB row first, then bucket objects (originals +
   * deterministic variants). Media still referenced by non-archived listings
   * is refused so storefronts never show broken images; fully-archived
   * references are detached and the media may go.
   */
  async removeMedia(storeId: string, uploadId: string): Promise<void> {
    const upload = await prisma.upload.findUnique({
      where: { id: uploadId },
      select: { id: true, storeId: true, key: true },
    });
    if (!upload || upload.storeId !== storeId) {
      throw new ApiError(404, "MEDIA_NOT_FOUND", "Media not found.");
    }

    const refs = await prisma.listingMedia.findMany({
      where: { uploadId },
      include: { listing: { select: { status: true } } },
    });
    const liveRefs = refs.filter((r) => r.listing.status !== "archived");
    if (liveRefs.length > 0) {
      throw new ApiError(
        409,
        "MEDIA_IN_USE",
        `Used by ${liveRefs.length} item${liveRefs.length === 1 ? "" : "s"}. Remove it from those items first.`,
      );
    }

    const variantKeys = ([
      "thumb",
      "card",
      "full",
    ] as const).map((v) => variantKey(upload.key, v));
    await deleteObjects([upload.key, ...variantKeys]);

    await prisma.$transaction([
      prisma.listingMedia.deleteMany({ where: { uploadId } }),
      prisma.upload.delete({ where: { id: uploadId } }),
    ]);
  },

  /**
   * Orphan cleanup for a store (or ALL stores when storeId is omitted,
   * admin-only call path): ready-but-unattached uploads older than 24h and
   * stale pending uploads older than 7 days never landed anywhere useful.
   * The 24h guard keeps freshly uploaded media (variants in flight, wizard
   * open on another tab) from being surged away underneath the seller.
   */
  async garbageCollect(storeId?: string): Promise<GcResult> {
    const cutoffReady = new Date(Date.now() - 24 * 3600_000);
    const cutoffPending = new Date(Date.now() - 7 * 24 * 3600_000);
    const where = {
      createdAt: { lt: cutoffReady },
      listingMedia: { none: {} },
      ...(storeId !== undefined ? { storeId } : {}),
    };
    const candidates = await prisma.upload.findMany({
      where,
      select: { id: true, key: true, status: true, createdAt: true },
    });

    let deletedUploads = 0;
    let deletedObjects = 0;
    for (const u of candidates) {
      if (u.status === "pending" && u.createdAt > cutoffPending) continue;
      const keys =
        u.status === "ready"
          ? [u.key, ...(["thumb", "card", "full"] as const).map((v) => variantKey(u.key, v))]
          : [u.key];
      const got = await deleteObjects(keys);
      deletedObjects += got;
      await prisma.upload.delete({ where: { id: u.id } });
      deletedUploads += 1;
    }
    return { deletedUploads, deletedObjects };
  },
};

void MAX_UPLOAD_BYTES;
