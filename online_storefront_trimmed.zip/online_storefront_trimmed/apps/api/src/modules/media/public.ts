/**
 * Anonymous media proxy (MEDIA_SERVE_MODE=proxy).
 *
 * Public storefront images and og:image tags must be fetchable by anyone,
 * including scraper user agents that cannot sign URLs. When the bucket cannot
 * be made public (or when we simply want our own cache rules and to keep raw
 * originals unexposed), derived renditions are streamed through our origin at
 * /media/{key} instead of pointing at the bucket.
 *
 * Only derived webp artifacts are served: .thumb.webp, .card.webp, .full.webp
 * variants and share posters. Raw uploads (the originals a seller's camera
 * produced) never pass through here. Keys are unguessable by construction.
 */
import express from "express";
import { ApiError } from "../../errors.js";
import { getObject } from "../../lib/objectstore.js";
import { validateKey } from "./storage.js";

export const publicMediaRouter = express.Router();

/** Long-lived caching: variant and poster keys are immutable once written. */
const CACHE_CONTROL = "public, max-age=31536000, immutable";

const SERVABLE_RE = /\.(thumb|card|full)\.webp$|^share\/.+\/poster\/.+\.webp$/;

publicMediaRouter.get("/*key", async (req, res, next) => {
  try {
    const raw = req.params.key;
    const key = Array.isArray(raw) ? raw.join("/") : (raw ?? "");
    if (!SERVABLE_RE.test(key)) {
      throw new ApiError(404, "MEDIA_NOT_FOUND", "Media not found.");
    }
    try {
      validateKey(key);
    } catch {
      throw new ApiError(404, "MEDIA_NOT_FOUND", "Media not found.");
    }

    const bytes = await getObject(key);
    res
      .status(200)
      .set("Content-Type", "image/webp")
      .set("Cache-Control", CACHE_CONTROL)
      .set("Content-Length", String(bytes.byteLength))
      .send(bytes);
  } catch (err) {
    if ((err as { name?: string }).name === "NoSuchKey") {
      next(new ApiError(404, "MEDIA_NOT_FOUND", "Media not found."));
      return;
    }
    next(err);
  }
});
