import express from "express";
import { ok } from "../../middleware/error.js";
import { resolveStoreByHost } from "../../middleware/host.js";
import { optionalAuth } from "../../middleware/auth.js";
import { config } from "../../config.js";
import { ApiError } from "../../errors.js";
import { taxonomyService } from "../catalog/taxonomy.js";
import { catalogService } from "../catalog/service.js";
import { collectionsService } from "../collections/service.js";
import { shareService } from "../share/service.js";
import { storesService } from "../stores/service.js";
import { prisma } from "../../lib/prisma.js";

/**
 * Market bootstrap routes: what the buyer-side SPA reads first, keyed off the
 * requesting host (storefront should eventually serve per-tenant themes).
 */
export const marketRouter = express.Router();

marketRouter.use(resolveStoreByHost);

marketRouter.get("/current-store", optionalAuth, async (req, res, next) => {
  try {
    if (req.store) {
      const { slug, name, tagline, logoUrl, coverUrl, plan, status, theme, whatsappNumber } =
        req.store;

      // Draft preview (?preview=draft): owner only, and the draft is layered
      // over the published store. Anyone else silently gets the live theme.
      let effectiveTheme = theme;
      let previewingDraft = false;
      if (req.query.preview === "draft") {
        const draft = await storesService.previewThemeForOwner(slug, req.auth?.userId ?? null);
        if (draft !== null) {
          effectiveTheme = draft;
          previewingDraft = true;
        }
      }

      ok(res, {
        store: {
          slug,
          name,
          tagline,
          logoUrl,
          coverUrl,
          plan,
          status,
          theme: effectiveTheme,
          whatsappNumber,
        },
        mode: "tenant",
        previewingDraft,
      });
      return;
    }
    ok(res, {
      store: null,
      mode: "platform",
      platform: { name: "StoreSnap", storesDomain: config.storesDomain },
    });
  } catch (err) {
    next(err);
  }
});

/**
 * Global item route behind /p/:shortId human redirects. Works on any host:
 * the share code is globally unique, so no tenant host resolution needed.
 * Channel-tagged taps (?r=) land in the attribution ledger here.
 */
marketRouter.get("/p/:code", async (req, res, next) => {
  try {
    const code = String(req.params.code ?? "").slice(0, 40);
    const result = await catalogService.resolvePublicByCode(code);
    if (result.state === "gone" && result.store === null) {
      throw new ApiError(404, "LISTING_NOT_FOUND", "Item link not found.");
    }
    // Attribution: log the tap best-effort against the share link if it exists.
    const link = await prisma.shareLink
      .findUnique({ where: { code: code.toLowerCase() }, select: { id: true } })
      .catch(() => null);
    shareService.recordTap(link?.id ?? null, typeof req.query.r === "string" ? req.query.r : "");
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/**
 * Global drop read behind /p/{code} human redirects. Works on any host: the
 * code is globally unique. An ended drop still resolves so old group posts
 * land on a "this drop ended" page instead of a dead link (invariant 5).
 */
marketRouter.get("/collections/:code", async (req, res, next) => {
  try {
    const code = String(req.params.code ?? "").slice(0, 40);
    const result = await collectionsService.getPublicByCode(code);
    if (result.state === "gone") {
      throw new ApiError(404, "COLLECTION_NOT_FOUND", "Drop not found.");
    }
    const link = await prisma.shareLink
      .findUnique({ where: { code: code.toLowerCase() }, select: { id: true } })
      .catch(() => null);
    shareService.recordTap(link?.id ?? null, typeof req.query.r === "string" ? req.query.r : "");
    ok(res, result);
  } catch (err) {
    next(err);
  }
});

/** Shared taxonomy for storefront filters and the item editor. */
marketRouter.get("/categories", async (_req, res, next) => {
  try {
    ok(res, { categories: await taxonomyService.listActive() });
  } catch (err) {
    next(err);
  }
});
