/**
 * pg-boss singleton: Postgres-backed queue (AGENTS.md section 3). One less
 * container; the same DATABASE_URL as the API. Swap to Redis only if scale
 * demands it later.
 */
import { PgBoss } from "pg-boss";
import { config } from "../config.js";
import { logger } from "./logger.js";

let boss: PgBoss | null = null;
let started = false;

export type MediaVariantsJobData = {
  uploadId: string;
  key: string;
};

export const QUEUES = {
  mediaVariants: "media-variants",
  billingMetering: "billing-metering",
} as const;

export function queue(): PgBoss {
  if (boss === null) {
    boss = new PgBoss({
      connectionString: config.databaseUrl,
      // Keep the schema namespaced alongside Prisma modules.
      schema: "queue",
      max: process.env.QUEUE_CONCURRENCY ? Number(process.env.QUEUE_CONCURRENCY) : 3,
    });
    boss.on("error", (err: Error) => logger.error({ err }, "pg-boss error"));
  }
  return boss;
}

export async function startQueue(): Promise<PgBoss> {
  const b = queue();
  if (!started) {
    await b.start();
    await b.createQueue(QUEUES.mediaVariants);
    await b.createQueue(QUEUES.billingMetering);
    started = true;
  }
  return b;
}

/** Fire-and-forget enqueue with a hard retry cap so bad jobs do not loop. */
export async function sendVariantsJob(data: MediaVariantsJobData): Promise<void> {
  await startQueue();
  await (boss as PgBoss).send({
    name: QUEUES.mediaVariants,
    data,
    options: { retryLimit: 3, retryDelay: 30, expireInSeconds: 300 },
  });
}
