/** Hostnames arrive as `shop:4000` or uppercase; normalise for lookups. */
export function normaliseHost(input: string): string {
  return input.trim().toLowerCase().split(":")[0] ?? "";
}

const RESERVED = new Set([
  "www", "app", "api", "admin", "dashboard", "auth", "cdn", "static",
  "mail", "status", "docs", "help", "support", "platform", "shops",
  "snap", "assets", "assets2", "media", "staging", "dev", "test",
]);

const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/** Normalise + validate a store slug. Returns null when invalid. */
export function normaliseSlug(input: string): string | null {
  const slug = input
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^-+|-+$/g, "");

  if (slug.length < 3 || slug.length > 32) return null;
  if (!SLUG_RE.test(slug)) return null;
  if (RESERVED.has(slug)) return null;
  return slug;
}
