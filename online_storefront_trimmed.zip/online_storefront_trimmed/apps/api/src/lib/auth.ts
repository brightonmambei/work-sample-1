import { hash, verify } from "@node-rs/argon2";
import crypto from "node:crypto";
import jwt from "jsonwebtoken";
import { prisma } from "./prisma.js";
import { config, isProd } from "../config.js";
import { ApiError } from "../errors.js";
import type { User } from "@prisma/client";

/**
 * Session model:
 * - Access JWT (15 min, stateless) carries sub + role.
 * - Refresh token is an opaque random string; only its sha256 lives in DB.
 * - Rotation on every refresh; reuse of a revoked token revokes all sessions.
 */

const ARGON2_OPTS = { memoryCost: 19456, timeCost: 2, parallelism: 1 };

export async function hashPassword(plain: string): Promise<string> {
  return hash(plain, ARGON2_OPTS);
}

export async function verifyPassword(
  passwordHash: string,
  plain: string,
): Promise<boolean> {
  try {
    return await verify(passwordHash, plain, ARGON2_OPTS);
  } catch {
    return false;
  }
}

export const hashToken = (token: string): string =>
  crypto.createHash("sha256").update(token).digest("hex");

export const randomToken = (): string => crypto.randomBytes(48).toString("base64url");

export interface AccessClaims {
  sub: string;
  role: string;
}

export function signAccessToken(user: Pick<User, "id" | "role">): string {
  return jwt.sign({ sub: user.id, role: user.role }, config.jwtAccessSecret, {
    expiresIn: config.accessTtl,
  });
}

export function verifyAccessToken(token: string): AccessClaims {
  return jwt.verify(token, config.jwtAccessSecret) as AccessClaims;
}

export function refreshExpiry(): Date {
  return new Date(Date.now() + config.refreshTtl * 1000);
}

export async function createSession(
  userId: string,
  meta: { userAgent?: string; ip?: string } = {},
): Promise<string> {
  const refreshToken = randomToken();
  await prisma.session.create({
    data: {
      userId,
      refreshTokenHash: hashToken(refreshToken),
      userAgent: meta.userAgent ?? "",
      ip: meta.ip ?? "",
      expiresAt: refreshExpiry(),
    },
  });
  return refreshToken;
}

export async function rotateSession(
  refreshToken: string,
  meta: { userAgent?: string; ip?: string } = {},
): Promise<{ userId: string }> {
  const tokenHash = hashToken(refreshToken);
  const session = await prisma.session.findUnique({
    where: { refreshTokenHash: tokenHash },
    include: { user: true },
  });

  if (!session) {
    throw new ApiError(401, "SESSION_INVALID", "Session not recognized.");
  }

  if (session.revokedAt !== null || session.expiresAt < new Date()) {
    // Token reuse or expiry: kill the whole family.
    await prisma.session.updateMany({
      where: { userId: session.userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    throw new ApiError(401, "SESSION_EXPIRED", "Session ended. Sign in again.");
  }

  const fresh = randomToken();
  await prisma.$transaction([
    prisma.session.update({
      where: { id: session.id },
      data: { revokedAt: new Date() },
    }),
    prisma.session.create({
      data: {
        userId: session.userId,
        refreshTokenHash: hashToken(fresh),
        userAgent: meta.userAgent ?? session.userAgent,
        ip: meta.ip ?? session.ip,
        expiresAt: refreshExpiry(),
      },
    }),
  ]);

  return { userId: session.userId };
}

export async function revokeSession(refreshToken: string): Promise<void> {
  await prisma.session.updateMany({
    where: { refreshTokenHash: hashToken(refreshToken), revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function revokeAllSessions(userId: string): Promise<void> {
  await prisma.session.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export const REFRESH_COOKIE = "ss_rt";

export function refreshCookieOptions() {
  return {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax" as const,
    path: "/api/v1/auth",
    maxAge: config.refreshTtl * 1000,
  };
}
