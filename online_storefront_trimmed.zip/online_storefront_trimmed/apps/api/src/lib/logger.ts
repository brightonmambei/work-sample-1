import pino from "pino";
import { config, isDev } from "../config.js";

export const logger = pino({
  level: config.logLevel,
  base: { service: "storesnap-api" },
  ...(isDev
    ? {
        transport: {
          target: "pino-pretty",
          options: { colorize: true, translateTime: "HH:MM:ss" },
        },
      }
    : {}),
});
