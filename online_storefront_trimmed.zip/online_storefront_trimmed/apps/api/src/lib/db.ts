import { Pool } from "pg";
import { config } from "../config.js";

/**
 * Minimal DB probe for the health route. Prisma owns real queries from
 * Phase 1 onward; this exists so Phase 0 health checks can report the DB.
 */

let pool: Pool | null = null;
let lastProbe = 0;
let lastResult = false;
const PROBE_TTL_MS = 5_000;

function getPool(): Pool {
  if (!pool) {
    pool = new Pool({
      connectionString: config.databaseUrl,
      max: 2,
      connectionTimeoutMillis: 2_000,
    });
  }
  return pool;
}

export async function pingDb(): Promise<boolean> {
  const now = Date.now();
  if (now - lastProbe < PROBE_TTL_MS) {
    return lastResult;
  }
  try {
    const client = getPool();
    await client.query("SELECT 1");
    lastProbe = now;
    lastResult = true;
  } catch {
    lastProbe = now;
    lastResult = false;
  }
  return lastResult;
}
