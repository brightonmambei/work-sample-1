import { PrismaClient } from "@prisma/client";

declare global {
  // eslint-disable-next-line no-var
  var storesnapPrisma: PrismaClient | undefined;
}

export const prisma =
  global.storesnapPrisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  global.storesnapPrisma = prisma;
}
