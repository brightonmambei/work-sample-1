/**
 * Shared object-store facade (S3/MinIO/RustFS). The API (share poster
 * rendering) and the worker (variant pipeline) talk to the same bucket.
 * Endpoint/creds come from env: S3_* in both dev compose and prod.
 */
import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";

let s3Client: S3Client | null = null;

export function objectS3(): S3Client {
  if (s3Client === null) {
    s3Client = new S3Client({
      region: process.env.S3_REGION ?? "us-east-1",
      endpoint: process.env.S3_ENDPOINT || undefined,
      forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
      credentials:
        process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY
          ? {
              accessKeyId: process.env.S3_ACCESS_KEY,
              secretAccessKey: process.env.S3_SECRET_KEY,
            }
          : undefined,
    });
  }
  return s3Client;
}

export function objectBucket(): string {
  const b = process.env.S3_BUCKET;
  if (typeof b !== "string" || b.length === 0) throw new Error("S3_BUCKET is not configured");
  return b;
}

export async function getObject(key: string): Promise<Buffer> {
  const res = await objectS3().send(
    new GetObjectCommand({ Bucket: objectBucket(), Key: key }),
  );
  if (!res.Body) throw new Error(`object ${key} has no body`);
  const bytes = await res.Body.transformToByteArray();
  return Buffer.from(bytes);
}

export async function putObject(
  key: string,
  body: Buffer,
  contentType = "image/webp",
): Promise<void> {
  await objectS3().send(
    new PutObjectCommand({
      Bucket: objectBucket(),
      Key: key,
      Body: body,
      ContentType: contentType,
      CacheControl: "public, max-age=31536000, immutable",
    }),
  );
}

/**
 * Hard-delete objects from the bucket, VERIFIED. Some providers (iDriveE2)
 * return an empty Deleted set for batch deletes, so batch success is
 * checked per key with a HEAD and anything still present is deleted
 * individually. A key that still exists after all attempts is an error.
 */
export async function deleteObjects(keys: string[]): Promise<number> {
  if (keys.length === 0) return 0;
  const {
    DeleteObjectsCommand,
    DeleteObjectCommand,
    HeadObjectCommand,
  } = await import("@aws-sdk/client-s3");
  const unique = Array.from(new Set(keys));

  try {
    await objectS3().send(
      new DeleteObjectsCommand({
        Bucket: objectBucket(),
        Delete: {
          Objects: unique.map((Key) => ({ Key })),
          Quiet: false,
        },
      }),
    );
  } catch (err) {
    const code = (err as { name?: string }).name ?? "";
    if (!["NoSuchKey", "NotFound", "NoTraversal"].includes(code)) {
      // Batch unsupported or malformed on this provider; fall through and
      // delete one by one.
    }
  }

  let deleted = 0;
  for (const key of unique) {
    try {
      await objectS3().send(new HeadObjectCommand({ Bucket: objectBucket(), Key: key }));
      // Still there: nuke it directly.
      await objectS3().send(new DeleteObjectCommand({ Bucket: objectBucket(), Key: key }));
      deleted += 1;
    } catch (verifyErr) {
      if ((verifyErr as { name?: string }).name === "NotFound") {
        deleted += 1;
      } else {
        throw verifyErr;
      }
    }
  }
  return deleted;
}

/** List bucket objects (paginated) for inventory and orphan sweeps. */
export async function listObjects(opts: { prefix?: string; maxKeys?: number } = {}): Promise<
  Array<{ key: string; bytes: number; lastModified: string | null }>
> {
  const { ListObjectsV2Command } = await import("@aws-sdk/client-s3");
  const cap = opts.maxKeys ?? 1000;
  const out: Array<{ key: string; bytes: number; lastModified: string | null }> = [];
  let token: string | undefined;
  do {
    const res = await objectS3().send(
      new ListObjectsV2Command({
        Bucket: objectBucket(),
        Prefix: opts.prefix,
        ContinuationToken: token,
        MaxKeys: Math.min(1000, cap - out.length),
      }),
    );
    for (const o of res.Contents ?? []) {
      if (o.Key === undefined) continue;
      out.push({
        key: o.Key,
        bytes: o.Size ?? 0,
        lastModified: o.LastModified ? o.LastModified.toISOString() : null,
      });
    }
    token = res.IsTruncated ? res.NextContinuationToken : undefined;
  } while (token !== undefined && out.length < cap);
  return out;
}
