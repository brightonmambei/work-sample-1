/** Generic operational error with a stable machine code for clients. */
export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

export function notFound(resource: string): ApiError {
  return new ApiError(404, "NOT_FOUND", `${resource} not found`);
}
