import express from "express";
import { identityRouter } from "../modules/identity/index.js";
import { storesRouter, sellerStoreRouter } from "../modules/stores/routes.js";
import { marketRouter } from "../modules/market/index.js";
import { sellerCatalogRouter, publicCatalogRouter } from "../modules/catalog/routes.js";
import { mediaRouter } from "../modules/media/routes.js";
import { publicMediaRouter } from "../modules/media/public.js";
import {
  publicOrdersRouter,
  sellerOrdersRouter,
} from "../modules/orders/routes.js";
import { sellerShareRouter } from "../modules/share/routes.js";
import { shareRouter } from "../modules/share/routes.js";
import { sellerCollectionsRouter } from "../modules/collections/routes.js";
import { sellerBillingRouter, mpesaWebhookRouter } from "../modules/billing/routes.js";
import { adminRouter } from "../modules/admin/routes.js";
import { healthRouter } from "./health.js";

/**
 * v1 mount table. Identity carries its own scoped cookie parser (refresh
 * cookie only); host resolution applies to market/public-catalog routes and
 * to the storefront-scoped pages from Phase 2 onward.
 */
export const v1Router = express.Router();

v1Router.use("/health", healthRouter);
v1Router.use("/auth", ...identityRouter);
v1Router.use("/market", marketRouter);
// Buyer-facing catalog readable only for a resolved tenant host.
v1Router.use("/market", publicCatalogRouter);
v1Router.use("/stores", storesRouter);
v1Router.use("/seller/store", sellerStoreRouter);
v1Router.use("/seller/media", mediaRouter);
// Anonymous rendition serving when MEDIA_SERVE_MODE=proxy: public URLs point
// at {siteUrl}/media/{key}, which nginx/Vite forward here.
v1Router.use("/media", publicMediaRouter);
v1Router.use("/seller", sellerCatalogRouter);
v1Router.use("/seller/collections", sellerCollectionsRouter);
v1Router.use("/seller", sellerOrdersRouter);
v1Router.use("/seller", sellerBillingRouter);
v1Router.use("/seller/share", sellerShareRouter);
// Buyer checkout + tracking: tenant-scoped by host like the public catalog.
v1Router.use("/market", publicOrdersRouter);
// Canonical share links: bots get OG SSR, humans get the SPA route.
v1Router.use("/p", shareRouter);
// M-Pesa STK callbacks (platform revenue only; never seller sale money).
v1Router.use("/webhooks", mpesaWebhookRouter);
// Owner-grade console API (audit-logged).
v1Router.use("/admin", adminRouter);

