import { Router } from "express";
import { ok } from "../middleware/error.js";
import { pingDb } from "../lib/db.js";
import { config } from "../config.js";

export const healthRouter = Router();

healthRouter.get("/", async (_req, res, next) => {
  try {
    const db = await pingDb();
    ok(res, {
      status: "healthy",
      env: config.env,
      version: "0.1.0",
      uptimeSeconds: Math.floor(process.uptime()),
      checks: {
        database: db ? "ok" : "down",
      },
    });
  } catch (e) {
    next(e);
  }
});
