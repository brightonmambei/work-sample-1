/**
 * Admin bootstrap: creates or promotes a platform_owner account.
 *
 * Usage:
 *   ADMIN_EMAIL=admin@storesnap.co.ke ADMIN_PASSWORD=... \
 *     pnpm --filter @storesnap/api admin:bootstrap
 */
import { config as dotenv } from "dotenv";
dotenv();

import { prisma } from "../lib/prisma.js";
import { identityService } from "../modules/identity/service.js";

async function main(): Promise<void> {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) {
    console.error(
      "admin:bootstrap requires ADMIN_EMAIL and ADMIN_PASSWORD environment variables.",
    );
    process.exit(1);
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    await prisma.user.update({
      where: { email },
      data: { role: "platform_owner", status: "active" },
    });
    console.log(`Promoted existing account to platform_owner: ${email}`);
  } else {
    const result = await identityService.register({
      email,
      password,
      name: "Platform Owner",
      intent: "seller",
    });
    await prisma.user.update({
      where: { id: result.user.id },
      data: { role: "platform_owner" },
    });
    console.log(`Platform owner created: ${email}`);
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
