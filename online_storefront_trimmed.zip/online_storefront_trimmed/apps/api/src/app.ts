import express, { type Request } from "express";
import helmet from "helmet";
import cors from "cors";
import pinoHttp from "pino-http";
import { config, isDev } from "./config.js";
import { logger } from "./lib/logger.js";
import { v1Router } from "./routes/index.js";
import { errorHandler } from "./middleware/error.js";

export function createApp(): express.Express {
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  if (!isDev) {
    app.use(
      helmet({
        contentSecurityPolicy: false, // API returns JSON only
      }),
    );
  }
  app.use(
    cors({
      origin: (origin: string | undefined, cb) => {
        // Allow no-origin requests (curl, health checks, webviews).
        if (!origin) return cb(null, true);
        if (config.corsOrigin === origin) return cb(null, true);
        cb(new Error("Not allowed by CORS"));
      },
    }),
  );
  app.use(express.json({ limit: "2mb" }));
  app.use(
    pinoHttp({
      logger,
      quietReqLogger: true,
      autoLogging: {
        ignore: (req: Request) => req.url === "/api/v1/health",
      },
    }),
  );

  app.get("/", (_req, res) => {
    res.json({ name: "storesnap-api", status: "running" });
  });

  app.use("/api/v1", v1Router);

  app.use((_req, res) => {
    res.status(404).json({
      ok: false as const,
      error: { code: "NOT_FOUND", message: "Route not found" },
    });
  });
  app.use(errorHandler);

  return app;
}
