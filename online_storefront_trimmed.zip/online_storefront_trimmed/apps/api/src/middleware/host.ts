import type { NextFunction, Request, Response } from "express";
import { prisma } from "../lib/prisma.js";
import { config } from "../config.js";
import { normaliseHost } from "../lib/host.js";
import { themeSpecSchema, type ThemeSpec } from "@storesnap/shared";

/**
 * Tenant routing (AGENTS.md section 12):
 *   {slug}.{STORES_DOMAIN}  -> subdomain lookup
 *   domain from domains.active -> custom domain lookup
 *   localhost (dev) -> config.devStoreSlug escape hatch
 * Anything else: req.store = null; public routes degrade gracefully.
 */
export async function resolveStoreByHost(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    // Explicit slug override (public browsing of a store from any host, e.g.
    // item/social redirects on the app domain): ?storeSlug=... wins.
    const slugParam = typeof req.query.storeSlug === "string" ? req.query.storeSlug : "";
    let found: Awaited<ReturnType<typeof findBySlug>> = null;
    if (slugParam && /^[a-z0-9-]{1,64}$/i.test(slugParam)) {
      found = await findBySlug(slugParam.toLowerCase());
      if (found && found.status !== "active") found = null;
    }

    const host = normaliseHost(req.hostname);
    if (!found) {
      if (host.endsWith(`.${config.storesDomain}`)) {
        const subdomain = host.slice(0, -(config.storesDomain.length + 1));
        if (subdomain && !["www", "app", "api"].includes(subdomain)) {
          found = await findBySlug(subdomain);
        }
      } else if (host !== "localhost" && host !== "127.0.0.1" && host !== "0.0.0.0") {
        const byDomain = await prisma.domain.findFirst({
          where: { domain: host, status: "active" },
          select: { store: { select: storeSelection } },
        });
        found = byDomain?.store ?? null;
      }
    }

    // Dev escape hatch: local storefront preview without wildcard DNS.
    if (!found && config.devStoreSlug) {
      found = await findBySlug(config.devStoreSlug);
    }

    if (found && found.status !== "active") {
      found = null; // suspended stores never render
    }

    // Theme is re-validated on read: DB corruption snaps to a safe preset.
    req.store = found ? { ...found, theme: parseTheme(found.theme) } : null;
    // Tenant context for down-route consumers (public catalog, OG pages).
    if (req.store) res.locals.storeId = req.store.id;
    next();
  } catch (err) {
    next(err);
  }
}

function findBySlug(slug: string) {
  return prisma.store.findUnique({ where: { slug }, select: storeSelection });
}

const storeSelection = {
  id: true,
  slug: true,
  name: true,
  tagline: true,
  logoUrl: true,
  coverUrl: true,
  plan: true,
  status: true,
  theme: true,
  whatsappNumber: true,
} as const;

function parseTheme(raw: unknown): ThemeSpec {
  const candidate = themeSpecSchema.safeParse(raw);
  if (candidate.success) return candidate.data;
  return { schemaVersion: 1, preset: "pro-light", overrides: {} };
}
