/**
 * Store ownership guard: every seller-scoped route needs the caller's store;
 * attaching it on the request removes repeated lookups and closes the
 * "act on someone else's store" bug class.
 */
import type { NextFunction, Request, Response } from "express";
import { prisma } from "../lib/prisma.js";
import { ApiError } from "../errors.js";

export interface StoreOwnership {
  storeId: string;
  slug: string;
  plan: string;
  status: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      storeOwnership?: StoreOwnership;
    }
  }
}

export async function requireStoreOwnership(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.auth) {
      throw new ApiError(401, "UNAUTHENTICATED", "Sign in required.");
    }
    const store = await prisma.store.findUnique({
      where: { ownerId: req.auth.userId },
      select: { id: true, slug: true, plan: true, status: true },
    });
    if (!store) {
      throw new ApiError(404, "STORE_NOT_FOUND", "Create your store first.");
    }
    if (store.status !== "active") {
      throw new ApiError(403, "STORE_SUSPENDED", "This store is suspended.");
    }
    req.storeOwnership = {
      storeId: store.id,
      slug: store.slug,
      plan: store.plan,
      status: store.status,
    };
    next();
  } catch (err) {
    next(err);
  }
}
