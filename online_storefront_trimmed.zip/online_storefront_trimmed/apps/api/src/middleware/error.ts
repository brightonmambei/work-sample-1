import type { NextFunction, Request, Response } from "express";
import { logger } from "../lib/logger.js";
import { ApiError } from "../errors.js";

/**
 * Error envelope (see packages/shared/src/schema.ts apiErrorSchema):
 * { ok: false, error: { code, message }; clients can branch on `ok`.
 */
export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction,
): void {
  if (err instanceof ApiError) {
    res.status(err.status).json({
      ok: false as const,
      error: { code: err.code, message: err.message },
    });
    return;
  }

  logger.error({ err, url: req.url }, "unhandled error");
  res.status(500).json({
    ok: false as const,
    error: {
      code: "INTERNAL",
      message: "Something went wrong. Please try again.",
    },
  });
}

/** Uniform success envelope for API consumers. */
export function ok(res: Response, data: unknown, status = 200): void {
  res.status(status).json({ ok: true as const, data });
}
