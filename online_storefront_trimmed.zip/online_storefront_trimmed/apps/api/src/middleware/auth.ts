import type { NextFunction, Request, Response } from "express";
import { verifyAccessToken } from "../lib/auth.js";
import { ApiError } from "../errors.js";
import type { ThemeSpec } from "@storesnap/shared";

export interface AuthContext {
  userId: string;
  role: "buyer" | "seller" | "platform_owner";
}

export interface StoreContext {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  logoUrl: string | null;
  coverUrl: string | null;
  plan: string;
  status: string;
  theme: ThemeSpec;
  whatsappNumber: string | null;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthContext;
      store?: StoreContext | null;
    }
  }
}

function parseAuth(req: Request): AuthContext {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    throw new ApiError(401, "UNAUTHENTICATED", "Sign in required.");
  }
  try {
    const claims = verifyAccessToken(header.slice(7));
    return { userId: claims.sub, role: claims.role as AuthContext["role"] };
  } catch {
    throw new ApiError(401, "SESSION_EXPIRED", "Sign in again.");
  }
}

export function requireAuth(
  req: Request,
  _res: Response,
  next: NextFunction,
): void {
  try {
    req.auth = parseAuth(req);
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Attach the caller when a valid token is present, otherwise continue
 * anonymously. Used by public pages that behave differently for the owner
 * (draft storefront preview) without ever requiring a session.
 */
export function optionalAuth(req: Request, _res: Response, next: NextFunction): void {
  try {
    req.auth = parseAuth(req);
  } catch {
    req.auth = undefined;
  }
  next();
}

/** Roles checked separately so clients see 401 (re-auth) vs 403 (wrong role). */
export function requireRole(
  ...roles: Array<AuthContext["role"]>
): (req: Request, res: Response, next: NextFunction) => void {
  return (req, res, next) => {
    try {
      const auth = parseAuth(req);
      if (!roles.includes(auth.role)) {
        next(new ApiError(403, "FORBIDDEN", "Insufficient permissions."));
        return;
      }
      req.auth = auth;
      next();
    } catch (err) {
      next(err);
    }
  };
}
