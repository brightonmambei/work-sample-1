import type { NextFunction, Request, Response } from "express";
import type { ZodTypeAny, z } from "zod";
import { ApiError } from "../errors.js";

/** Validate + parse request body against a zod schema, attach to req.body. */
export function validateBody<T extends ZodTypeAny>(schema: T) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      const first = Object.entries(result.error.flatten().fieldErrors)[0]?.[1];
      next(
        new ApiError(
          422,
          "VALIDATION",
          first?.[0] ?? "Request body is invalid.",
        ),
      );
      return;
    }
    (req as Request & { body: z.infer<T> }).body = result.data;
    next();
  };
}

export function validateQuery<T extends ZodTypeAny>(schema: T) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req.query);
    if (!result.success) {
      next(new ApiError(422, "VALIDATION", "Invalid query parameters."));
      return;
    }
    // Express req.query is a getter; mutate contents instead of replacing.
    Object.assign(req.query as Record<string, unknown>, result.data);
    next();
  };
}
