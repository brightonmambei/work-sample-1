/**
 * Image variants worker (AGENTS.md section 8): consumes the media-variants
 * queue and produces WebP renditions with sharp:
 *   thumb 480w / card 960w / full 1600w, quality 80.
 * Originals are never modified: re-encoding can replay them later.
 */
import sharp from "sharp";
import { startQueue, QUEUES, type MediaVariantsJobData } from "./lib/queue.js";
import { logger } from "./lib/logger.js";
import { prisma } from "./lib/prisma.js";
import { variantKey, ensureBucket } from "./modules/media/storage.js";
import { billingService } from "./modules/billing/service.js";
import { getObject, putObject } from "./lib/objectstore.js";
const VARIANTS = [
  { name: "thumb", maxWidth: 480 },
  { name: "card", maxWidth: 960 },
  { name: "full", maxWidth: 1600 },
] as const;

/**
 * Process one uploaded original into WebP variants. Upscaling is never
 * applied: a 400px source photo keeps its 400px card, just compressed.
 */
export async function processVariants(data: MediaVariantsJobData): Promise<void> {
  const original = await getObject(data.key);
  const image = sharp(original, { failOn: "none" });
  const meta = await image.metadata();

  const results: {
    thumbKey?: string;
    cardKey?: string;
    fullKey?: string;
    width?: number;
    height?: number;
  } = {};

  for (const v of VARIANTS) {
    if (meta.width === undefined) continue;
    const width = Math.min(v.maxWidth, meta.width);
    const resized =
      meta.width > width
        ? image.resize({ width, withoutEnlargement: true })
        : sharp(original, { failOn: "none" });
    const buffer = await resized
      .webp({ quality: 80, effort: 4 })
      .toBuffer();
    const key = variantKey(data.key, v.name);
    await putObject(key, buffer);
    results[`${v.name}Key` as const] = key;
    if (!results.width) {
      const outMeta = await sharp(buffer).metadata();
      results.width = outMeta.width ?? undefined;
      results.height = outMeta.height ?? undefined;
    }
  }

  if (results.thumbKey === undefined && results.cardKey === undefined) {
    throw new Error(`no variants produced for ${data.key}`);
  }

  await prisma.listingMedia.updateMany({
    where: { uploadId: data.uploadId },
    data: {
      thumbKey: results.thumbKey ?? null,
      cardKey: results.cardKey ?? null,
      fullKey: results.fullKey ?? null,
      width: results.width ?? null,
      height: results.height ?? null,
    },
  });

  logger.info({ key: data.key }, "variants generated");
}

async function main(): Promise<void> {
  const boss = await startQueue();
  await ensureBucket().catch((err) => logger.warn({ err }, "bucket bootstrap failed"));
  // Rate card is DB-owned config: seed idempotently before any metering runs.
  await billingService.ensureDefaults().catch((err) => logger.warn({ err }, "rate card seed failed"));

  await boss.work<MediaVariantsJobData>(
    QUEUES.mediaVariants,
    { batchSize: 1 },
    async (jobs) => {
      for (const job of jobs) {
        await processVariants(job.data);
      }
    },
  );
  logger.info("worker: media-variants queue running");

  // Metering engine cron (AGENTS.md section 11): nightly aggregation of the
  // immutable usage ledger into usage_periods, then proportionate dunning.
  await boss.schedule(QUEUES.billingMetering, "15 3 * * *", {});
  await boss.work<{ reason?: string }>(
    QUEUES.billingMetering,
    { batchSize: 1 },
    async () => {
      const periods = await billingService.aggregateUsage();
      const dunning = await billingService.enforceOverdue();
      logger.info({ periods, ...dunning }, "metering pass complete");
    },
  );
  logger.info("worker: billing-metering schedule running");
}

main().catch((err) => {
  logger.error({ err }, "worker boot failed");
  process.exit(1);
});
