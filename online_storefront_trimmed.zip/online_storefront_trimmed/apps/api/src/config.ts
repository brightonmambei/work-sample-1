import { config as dotenv } from "dotenv";
dotenv();

import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.string().default("development"),
  PORT: z.coerce.number().default(4000),
  CORS_ORIGIN: z.string().default("http://localhost:5173"),
  LOG_LEVEL: z.string().default("info"),
  DATABASE_URL: z
    .string()
    .default("postgres://storesnap:storesnap@localhost:5434/storesnap"),

  JWT_ACCESS_SECRET: z.string().min(8).default("storesnap-dev-access-secret"),
  JWT_REFRESH_SECRET: z.string().min(8).default("storesnap-dev-refresh-secret"),
  ACCESS_TTL_SECONDS: z.coerce.number().default(60 * 15),
  REFRESH_TTL_SECONDS: z.coerce.number().default(60 * 60 * 24 * 30),

  /** Root domain tenants live under: {slug}.shops.storesnap.co.ke */
  STORES_DOMAIN: z.string().default("shops.storesnap.co.ke"),
  /** Local dev escape hatch: when host is localhost, resolve this store slug. */
  DEV_STORE_SLUG: z.string().optional(),

  /**
   * Consumer-facing platform origin: slug storefronts live at
   * {siteUrl}/s/{slug}; canonical share links are {siteUrl}/p/{code} (the
   * bot-unfurl route, which 302s humans into the slug storefront). In prod
   * the app domain (e.g. storesnap.co.ke); dev uses the Vite origin.
   */
  PUBLIC_SITE_URL: z.string().default("http://localhost:5173"),

  /** Object storage (MinIO dev, S3/B2 prod). */
  S3_BUCKET: z.string().default("storesnap-media"),
  S3_REGION: z.string().default("us-east-1"),
  S3_ENDPOINT: z.string().optional(),
  S3_FORCE_PATH_STYLE: z.string().default("false"),
  S3_ACCESS_KEY: z.string().optional(),
  S3_SECRET_KEY: z.string().optional(),
  /** Public origin of the bucket (CDN in prod; MinIO directly in dev). */
  S3_PUBLIC_BASE_URL: z.string().optional(),
  /** Browser-facing endpoint for presigned PUTs when it differs internally. */
  S3_SIGN_ENDPOINT: z.string().optional(),
  /**
   * How derived media (webp variants, share posters) reaches browsers.
   * bucket: direct bucket/CDN URLs (fastest, needs anonymous read enabled).
   * proxy: served by our own origin at /media/... (keeps the bucket private,
   * gives us cache control, and only derived renditions are exposed).
   */
  MEDIA_SERVE_MODE: z.enum(["bucket", "proxy"]).default("bucket"),

  /** Image variant worker concurrency. */
  QUEUE_CONCURRENCY: z.coerce.number().default(3),

  /** M-Pesa Daraja (Phase 4): stub mode collects instantly, no real STK. */
  MPESA_MODE: z.enum(["stub", "live"]).default("stub"),
  MPESA_ENV: z.enum(["sandbox", "production"]).default("sandbox"),
  MPESA_CONSUMER_KEY: z.string().optional(),
  MPESA_CONSUMER_SECRET: z.string().optional(),
  MPESA_SHORTCODE: z.string().optional(),
  MPESA_PASSKEY: z.string().optional(),
  /** Public URL of the API for webhook callbacks. */
  PUBLIC_API_URL: z.string().default("http://localhost:4000"),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error(
    "Invalid environment:",
    JSON.stringify(parsed.error.flatten().fieldErrors, null, 2),
  );
  process.exit(1);
}

export const config = {
  env: parsed.data.NODE_ENV,
  port: parsed.data.PORT,
  corsOrigin: parsed.data.CORS_ORIGIN,
  logLevel: parsed.data.LOG_LEVEL,
  databaseUrl: parsed.data.DATABASE_URL,
  jwtAccessSecret: parsed.data.JWT_ACCESS_SECRET,
  jwtRefreshSecret: parsed.data.JWT_REFRESH_SECRET,
  accessTtl: parsed.data.ACCESS_TTL_SECONDS,
  refreshTtl: parsed.data.REFRESH_TTL_SECONDS,
  storesDomain: parsed.data.STORES_DOMAIN,
  devStoreSlug: parsed.data.DEV_STORE_SLUG,
  s3: {
    bucket: parsed.data.S3_BUCKET,
    region: parsed.data.S3_REGION,
    endpoint: parsed.data.S3_ENDPOINT,
    forcePathStyle: parsed.data.S3_FORCE_PATH_STYLE === "true",
    accessKey: parsed.data.S3_ACCESS_KEY,
    secretKey: parsed.data.S3_SECRET_KEY,
    publicBaseUrl: parsed.data.S3_PUBLIC_BASE_URL,
    signEndpoint: parsed.data.S3_SIGN_ENDPOINT,
    serveMode: parsed.data.MEDIA_SERVE_MODE,
  },
  queueConcurrency: parsed.data.QUEUE_CONCURRENCY,
  mpesa: {
    mode: parsed.data.MPESA_MODE,
    env: parsed.data.MPESA_ENV,
    consumerKey: parsed.data.MPESA_CONSUMER_KEY,
    consumerSecret: parsed.data.MPESA_CONSUMER_SECRET,
    shortcode: parsed.data.MPESA_SHORTCODE,
    passkey: parsed.data.MPESA_PASSKEY,
    publicApiUrl: parsed.data.PUBLIC_API_URL,
  },
  siteUrl: parsed.data.PUBLIC_SITE_URL,
} as const;

export const isDev = config.env !== "production";
export const isProd = config.env === "production";
