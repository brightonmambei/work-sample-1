import { config } from "./config.js";
import { logger } from "./lib/logger.js";
import { createApp } from "./app.js";
import { taxonomyService } from "./modules/catalog/taxonomy.js";
import { ensureBucket } from "./modules/media/storage.js";
import { billingService } from "./modules/billing/service.js";

/**
 * Boot-time database work must survive a database that is still waking up:
 * Neon scale-to-zero and a Postgres container that restarts alongside the API
 * both produce a first-query failure that is gone a few seconds later.
 */
async function withRetry(
  label: string,
  fn: () => Promise<unknown>,
  attempts = 5,
): Promise<void> {
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      await fn();
      return;
    } catch (err) {
      if (attempt === attempts) throw err;
      const waitMs = Math.min(1000 * 2 ** (attempt - 1), 8000);
      logger.warn({ label, attempt, waitMs }, "boot step failed, retrying");
      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }
  }
}

async function main(): Promise<void> {
  // Idempotent: the taxonomy is DB-owned from first boot (Phase 2).
  await withRetry("taxonomy seed", () => taxonomyService.seedDefaults());
  // Bucket bootstrap: presign + public image URLs assume it exists.
  await withRetry("bucket bootstrap", () => ensureBucket()).catch((err) =>
    logger.warn({ err }, "bucket bootstrap failed"),
  );
  // Rate card is DB-owned admin config (AGENTS.md section 11), seeded here so
  // the console and metering agree from the first boot.
  await withRetry("rate card seed", () => billingService.ensureDefaults()).catch((err) =>
    logger.warn({ err }, "rate card seed failed"),
  );

  const app = createApp();
  app.listen(config.port, () => {
    logger.info(`storesnap-api listening on :${config.port}`);
  });
}

main().catch((err) => {
  logger.error({ err }, "api boot failed");
  process.exit(1);
});
