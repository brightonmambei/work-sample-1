import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts"],
    environment: "node",
    hookTimeout: 10_000,
    setupFiles: ["tests/setup.ts"],
  },
});
