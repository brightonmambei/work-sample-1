/**
 * Caption composer (share kit): the text a seller pastes into a WhatsApp
 * group. Deterministic, tested, no emojis and no em-dashes.
 */
import { describe, expect, it } from "vitest";
import { composeCaption, composeDropCaption } from "../src/modules/share/caption.js";

const base = {
  title: "Court Sneaker",
  priceKes: 3200,
  compareAtKes: null,
  condition: "new" as const,
  conditionGrade: null,
  stock: 7,
  storeName: "Kilimani Thrift Hub",
  locationLabel: "Nairobi",
  url: "https://storesnap.co.ke/p/abc123",
};

describe("share caption", () => {
  it("leads with the title, price and the canonical link", () => {
    expect(composeCaption(base)).toBe(
      [
        "Court Sneaker",
        "KSh 3,200",
        "Brand new - Kilimani Thrift Hub, Nairobi",
        "Order: https://storesnap.co.ke/p/abc123",
      ].join("\n"),
    );
  });

  it("shows the old price when the item is discounted", () => {
    const caption = composeCaption({ ...base, compareAtKes: 4500 });
    expect(caption).toContain("KSh 3,200 (was KSh 4,500)");
  });

  it("ignores a compare-at price that is not a real discount", () => {
    const caption = composeCaption({ ...base, compareAtKes: 3200 });
    expect(caption).toContain("KSh 3,200");
    expect(caption).not.toContain("was");
  });

  it("describes thrift grade and low stock", () => {
    const caption = composeCaption({
      ...base,
      condition: "thrift",
      conditionGrade: 4,
      stock: 2,
    });
    expect(caption).toContain("Thrift, grade 4/5");
    expect(caption).toContain("Only 2 left");
  });

  it("stays quiet about stock when there is plenty, and when there is none", () => {
    expect(composeCaption({ ...base, stock: 25 })).not.toContain("left");
    expect(composeCaption({ ...base, stock: 0 })).not.toContain("Only");
  });

  it("drops the location when the seller has not set one", () => {
    const caption = composeCaption({ ...base, locationLabel: null });
    expect(caption).toContain("Brand new - Kilimani Thrift Hub\n");
  });

  it("truncates a very long title instead of pasting a wall of text", () => {
    const caption = composeCaption({ ...base, title: "x".repeat(200) });
    const firstLine = caption.split("\n")[0]!;
    expect(firstLine.length).toBeLessThanOrEqual(70);
    expect(firstLine.endsWith("...")).toBe(true);
  });
});

describe("drop caption", () => {
  const drop = {
    title: "Friday drop",
    itemCount: 12,
    minPriceKes: 500,
    maxPriceKes: 4200,
    storeName: "Kilimani Thrift Hub",
    locationLabel: "Nairobi",
    url: "https://storesnap.co.ke/p/drop123",
  };

  it("leads with the title, then what is inside and the price range", () => {
    expect(composeDropCaption(drop)).toBe(
      [
        "Friday drop",
        "12 items · KSh 500 - KSh 4,200",
        "Kilimani Thrift Hub, Nairobi",
        "Browse: https://storesnap.co.ke/p/drop123",
      ].join("\n"),
    );
  });

  it("collapses a single price and a single item", () => {
    const one = composeDropCaption({
      ...drop,
      itemCount: 1,
      minPriceKes: 1500,
      maxPriceKes: 1500,
    });
    expect(one).toContain("1 item · KSh 1,500");
  });

  it("says restocking instead of an empty price when the drop is empty", () => {
    const empty = composeDropCaption({
      ...drop,
      itemCount: 0,
      minPriceKes: 0,
      maxPriceKes: 0,
    });
    expect(empty).toContain("0 items · Restocking");
  });

  it("drops the location when the seller has not set one", () => {
    const caption = composeDropCaption({ ...drop, locationLabel: null });
    expect(caption).toContain("12 items · KSh 500 - KSh 4,200\nKilimani Thrift Hub\n");
  });

  it("stays plain text: no emojis, no em-dashes", () => {
    const caption = composeDropCaption(drop);
    expect(caption).not.toMatch(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u);
    expect(caption).not.toContain("—");
  });

  it("truncates a very long title", () => {
    const caption = composeDropCaption({ ...drop, title: "x".repeat(200) });
    const firstLine = caption.split("\n")[0]!;
    expect(firstLine.length).toBeLessThanOrEqual(70);
    expect(firstLine.endsWith("...")).toBe(true);
  });
});
