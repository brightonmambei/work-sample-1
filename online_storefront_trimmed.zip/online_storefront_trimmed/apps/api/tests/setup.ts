/**
 * Test environment: loaded before any app import, so config.ts sees the
 * local MinIO settings (credentials are needed only for presign signing).
 */
process.env.S3_BUCKET ??= "storesnap-media";
process.env.S3_REGION ??= "us-east-1";
process.env.S3_ENDPOINT ??= "http://localhost:9000";
process.env.S3_FORCE_PATH_STYLE ??= "true";
process.env.S3_ACCESS_KEY ??= "storesnap";
process.env.S3_SECRET_KEY ??= "storesnap-secret";
process.env.S3_PUBLIC_BASE_URL ??= "http://localhost:9000/storesnap-media";
