/**
 * Unit coverage for the media URL base switch (no database needed): direct
 * bucket URLs versus same-origin proxying, plus the proxy route's own
 * guardrails are covered in mediamgmt.integration.test.ts.
 */
import { describe, expect, it } from "vitest";
import { mediaBaseUrl } from "../src/modules/media/storage.js";

describe("media base URL", () => {
  it("serves derived renditions from our own origin in proxy mode", () => {
    expect(
      mediaBaseUrl("proxy", "https://storesnap.co.ke/", "https://s3.example.com/bucket"),
    ).toBe("https://storesnap.co.ke/media");
  });

  it("keeps direct bucket/CDN URLs in bucket mode", () => {
    expect(
      mediaBaseUrl("bucket", "https://storesnap.co.ke", "https://cdn.example.com/bucket/"),
    ).toBe("https://cdn.example.com/bucket");
  });

  it("never lets a trailing slash double up", () => {
    expect(mediaBaseUrl("proxy", "http://localhost:5173", "x")).toBe("http://localhost:5173/media");
    expect(mediaBaseUrl("bucket", "http://localhost:5173", "http://localhost:9000/bucket")).toBe(
      "http://localhost:9000/bucket",
    );
  });
});
