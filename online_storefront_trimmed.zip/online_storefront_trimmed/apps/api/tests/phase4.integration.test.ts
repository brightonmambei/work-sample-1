/**
 * Phase 4 integration tests: subscriptions (plan change), the metering engine
 * (usage events to usage periods to invoice drafts, rate card math), invoice
 * collection with the M-Pesa STK stub, boost purchase activation, and the
 * minimal admin console (stores, invoices, rate card, audit log).
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";
import { billingService } from "../src/modules/billing/service.js";
import { hashPassword } from "../src/lib/auth.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

process.env.MPESA_MODE ??= "stub";

const suffix = randomBytes(4).toString("hex");
const SELLER_EMAIL = `billing-${suffix}@storesnap.test`;
const ADMIN_EMAIL = `admin-${suffix}@storesnap.test`;
const ADMIN_PASSWORD = "Str0ng-admin-pass!";

let sellerToken = "";
let adminToken = "";
let storeSlug = "";
let storeId = "";
let listingId = "";
/** The engine aggregates the CLOSED month; events land backdated. */
let lastMonth: Date;

function sellerAuth(): Record<string, string> {
  return { Authorization: `Bearer ${sellerToken}` };
}

function adminAuth(): Record<string, string> {
  return { Authorization: `Bearer ${adminToken}` };
}

const kesLine = (invoice: { lines: unknown }): Array<{ label: string; amountKes: number }> =>
  ((invoice.lines as { items?: Array<{ label: string; amountKes: number }> }).items ?? []);

afterAll(async () => {
  const emails = [SELLER_EMAIL, ADMIN_EMAIL];
  const users = await prisma.user.findMany({
    where: { email: { in: emails } },
    select: { id: true },
  });
  const ids = users.map((u) => u.id);
  const stores = await prisma.store.findMany({
    where: { slug: { startsWith: `billing-test-${suffix}` } },
    select: { id: true },
  });
  const sids = stores.map((s) => s.id);
  if (sids.length > 0) {
    await prisma.mpesaPayment.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.boostPurchase.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.usageInvoice.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.usagePeriod.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.billingUsageEvent.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.billingSubscription.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.hold.deleteMany({ where: { listing: { storeId: { in: sids } } } });
    await prisma.listingMedia.deleteMany({ where: { listing: { storeId: { in: sids } } } });
    await prisma.shareLink.deleteMany({ where: { listing: { storeId: { in: sids } } } });
    await prisma.orderItem.deleteMany({ where: { order: { storeId: { in: sids } } } });
    await prisma.order.deleteMany({ where: { storeId: { in: sids } } });
    await prisma.listing.deleteMany({
      where: { store: { slug: { startsWith: `billing-test-${suffix}` } } },
    });
    await prisma.auditLog.deleteMany({ where: { targetId: { in: sids } } });
    await prisma.rateCard.deleteMany({ where: { key: { startsWith: `test-rate-${suffix}` } } });
    await prisma.store.deleteMany({ where: { id: { in: sids } } });
  }
  await prisma.user.deleteMany({ where: { id: { in: ids } } });
});

d("billing engine", () => {
  let app: ReturnType<typeof createApp>;

  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    await billingService.ensureDefaults();
    app = createApp();
    const now = new Date();
    lastMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 5));

    // Seller + store flow (initially on Grow).
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Billing Seller", email: SELLER_EMAIL, password: "Str0ng-pass!" });
    sellerToken = reg.body.data.accessToken;
    const store = await request(app)
      .post("/api/v1/seller/store")
      .set(sellerAuth())
      .send({ name: "Billing Test Store", slug: `billing-test-${suffix}` });
    storeSlug = store.body.data.store.slug;
    storeId = store.body.data.store.id;

    // Platform owner for the admin console surface.
    await prisma.user.create({
      data: {
        email: ADMIN_EMAIL,
        name: "Platform Owner",
        role: "platform_owner",
        status: "active",
        passwordHash: await hashPassword(ADMIN_PASSWORD),
      },
    });
    const adminLogin = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    adminToken = adminLogin.body.data.accessToken;

    const category = await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } });
    const listing = await request(app)
      .post("/api/v1/seller/products")
      .set(sellerAuth())
      .send({
        title: "Boost target tee",
        priceKes: 1400,
        categoryId: category.id,
        condition: "new",
        stock: 5,
        publishNow: true,
        media: [],
      });
    expect(listing.status).toBe(201);
    listingId = listing.body.data.listing.id;
  });

  it("starts on Grow with a clean ledger", async () => {
    const res = await request(app).get("/api/v1/seller/billing").set(sellerAuth());
    expect(res.status).toBe(200);
    expect(res.body.data.subscription.plan).toBe("grow");
    expect(res.body.data.usage.recordedKes).toBe(0);
  });

  it("records a self-reported sale into the immutable ledger", async () => {
    const res = await request(app)
      .post("/api/v1/seller/sales/self-report")
      .set(sellerAuth())
      .send({ title: "WhatsApp jacket", amountKes: 5000, quantity: 2 });
    expect(res.status).toBe(201);
    const summary = await request(app).get("/api/v1/seller/usage/summary").set(sellerAuth());
    expect(summary.body.data.usage.units).toBe(1);
    expect(summary.body.data.usage.recordedKes).toBe(10000);
  });

  it("keeps metering on Grow at KSh 0 (no fee below Business tier)", async () => {
    expect(await billingService.feeFor(storeId, 100000)).toBe(0);
  });

  it("upgrades the plan and reflects it on the store", async () => {
    const res = await request(app)
      .post("/api/v1/seller/billing/plan")
      .set(sellerAuth())
      .send({ plan: "business", period: "monthly" });
    expect(res.status).toBe(200);
    const store = await prisma.store.findUnique({ where: { id: storeId } });
    expect(store?.plan).toBe("business");
    const sub = await prisma.billingSubscription.findUnique({ where: { storeId } });
    expect(sub?.status).toBe("active");
    expect(sub?.priceKes).toBe(2999);
  });

  it("aggregates closed-month usage into a period and computes the rate-card fee", async () => {
    // Current-month events sit outside the cycle; seed one in the closed month.
    await prisma.billingUsageEvent.create({
      data: { storeId, type: "sale_recorded", amountKes: 10000, createdAt: lastMonth },
    });
    const periods = await billingService.aggregateUsage();
    expect(periods).toBeGreaterThan(0);
    const period = await prisma.usagePeriod.findFirst({ where: { storeId } });
    expect(period).not.toBeNull();
    expect(period?.units).toBe(1);
    expect(period?.recordedKes).toBe(10000);
    // Rate card default: 100 bps (1%) => KSh 100, above the KSh 20 minimum.
    expect(period?.feeKes).toBe(100);
  });

  it("drafts the invoice from the period; a second draft is rejected", async () => {
    const invoice = await billingService.draftUsageInvoice(storeId);
    const created = invoice as unknown as {
      status: string;
      totalKes: number;
      lines: unknown;
      id: string;
    };
    expect(created.status).toBe("draft");
    expect(created.totalKes).toBe(100);
    expect(kesLine(created)).toEqual([
      { label: expect.stringContaining("10,000"), amountKes: 100 },
    ]);

    await expect(billingService.draftUsageInvoice(storeId)).rejects.toMatchObject({
      code: "INVOICE_EXISTS",
    });
  });

  it("respects the minimum fee on tiny recorded volumes", async () => {
    await prisma.billingUsageEvent.create({
      data: { storeId, type: "sale_recorded", amountKes: 300, orderId: null, createdAt: lastMonth },
    });
    await billingService.aggregateUsage();
    const nextFee = await billingService.feeFor(storeId, 300);
    const card = await prisma.rateCard.findUniqueOrThrow({
      where: { key: "usage_fee_recorded_sales" },
    });
    // 300 x rate < minimum => the minimum applies (invariant: fee never tiny).
    const computed = Math.max(Math.round((300 * card.feeBps) / 10_000), card.minFeeKes);
    expect(nextFee).toBe(computed);

    // The re-aggregated period carries the recomputed fee (10,300 recorded).
    const period = await prisma.usagePeriod.findFirstOrThrow({ where: { storeId } });
    const periodFee = Math.max(
      Math.round((period.recordedKes * card.feeBps) / 10_000),
      card.minFeeKes,
    );
    expect(period.feeKes).toBe(periodFee);
  });

  it("collects the invoice over the M-Pesa stub and settles it paid", async () => {
    const invoice = await prisma.usageInvoice.findFirst({
      where: { storeId, status: "draft" },
      orderBy: { createdAt: "desc" },
    });
    expect(invoice).not.toBeNull();
    const res = await request(app)
      .post(`/api/v1/seller/billing/invoices/${invoice!.id}/collect`)
      .set(sellerAuth())
      .send({ phone: "0712345678" });
    expect(res.status).toBe(200);
    expect(res.body.data.payment.status).toBe("success");

    const settled = await prisma.usageInvoice.findUnique({ where: { id: invoice!.id } });
    expect(settled?.status).toBe("paid");
    expect(settled?.paidAt).not.toBeNull();
  });

  it("webhook settlement is idempotent against the stub receipt", async () => {
    const payment = await prisma.mpesaPayment.findFirstOrThrow({ where: { storeId } });
    // Second settlement attempt on an already-settled payment must no-op.
    await billingService.settlePayment(payment.checkoutRequestId, {
      success: true,
      receipt: "DOUBLE",
    });
    const again = await prisma.mpesaPayment.findUniqueOrThrow({ where: { id: payment.id } });
    expect(again.mpesaReceiptNumber).not.toBe("DOUBLE");
  });

  it("purchases a boost and activates the featured window", async () => {
    const res = await request(app)
      .post("/api/v1/seller/boosts")
      .set(sellerAuth())
      .send({ listingId, packKey: "feature_72h", phone: "0712345678" });
    expect(res.status).toBe(201);
    expect(res.body.data.boost.status).toBe("paid");

    const listing = await prisma.listing.findUniqueOrThrow({ where: { id: listingId } });
    expect(listing.boostedUntil).not.toBeNull();
    const until = listing.boostedUntil as Date;
    expect(until.getTime()).toBeGreaterThan(Date.now() + 70 * 3600_000);
  });

  it("rejects an unknown boost pack", async () => {
    const res = await request(app)
      .post("/api/v1/seller/boosts")
      .set(sellerAuth())
      .send({ listingId, packKey: "feature_999h", phone: "0712345678" });
    expect(res.status).toBe(422);
  });

  it("admin overview reports revenue and plan mix", async () => {
    const res = await request(app).get("/api/v1/admin/overview").set(adminAuth());
    expect(res.status).toBe(200);
    expect(res.body.data.overview.activeStores).toBeGreaterThan(0);
    expect(res.body.data.overview.mrrKes).toBeGreaterThanOrEqual(2999);
    expect(res.body.data.overview.boostRevenueKes).toBeGreaterThanOrEqual(100);
    expect(res.body.data.overview.recordedSales.units).toBeGreaterThan(0);
  });

  it("admin lists stores, and forbids the console to non-owners", async () => {
    const forbidden = await request(app).get("/api/v1/admin/stores").set(sellerAuth());
    expect(forbidden.status).toBe(403);

    const res = await request(app).get("/api/v1/admin/stores").set(adminAuth());
    expect(res.status).toBe(200);
    const row = res.body.data.stores.find((s: { slug: string }) => s.slug === storeSlug);
    expect(row).toBeTruthy();
    expect(row.plan).toBe("business");
  });

  it("admin suspends and restores a store with audit entries", async () => {
    const suspend = await request(app)
      .post(`/api/v1/admin/stores/${storeId}/suspend`)
      .set(adminAuth());
    expect(suspend.status).toBe(200);
    expect((await prisma.store.findUniqueOrThrow({ where: { id: storeId } })).status).toBe(
      "suspended",
    );

    const restore = await request(app)
      .post(`/api/v1/admin/stores/${storeId}/restore`)
      .set(adminAuth());
    expect(restore.status).toBe(200);
    expect((await prisma.store.findUniqueOrThrow({ where: { id: storeId } })).status).toBe(
      "active",
    );

    const audit = await request(app).get("/api/v1/admin/audit").set(adminAuth());
    const actions = audit.body.data.entries.map((e: { action: string }) => e.action);
    expect(actions).toContain("store.suspend");
    expect(actions).toContain("store.restore");
  });

  it("admin releases a draft invoice, voids drafts, and refuses voiding paid ones", async () => {
    const paid = await prisma.usageInvoice.findFirstOrThrow({ where: { storeId, status: "paid" } });
    const refuse = await request(app)
      .post(`/api/v1/admin/invoices/${paid.id}/void`)
      .set(adminAuth());
    expect(refuse.status).toBe(409);

    const draft = await prisma.usageInvoice.create({
      data: {
        storeId,
        status: "draft",
        totalKes: 45,
        lines: { items: [] },
      },
    });
    const release = await request(app)
      .post(`/api/v1/admin/invoices/${draft.id}/release`)
      .set(adminAuth());
    expect(release.status).toBe(200);

    const voided = await request(app)
      .post(`/api/v1/admin/invoices/${draft.id}/void`)
      .set(adminAuth());
    expect(voided.status).toBe(200);
    expect((await prisma.usageInvoice.findUniqueOrThrow({ where: { id: draft.id } })).status).toBe(
      "void",
    );

    const audit = await request(app).get("/api/v1/admin/audit").set(adminAuth());
    const actions = audit.body.data.entries.map((e: { action: string }) => e.action);
    expect(actions).toContain("invoice.release");
    expect(actions).toContain("invoice.void");
  });

  it("adjusts an invoice total from the console (corrections on the invoice, never the ledger)", async () => {
    const draft = await prisma.usageInvoice.create({
      data: { storeId, status: "draft", totalKes: 80, lines: { items: [] } },
    });
    const adjust = await request(app)
      .post(`/api/v1/admin/invoices/${draft.id}/adjust`)
      .set(adminAuth())
      .send({ deltaKes: -20 });
    expect(adjust.status).toBe(200);
    expect(adjust.body.data.invoice.totalKes).toBe(60);
    await prisma.usageInvoice.delete({ where: { id: draft.id } });
  });

  it("admin updates the rate card and the meter uses the new rate", async () => {
    const put = await request(app)
      .put("/api/v1/admin/rate-card/usage_fee_recorded_sales")
      .set(adminAuth())
      .send({ feeBps: 250, minFeeKes: 30, active: true });
    expect(put.status).toBe(200);

    const fee = await billingService.feeFor(storeId, 10000);
    expect(fee).toBe(Math.max(Math.round((10000 * 250) / 10_000), 30));

    // Restore the default so shared rate card rows stay predictable.
    await prisma.rateCard.update({
      where: { key: "usage_fee_recorded_sales" },
      data: { feeBps: 100, minFeeKes: 20 },
    });
  });

  it("enforceOverdue marks stale issued invoices overdue", async () => {
    // Fresh issued invoices are never overdue; the dunning pass reports cleanly.
    const result = await billingService.enforceOverdue();
    expect(result.pastDue).toBe(0);
  });
});
