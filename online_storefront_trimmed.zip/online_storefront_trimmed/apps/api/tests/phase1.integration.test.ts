/**
 * Phase 1 integration tests: identity + tenants + host routing.
 * These hit a real Postgres; run with the dev stack up:
 *   RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 * Without it, the suite skips (CI has no DB yet).
 */
import { afterAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

const suffix = randomBytes(4).toString("hex");
const EMAIL = `seller-${suffix}@storesnap.test`;
const EMAIL2 = `buyer-${suffix}@storesnap.test`;

function extractRefresh(res: request.Response): string {
  const raw = res.headers["set-cookie"] ?? [];
  const list = Array.isArray(raw) ? raw : [raw];
  for (const c of list) {
    const match = /ss_rt=([^;]+)/.exec(String(c));
    if (match?.[1]) return match[1];
  }
  return "";
}

d("identity + stores flow", () => {
  it("registers a seller and returns tokens", async () => {
    const res = await request(createApp())
      .post("/api/v1/auth/register")
      .send({ name: "Wanjiku Neci", email: EMAIL, password: "Str0ng-pass!" });
    expect(res.status).toBe(201);
    expect(res.body.ok).toBe(true);
    expect(res.body.data.user.role).toBe("seller");
    expect(extractRefresh(res)).not.toBe("");
  });

  it("blocks duplicate email registration", async () => {
    const res = await request(createApp())
      .post("/api/v1/auth/register")
      .send({ name: "Again", email: EMAIL, password: "Str0ng-pass!" });
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe("EMAIL_TAKEN");
  });

  it("rejects weak payloads with the error envelope", async () => {
    const res = await request(createApp())
      .post("/api/v1/auth/register")
      .send({ name: "x", email: "not-an-email", password: "short" });
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe("VALIDATION");
  });

  it("logs in and reports /auth/me", async () => {
    const login = await request(createApp())
      .post("/api/v1/auth/login")
      .send({ email: EMAIL, password: "Str0ng-pass!" });
    expect(login.status).toBe(200);

    const me = await request(createApp())
      .get("/api/v1/auth/me")
      .set("Authorization", `Bearer ${login.body.data.accessToken}`);
    expect(me.body.data.user.email).toBe(EMAIL);
  });

  it("rotates refresh sessions and detects token reuse", async () => {
    const reg = await request(createApp())
      .post("/api/v1/auth/register")
      .send({ name: "Buyer One", email: EMAIL2, password: "Str0ng-pass!" });
    const firstRefresh = extractRefresh(reg);

    const rot = await request(createApp())
      .post("/api/v1/auth/refresh")
      .set("Cookie", `ss_rt=${firstRefresh}`);
    expect(rot.status).toBe(200);
    const secondRefresh = extractRefresh(rot);

    // Reuse the first (now revoked) token: whole family must die.
    const reuse = await request(createApp())
      .post("/api/v1/auth/refresh")
      .set("Cookie", `ss_rt=${firstRefresh}`);
    expect(reuse.status).toBe(401);

    const after = await request(createApp())
      .post("/api/v1/auth/refresh")
      .set("Cookie", `ss_rt=${secondRefresh}`);
    expect(after.status).toBe(401);
  });

  it("creates a store, enforces slug rules, resolves by host", async () => {
    const reg = await request(createApp())
      .post("/api/v1/auth/register")
      .send({ name: "Store Owner", email: `owner-${suffix}@storesnap.test`, password: "Str0ng-pass!" });
    const token = reg.body.data.accessToken as string;

    const app = createApp();

    // slug validation
    const badSlug = await request(app)
      .post("/api/v1/seller/store")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Kilimani Wheels", slug: "admin" });
    expect(badSlug.status).toBe(422);

    const created = await request(app)
      .post("/api/v1/seller/store")
      .set("Authorization", `Bearer ${token}`)
      .send({
        name: "Kilimani Wheels",
        slug: `kilimani-wheels-${suffix}`,
        tagline: "Car parts and accessories",
        whatsappNumber: "254712345678",
        locationLabel: "Kilimani, Nairobi",
        themePreset: "pro-dark",
      });
    expect(created.status).toBe(201);
    expect(created.body.data.store.slug).toBe(`kilimani-wheels-${suffix}`);
    expect(created.body.data.store.theme.preset).toBe("pro-dark");

    // one store per owner
    const second = await request(app)
      .post("/api/v1/seller/store")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Other", slug: `other-${suffix}` });
    expect(second.status).toBe(409);

    // slug check reflects availability
    const check = await request(app).get(
      `/api/v1/stores/slug-check?slug=kilimani-wheels-${suffix}`,
    );
    expect(check.body.data.available).toBe(false);

    // public storefront bootstrap
    const pub = await request(app).get(`/api/v1/stores/kilimani-wheels-${suffix}`);
    expect(pub.body.data.store.name).toBe("Kilimani Wheels");

    // wildcard subdomain host resolution
    const host = await request(app)
      .get("/api/v1/market/current-store")
      .set("Host", `kilimani-wheels-${suffix}.shops.storesnap.co.ke`);
    expect(host.body.data.mode).toBe("tenant");
    expect(host.body.data.store.slug).toBe(`kilimani-wheels-${suffix}`);

    // unknown platform host degrades gracefully
    const none = await request(app)
      .get("/api/v1/market/current-store")
      .set("Host", "unknown.example.com");
    expect(none.body.data.mode).toBe("platform");
    expect(none.body.data.store).toBeNull();
  });

  it("keeps suspended stores out of host resolution", async () => {
    const store = await prisma.store.findFirst({
      where: { slug: { startsWith: "kilimani-wheels-" } },
    });
    if (!store) return; // previous test guarantees presence
    await prisma.store.update({ where: { id: store.id }, data: { status: "suspended" } });

    const host = await request(createApp())
      .get("/api/v1/market/current-store")
      .set("Host", `${store.slug}.shops.storesnap.co.ke`);
    expect(host.body.data.mode).toBe("platform");

    await prisma.store.update({ where: { id: store.id }, data: { status: "active" } });
  });

  afterAll(async () => {
    await prisma.store.deleteMany({ where: { slug: `kilimani-wheels-${suffix}` } });
    await prisma.user.deleteMany({
      where: { email: { endsWith: `-${suffix}@storesnap.test` } },
    });
    await prisma.$disconnect();
  });
});
