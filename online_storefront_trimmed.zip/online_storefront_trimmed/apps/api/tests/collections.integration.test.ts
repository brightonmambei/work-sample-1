/**
 * Collections ("drops") integration: seller CRUD, the canonical /p/{code}
 * unfurl for a collection (bot HTML with the generated collage, human 302 to
 * the SPA drop page), attribution plumbing, cross-tenant refusal and the
 * "ended drops never die" rule (AGENTS.md invariants 5 and 8).
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import sharp from "sharp";
import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";
import { deleteObjects } from "../src/lib/objectstore.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

process.env.S3_ACCESS_KEY ??= "storesnap";
process.env.S3_SECRET_KEY ??= "storesnap-secret";

const suffix = randomBytes(4).toString("hex");
const EMAIL = `col-${suffix}@storesnap.test`;
const SLUG = `col-test-${suffix}`;
const STRANGER_EMAIL = `col-stranger-${suffix}@storesnap.test`;
const STRANGER_SLUG = `col-stranger-${suffix}`;

let accessToken = "";
let strangerToken = "";
let storeId = "";
let categoryId = "";
const listingIds: string[] = [];
let dropCode = "";
let dropId = "";
let dropCardUrl: string | null = null;

function auth(token = accessToken): Record<string, string> {
  return { Authorization: `Bearer ${token}` };
}

function s3(): S3Client {
  return new S3Client({
    region: process.env.S3_REGION ?? "us-east-1",
    endpoint: process.env.S3_ENDPOINT,
    forcePathStyle: true,
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY!,
      secretAccessKey: process.env.S3_SECRET_KEY!,
    },
  });
}

/** A real (tiny) photo in the bucket, attached as the listing hero. */
async function attachHero(listingId: string, color: string): Promise<void> {
  const png = await sharp({
    create: { width: 120, height: 160, channels: 3, background: color },
  })
    .png()
    .toBuffer();
  const key = `col/${suffix}/${listingId}.png`;
  await s3().send(
    new PutObjectCommand({
      Bucket: process.env.S3_BUCKET ?? "storesnap-media",
      Key: key,
      Body: png,
      ContentType: "image/png",
    }),
  );
  const upload = await prisma.upload.create({
    data: {
      id: `up${listingId}`,
      storeId,
      ownerUserId: "",
      key,
      mime: "image/png",
      sizeBytes: png.length,
      width: 120,
      height: 160,
      status: "ready",
    },
  });
  await prisma.listingMedia.create({
    data: {
      listingId,
      uploadId: upload.id,
      isHero: true,
      sortOrder: 0,
      thumbKey: key,
      cardKey: key,
      fullKey: key,
      width: 120,
      height: 160,
    },
  });
}

d("collections: drop links, unfurls and cross-tenant guards", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();

    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Drop Seller", email: EMAIL, password: "Str0ng-pass!" });
    accessToken = reg.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set(auth())
      .send({ name: "Drop Test Store", slug: SLUG, whatsappNumber: "+254700000001" });
    storeId = (await prisma.store.findUniqueOrThrow({ where: { slug: SLUG } })).id;
    categoryId = (await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } })).id;

    const stranger = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Stranger", email: STRANGER_EMAIL, password: "Str0ng-pass!" });
    strangerToken = stranger.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set(auth(strangerToken))
      .send({ name: "Stranger Store", slug: STRANGER_SLUG });

    // Three live listings, each with a real hero photo.
    const prices = [1200, 2400, 3600];
    for (let i = 0; i < prices.length; i += 1) {
      const res = await request(app)
        .post("/api/v1/seller/products")
        .set(auth())
        .send({
          title: `Drop Item ${i + 1}`,
          priceKes: prices[i],
          categoryId,
          condition: i === 0 ? "thrift" : "new",
          conditionGrade: i === 0 ? 4 : null,
          stock: 5,
          publishNow: true,
          media: [],
        });
      const id = res.body.data.listing.id as string;
      listingIds.push(id);
      await attachHero(id, i === 0 ? "#8a7d5c" : i === 1 ? "#3f5d5a" : "#6a4b6b");
    }
  }, 60_000);

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: SLUG } });
    const bucketKeys: string[] = [];
    if (store) {
      const uploads = await prisma.upload.findMany({
        where: { storeId: store.id },
        select: { key: true },
      });
      bucketKeys.push(...uploads.map((u) => u.key));
      const collections = await prisma.collection.findMany({
        where: { storeId: store.id },
        select: { cardKey: true },
      });
      bucketKeys.push(...collections.map((c) => c.cardKey).filter((k): k is string => k !== null));

      await prisma.shareEvent.deleteMany({ where: { shareLink: { collection: { storeId: store.id } } } });
      await prisma.shareLink.deleteMany({ where: { collection: { storeId: store.id } } });
      await prisma.collectionItem.deleteMany({ where: { collection: { storeId: store.id } } });
      await prisma.collection.deleteMany({ where: { storeId: store.id } });
      await prisma.shareEvent.deleteMany({ where: { shareLink: { listing: { storeId: store.id } } } });
      await prisma.shareLink.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.listingMedia.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.listing.deleteMany({ where: { storeId: store.id } });
      await prisma.upload.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    if (bucketKeys.length > 0) {
      await deleteObjects(bucketKeys).catch(() => undefined);
    }
    const strangerStore = await prisma.store.findUnique({ where: { slug: STRANGER_SLUG } });
    if (strangerStore) await prisma.store.delete({ where: { id: strangerStore.id } });
    for (const email of [EMAIL, STRANGER_EMAIL]) {
      const user = await prisma.user.findUnique({ where: { email } });
      if (user) await prisma.user.delete({ where: { id: user.id } });
    }
    await prisma.$disconnect();
  });

  it("creates a drop with a canonical link, a caption and a rendered card", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/v1/seller/collections")
      .set(auth())
      .send({
        title: "Friday drop",
        description: "Sizes 6 to 12",
        listingIds,
      });

    expect(res.status).toBe(201);
    const drop = res.body.data.collection;
    dropId = drop.id;
    dropCode = drop.code;

    expect(drop.title).toBe("Friday drop");
    expect(drop.itemCount).toBe(3);
    expect(drop.minPriceKes).toBe(1200);
    expect(drop.maxPriceKes).toBe(3600);
    // The copied link is the unfurl route, never the SPA path.
    expect(drop.shareUrl).toContain(`/p/${drop.code}`);
    expect(drop.caption.split("\n")[0]).toBe("Friday drop");
    expect(drop.caption).toContain("3 items · KSh 1,200 - KSh 3,600");
    expect(drop.caption).toContain("Drop Test Store");
    expect(drop.caption).toContain(`Browse: ${drop.shareUrl}`);
    // Collage rendered from the item photos.
    expect(drop.cardUrl).toContain(`share/collections/${drop.id}/card.webp`);
    dropCardUrl = drop.cardUrl;

    // The share link exists from creation: attribution works on post one.
    const link = await prisma.shareLink.findUniqueOrThrow({ where: { code: drop.code } });
    expect(link.collectionId).toBe(drop.id);
    expect(link.listingId).toBeNull();
  }, 60_000);

  it("lists drops with contents and price range", async () => {
    const app = createApp();
    const res = await request(app).get("/api/v1/seller/collections").set(auth());
    expect(res.status).toBe(200);
    const drop = res.body.data.collections.find((c: { id: string }) => c.id === dropId);
    expect(drop).toBeTruthy();
    expect(drop.itemCount).toBe(3);
    expect(drop.listingIds).toEqual(listingIds);
  });

  it("renders the drop card as a 1200x630 webp", async () => {
    const drop = await prisma.collection.findUniqueOrThrow({ where: { id: dropId } });
    expect(drop.cardKey).not.toBeNull();
    // Straight from the bucket: the object is real, not just a key in a row.
    const { GetObjectCommand } = await import("@aws-sdk/client-s3");
    const obj = await s3().send(
      new GetObjectCommand({
        Bucket: process.env.S3_BUCKET ?? "storesnap-media",
        Key: drop.cardKey!,
      }),
    );
    const bytes = Buffer.from(await obj.Body!.transformToByteArray());
    const meta = await sharp(bytes).metadata();
    expect(meta.format).toBe("webp");
    expect(meta.width).toBe(1200);
    expect(meta.height).toBe(630);
  }, 30_000);

  it("serves the drop to buyers by code from any host", async () => {
    const app = createApp();
    const res = await request(app)
      .get(`/api/v1/market/collections/${dropCode}`)
      .set("Host", "localhost");
    expect(res.status).toBe(200);
    expect(res.body.data.state).toBe("live");
    expect(res.body.data.store.slug).toBe(SLUG);
    expect(res.body.data.collection.title).toBe("Friday drop");
    expect(res.body.data.collection.itemCount).toBe(3);
    expect(res.body.data.collection.items[0].code).toBeTruthy();
  });

  it("unfurls the drop for scrapers and redirects humans to the SPA route", async () => {
    const app = createApp();

    const bot = await request(app)
      .get(`/api/v1/p/${dropCode}`)
      .set("Host", "localhost")
      .set("User-Agent", "WhatsApp/2.23.20.0");
    expect(bot.status).toBe(200);
    expect(bot.headers["content-type"]).toContain("text/html");
    expect(bot.text).toContain('og:title" content="Friday drop"');
    expect(bot.text).toContain("3 items - KSh 1,200 - KSh 3,600");
    expect(bot.text).toContain(`share/collections/${dropId}/card.webp?v=`);
    expect(bot.text).toContain(`url=/s/${SLUG}/c/${dropCode}`);

    const human = await request(app).get(`/api/v1/p/${dropCode}`).set("Host", "localhost");
    expect(human.status).toBe(302);
    expect(human.headers.location).toBe(`/s/${SLUG}/c/${dropCode}`);
  });

  it("carries the channel tag through both paths and logs the view", async () => {
    const app = createApp();
    await request(app)
      .get(`/api/v1/p/${dropCode}?r=wa-group2`)
      .set("Host", "localhost")
      .set("User-Agent", "WhatsApp/2.23.20.0");
    const human = await request(app)
      .get(`/api/v1/p/${dropCode}?r=wa-group2`)
      .set("Host", "localhost");
    expect(human.headers.location).toBe(`/s/${SLUG}/c/${dropCode}?r=wa-group2`);

    const link = await prisma.shareLink.findUniqueOrThrow({ where: { code: dropCode } });
    await new Promise((resolve) => setTimeout(resolve, 300));
    const events = await prisma.shareEvent.findMany({ where: { shareLinkId: link.id } });
    expect(events.length).toBeGreaterThanOrEqual(1);
    expect(events.some((e) => e.channel === "wa-group2")).toBe(true);
  });

  it("reorders contents and refreshes the card version without moving the object", async () => {
    const app = createApp();
    const before = await prisma.collection.findUniqueOrThrow({ where: { id: dropId } });

    const bot = (): request.Test =>
      request(app)
        .get(`/api/v1/p/${dropCode}`)
        .set("Host", "localhost")
        .set("User-Agent", "WhatsApp/2.23.20.0");
    const versionOf = async (): Promise<string> => {
      const html = await bot();
      return /\?v=([a-z0-9]+)/.exec(html.text)?.[1] ?? "";
    };
    const versionBefore = await versionOf();
    expect(versionBefore).not.toBe("");

    const reversed = [...listingIds].reverse();
    const res = await request(app)
      .put(`/api/v1/seller/collections/${dropId}/items`)
      .set(auth())
      .send({ listingIds: reversed });
    expect(res.status).toBe(200);
    expect(res.body.data.collection.listingIds).toEqual(reversed);

    const refreshed = await request(app)
      .post(`/api/v1/seller/collections/${dropId}/refresh`)
      .set(auth());
    expect(refreshed.status).toBe(200);
    // Stable object path: the ?v= version is what busts WhatsApp's cache.
    expect(refreshed.body.data.collection.cardUrl).toBe(dropCardUrl);

    const after = await prisma.collection.findUniqueOrThrow({ where: { id: dropId } });
    expect(after.cardKey).toBe(before.cardKey);
    expect(after.ogVersion).not.toBeNull();

    // Every edit moves the version, so the next scrape re-reads the card.
    expect(await versionOf()).not.toBe(versionBefore);
  }, 60_000);

  it("refuses items from another store", async () => {
    const app = createApp();
    // A stranger cannot see or touch this drop.
    const strangerGet = await request(app)
      .get(`/api/v1/seller/collections/${dropId}`)
      .set(auth(strangerToken));
    expect(strangerGet.status).toBe(404);

    const strangerCreate = await request(app)
      .post("/api/v1/seller/collections")
      .set(auth(strangerToken))
      .send({ title: "Stolen drop", listingIds });
    expect(strangerCreate.status).toBe(403);
    expect(strangerCreate.body.error.code).toBe("FORBIDDEN");

    const strangerItems = await request(app)
      .put(`/api/v1/seller/collections/${dropId}/items`)
      .set(auth(strangerToken))
      .send({ listingIds: [] });
    expect(strangerItems.status).toBe(404);
  }, 30_000);

  it("keeps ended drops alive: the link still resolves, as ended", async () => {
    const app = createApp();
    const ended = await request(app)
      .del(`/api/v1/seller/collections/${dropId}`)
      .set(auth());
    expect(ended.status).toBe(200);

    const publicRead = await request(app)
      .get(`/api/v1/market/collections/${dropCode}`)
      .set("Host", "localhost");
    expect(publicRead.status).toBe(200);
    expect(publicRead.body.data.state).toBe("ended");
    // The items are still browsable: no dead group-chat posts.
    expect(publicRead.body.data.collection.itemCount).toBe(3);

    const bot = await request(app)
      .get(`/api/v1/p/${dropCode}`)
      .set("Host", "localhost")
      .set("User-Agent", "WhatsApp/2.23.20.0");
    expect(bot.status).toBe(200);
    expect(bot.text).toContain("This drop has ended");
  });

  it("404s unknown drop codes", async () => {
    const app = createApp();
    const res = await request(app)
      .get("/api/v1/market/collections/zzzzzzzzzz")
      .set("Host", "localhost");
    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe("COLLECTION_NOT_FOUND");
  });
});
