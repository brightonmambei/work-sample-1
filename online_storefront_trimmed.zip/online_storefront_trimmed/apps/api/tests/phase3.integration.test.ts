/**
 * Phase 3 integration tests: transactional checkout, stock guards, price
 * snapshots, buyer tracking, seller inbox transitions, Sale Recorder ledger.
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

process.env.S3_ACCESS_KEY ??= "storesnap";
process.env.S3_SECRET_KEY ??= "storesnap-secret";

const suffix = randomBytes(4).toString("hex");
const EMAIL = `orders-${suffix}@storesnap.test`;

let accessToken = "";
let storeSlug = "";
let listingId = "";

function auth(): Record<string, string> {
  return { Authorization: `Bearer ${accessToken}` };
}

function host(): Record<string, string> {
  return { Host: `${storeSlug}.shops.storesnap.co.ke` };
}

d("orders flow", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Orders Seller", email: EMAIL, password: "Str0ng-pass!" });
    accessToken = reg.body.data.accessToken;
    const store = await request(app)
      .post("/api/v1/seller/store")
      .set(auth())
      .send({ name: "Orders Test Store", slug: `orders-test-${suffix}` });
    storeSlug = store.body.data.store.slug;

    const category = await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } });
    const listing = await request(app)
      .post("/api/v1/seller/products")
      .set(auth())
      .send({
        title: "Merino Roll Neck (test stock)",
        priceKes: 2200,
        compareAtKes: 2800,
        categoryId: category.id,
        condition: "new",
        stock: 2,
        sizes: ["M", "L"],
        publishNow: true,
        media: [],
      });
    expect(listing.status).toBe(201);
    listingId = listing.body.data.listing.id;
  });

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: storeSlug } });
    if (store) {
      await prisma.orderItem.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.hold.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.listing.deleteMany({ where: { storeId: store.id } });
      await prisma.order.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const user = await prisma.user.findUnique({ where: { email: EMAIL } });
    if (user) await prisma.user.delete({ where: { id: user.id } });
    await prisma.$disconnect();
  });

  it("rejects checkout when the request would break stock rules", async () => {
    const app = createApp();
    const bad = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({
        buyerName: "Test Buyer",
        buyerPhone: "0712345678",
        items: [{ listingId, quantity: 5 }],
      });
    expect(bad.status).toBe(409);
    expect(bad.body.error.code).toBe("INSUFFICIENT_STOCK");

    const wrongSize = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({
        buyerName: "Test Buyer",
        buyerPhone: "0712345678",
        items: [{ listingId, quantity: 1, size: "XXL" }],
      });
    expect(wrongSize.status).toBe(422);
  });

  it("runs a full transactional checkout and decrements stock", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({
        buyerName: "Amina Wanji",
        buyerPhone: "0712445566",
        buyerLocation: "Kilimani",
        fulfillment: "pickup",
        paymentMethod: "mpesa",
        items: [{ listingId, quantity: 1, size: "M", color: "Olive" }],
      });
    expect(res.status).toBe(201);
    const token = res.body.data.order.token as string;
    expect(token.length).toBeGreaterThanOrEqual(14);
    expect(res.body.data.order.totalKes).toBe(2200);
    expect(res.body.data.order.items[0].priceKes).toBe(2200);

    const listing = await prisma.listing.findUniqueOrThrow({ where: { id: listingId } });
    expect(listing.stock).toBe(1); // 2 -> 1, transactional decrement

    // Usage ledger got the immutable recorded-sale entry.
    const usage = await prisma.billingUsageEvent.findFirst({
      where: { orderId: res.body.data.order.id },
    });
    expect(usage?.type).toBe("order_recorded");
    expect(usage?.amountKes).toBe(2200);

    // Seller bumps the price afterwards; the snapshot must not move.
    await prisma.listing.update({ where: { id: listingId }, data: { priceKes: 9999 } });
    const tracking = await request(app).get(`/api/v1/market/orders/${token}`);
    expect(tracking.status).toBe(200);
    expect(tracking.body.data.order.items[0].priceKes).toBe(2200);
    await prisma.listing.update({ where: { id: listingId }, data: { priceKes: 2200 } });

    // Unknown tokens never leak.
    const missing = await request(app).get(`/api/v1/market/orders/zzzzzzzzzzzzzzzzzz`);
    expect(missing.status).toBe(404);
  });

  it("prevents overselling the final unit", async () => {
    const app = createApp();
    const okOrder = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({ buyerName: "Buyer 2", buyerPhone: "0722334455", items: [{ listingId, quantity: 1 }] });
    expect(okOrder.status).toBe(201);

    const oversell = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({ buyerName: "Late Buyer", buyerPhone: "0733445566", items: [{ listingId, quantity: 1 }] });
    expect(oversell.status).toBe(409);

    const listing = await prisma.listing.findUniqueOrThrow({ where: { id: listingId } });
    expect(listing.stock).toBe(0);
  });

  it("transitions through the inbox and restores stock on cancel", async () => {
    const app = createApp();
    const list = await request(app).get("/api/v1/seller/orders?status=pending").set(auth());
    expect(list.status).toBe(200);
    const pending = list.body.data.orders as Array<{ id: string }>;
    expect(pending.length).toBe(2);

    const confirm = await request(app)
      .post(`/api/v1/seller/orders/${pending[0]!.id}/transition`)
      .set(auth())
      .send({ status: "confirmed" });
    expect(confirm.status).toBe(200);

    const cancel = await request(app)
      .post(`/api/v1/seller/orders/${pending[0]!.id}/transition`)
      .set(auth())
      .send({ status: "cancelled" });
    expect(cancel.status).toBe(200);

    const listing = await prisma.listing.findUniqueOrThrow({ where: { id: listingId } });
    expect(listing.stock).toBe(1); // cancelled order returned its unit
  });

  it("self-reports a WhatsApp-settled sale into the ledger", async () => {
    const app = createApp();
    const report = await request(app)
      .post("/api/v1/seller/sales/self-report")
      .set(auth())
      .send({
        title: "Jacket sold on WhatsApp",
        amountKes: 1800,
        quantity: 1,
        buyerName: "Settled by M-Pesa",
      });
    expect(report.status).toBe(201);

    const summary = await request(app).get("/api/v1/seller/usage/summary").set(auth());
    expect(summary.status).toBe(200);
    expect(summary.body.data.usage.units).toBe(3); // two checkouts + one book entry
    expect(summary.body.data.usage.recordedKes).toBe(6200);
  });

  it("gates holds to paid tiers", async () => {
    const app = createApp();
    // Grow tier: holds are a Commerce feature.
    const denied = await request(app)
      .post("/api/v1/seller/holds")
      .set(auth())
      .send({ listingId, quantity: 1 });
    expect(denied.status).toBe(402);

    await prisma.store.update({ where: { slug: storeSlug }, data: { plan: "commerce" } });
    const allowed = await request(app)
      .post("/api/v1/seller/holds")
      .set(auth())
      .send({ listingId, quantity: 1 });
    expect(allowed.status).toBe(201);
    expect(new Date(allowed.body.data.hold.expiresAt).getTime()).toBeGreaterThan(Date.now());
    await prisma.store.update({ where: { slug: storeSlug }, data: { plan: "grow" } });
  });
});
