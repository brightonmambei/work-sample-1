/**
 * Media library integration tests: presigned upload into the bucket, the
 * library list (attachment info, filters), hard delete (refused while a live
 * item references the media, allowed once detached, removing DB rows AND
 * bucket objects: original + WebP variants), the orphan GC, and the admin
 * storage console (forbidden for sellers, audit-logged sweep for owners).
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";
import { hashPassword } from "../src/lib/auth.js";
import { getObject } from "../src/lib/objectstore.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

process.env.S3_ACCESS_KEY ??= "storesnap";
process.env.S3_SECRET_KEY ??= "storesnap-secret";

const suffix = randomBytes(4).toString("hex");
const EMAIL = `media-${suffix}@storesnap.test`;
const ADMIN_EMAIL = `media-admin-${suffix}@storesnap.test`;
const ADMIN_PASSWORD = "Str0ng-admin-pass!";
const SLUG = `media-test-${suffix}`;

let sellerToken = "";
let adminToken = "";
let uploadId = "";
let key = "";
let listingId = "";

function sellerAuth(): Record<string, string> {
  return { Authorization: `Bearer ${sellerToken}` };
}

function adminAuth(): Record<string, string> {
  return { Authorization: `Bearer ${adminToken}` };
}

/** Presign via the API, PUT real bytes into the dev bucket, then confirm. */
async function uploadToBucket(
  app: ReturnType<typeof createApp>,
  body: Buffer,
): Promise<{ uploadId: string; key: string }> {
  const presign = await request(app)
    .post("/api/v1/seller/media/presign")
    .set(sellerAuth())
    .send({ mime: "image/jpeg", sizeBytes: body.length });
  expect(presign.status).toBe(201);
  const put = await fetch(presign.body.data.uploadUrl, {
    method: "PUT",
    body: new Uint8Array(body),
    headers: { "Content-Type": "image/jpeg" },
  });
  expect(put.status).toBe(200);
  const confirm = await request(app)
    .post("/api/v1/seller/media/confirm")
    .set(sellerAuth())
    .send({ key: presign.body.data.key, width: 64, height: 64 });
  expect(confirm.status).toBe(200);
  return { uploadId: presign.body.data.uploadId, key: presign.body.data.key };
}

d("media library: ledger + bucket hard delete + gc", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Media Seller", email: EMAIL, password: "Str0ng-pass!" });
    expect(reg.status).toBe(201);
    sellerToken = reg.body.data.accessToken;

    await request(app)
      .post("/api/v1/seller/store")
      .set(sellerAuth())
      .send({ name: "Media Test Store", slug: SLUG });

    await prisma.user.create({
      data: {
        email: ADMIN_EMAIL,
        name: "Media Admin",
        role: "platform_owner",
        status: "active",
        passwordHash: await hashPassword(ADMIN_PASSWORD),
      },
    });
    const login = await request(app)
      .post("/api/v1/auth/login")
      .send({ email: ADMIN_EMAIL, password: ADMIN_PASSWORD });
    adminToken = login.body.data.accessToken;
  });

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: SLUG } });
    if (store) {
      const uploads = await prisma.upload.findMany({
        where: { storeId: store.id },
        select: { id: true, key: true },
      });
      if (uploads.length > 0) {
        const keys = uploads.flatMap((u) => [
          u.key,
          `${u.key.slice(0, u.key.lastIndexOf("."))}.thumb.webp`,
          `${u.key.slice(0, u.key.lastIndexOf("."))}.card.webp`,
          `${u.key.slice(0, u.key.lastIndexOf("."))}.full.webp`,
        ]);
        for (const k of keys) {
          try {
            const { DeleteObjectCommand } = await import("@aws-sdk/client-s3");
            const { objectS3, objectBucket } = await import("../src/lib/objectstore.js");
            await objectS3().send(new DeleteObjectCommand({ Bucket: objectBucket(), Key: k }));
          } catch {
            // cleanup best effort; the tests below already deleted what matters
          }
        }
      }
      await prisma.upload.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const users = await prisma.user.findMany({
      where: { email: { in: [EMAIL, ADMIN_EMAIL] } },
      select: { id: true },
    });
    for (const u of users) {
      await prisma.user.delete({ where: { id: u.id } });
    }
    await prisma.$disconnect();
  });

  it("uploads a real photo to the bucket and lists it as an orphan", async () => {
    const app = createApp();
    // Bytes need not decode; the variant worker is not running under test.
    // What matters is that the sequence below proves them into the bucket.
    const jpeg = Buffer.alloc(768, 0x42);
    const up = await uploadToBucket(app, jpeg);
    uploadId = up.uploadId;
    key = up.key;

    // The bytes must actually exist in the bucket, not only in the ledger.
    const stored = await getObject(key);
    expect(stored.length).toBe(jpeg.length);

    const lib = await request(app)
      .get("/api/v1/seller/media")
      .set(sellerAuth());
    expect(lib.status).toBe(200);
    expect(lib.body.data.items).toHaveLength(1);
    expect(lib.body.data.items[0].id).toBe(uploadId);
    expect(lib.body.data.items[0].attachedTo).toHaveLength(0);
    expect(lib.body.data.summary.totalObjects).toBe(1);
    expect(lib.body.data.summary.orphanCount).toBe(1);

    const orphanOnly = await request(app)
      .get("/api/v1/seller/media?filter=orphan")
      .set(sellerAuth());
    expect(orphanOnly.body.data.items).toHaveLength(1);
  });

  it("attaches the upload to a live item; delete is refused while live", async () => {
    const app = createApp();
    const category = await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } });
    const res = await request(app)
      .post("/api/v1/seller/products")
      .set(sellerAuth())
      .send({
        title: "Denim Jacket",
        priceKes: 2100,
        categoryId: category.id,
        condition: "thrift",
        stock: 1,
        publishNow: true,
        media: [{ uploadId, isHero: true, sortOrder: 0 }],
      });
    expect(res.status).toBe(201);
    listingId = res.body.data.listing.id;

    const lib = await request(app)
      .get("/api/v1/seller/media")
      .set(sellerAuth());
    expect(lib.body.data.items[0].attachedTo).toHaveLength(1);
    expect(lib.body.data.items[0].attachedTo[0].title).toBe("Denim Jacket");

    const del = await request(app)
      .delete(`/api/v1/seller/media/${uploadId}`)
      .set(sellerAuth());
    expect(del.status).toBe(409);
    expect(del.body.error.code).toBe("MEDIA_IN_USE");
    expect(del.body.error.message).toContain("Used by 1 item");

    // fraud guard: another store's seller can neither see nor delete it
    const strangerReg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Stranger", email: `stranger-${suffix}@storesnap.test`, password: "Str0ng-pass!" });
    const strangerAuth = { Authorization: `Bearer ${strangerReg.body.data.accessToken}` };
    await request(app)
      .post("/api/v1/seller/store")
      .set(strangerAuth)
      .send({ name: "Stranger Store", slug: `stranger-${SLUG}` });
    const forbidden = await request(app)
      .delete(`/api/v1/seller/media/${uploadId}`)
      .set(strangerAuth);
    expect(forbidden.status).toBe(404);

    const strangerLib = await request(app)
      .get("/api/v1/seller/media")
      .set(strangerAuth);
    expect(strangerLib.body.data.items).toHaveLength(0);
  });

  it("hard-deletes after the item is archived: bucket objects go too", async () => {
    const app = createApp();
    const archive = await request(app)
      .patch(`/api/v1/seller/products/${listingId}`)
      .set(sellerAuth())
      .send({ archive: true });
    expect(archive.status).toBe(200);

    const del = await request(app)
      .delete(`/api/v1/seller/media/${uploadId}`)
      .set(sellerAuth());
    expect(del.status).toBe(200);

    // Ledger rows are gone...
    expect(await prisma.upload.findUnique({ where: { id: uploadId } })).toBeNull();
    expect(
      await prisma.listingMedia.count({ where: { uploadId } }),
    ).toBe(0);

    // ...and the objects are truly gone from the bucket.
    await expect(getObject(key)).rejects.toThrow();

    const lib = await request(app)
      .get("/api/v1/seller/media")
      .set(sellerAuth());
    expect(lib.body.data.items).toHaveLength(0);
  });

  it("orphan GC sweeps a stale orphan upload: row and objects removed", async () => {
    const app = createApp();
    const jpeg = Buffer.alloc(512, 7);
    const stale = await uploadToBucket(app, jpeg);
    await prisma.upload.update({
      where: { id: stale.uploadId },
      data: { createdAt: new Date(Date.now() - 3 * 86400_000) },
    });

    // Fresh uploads are protected by the 24h guard: nothing else exists, so
    // sweep deletes exactly the backdated one.
    const gc = await request(app)
      .post("/api/v1/seller/media/gc")
      .set(sellerAuth());
    expect(gc.status).toBe(200);
    expect(gc.body.data.deletedUploads).toBe(1);
    expect(gc.body.data.deletedObjects).toBeGreaterThanOrEqual(1);
    expect(await prisma.upload.findUnique({ where: { id: stale.uploadId } })).toBeNull();
    await expect(getObject(stale.key)).rejects.toThrow();
  });

  it("lists the raw bucket prefix for the store (read-only inventory)", async () => {
    const app = createApp();
    const res = await request(app)
      .get("/api/v1/seller/media/bucket")
      .set(sellerAuth());
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data.objects)).toBe(true);
    expect(res.body.data.bucket).toBe(process.env.S3_BUCKET ?? "storesnap-media");
  });

  it("serves derived renditions anonymously through /media (proxy route)", async () => {
    const app = createApp();
    // A real object at a derived-variant key, written directly so the test
    // does not depend on the worker running.
    const jpeg = Buffer.alloc(256, 3);
    const created = await uploadToBucket(app, jpeg);
    const originalBase = created.key.slice(0, created.key.lastIndexOf("."));
    const thumb = `${originalBase}.thumb.webp`;
    const { putObject } = await import("../src/lib/objectstore.js");
    await putObject(thumb, jpeg, "image/webp");

    // No Authorization header: buyers and scraper user agents must be able to
    // fetch images (this is what makes og:image unfurls work).
    const served = await request(app).get(`/api/v1/media/${thumb}`);
    expect(served.status).toBe(200);
    expect(served.headers["content-type"]).toContain("image/webp");
    expect(served.headers["cache-control"]).toContain("immutable");
    expect(Number(served.headers["content-length"])).toBe(jpeg.length);

    // Raw originals and non-media keys are never proxied.
    const original = await request(app).get(`/api/v1/media/${created.key}`);
    expect(original.status).toBe(404);
    const traversal = await request(app).get("/api/v1/media/../../etc/passwd.thumb.webp");
    expect([400, 404]).toContain(traversal.status);
    const missing = await request(app).get(
      `/api/v1/media/${originalBase}.card.webp`,
    );
    expect(missing.status).toBe(404);
  });

  it("admin storage console: forbidden for sellers, live for the owner", async () => {
    const app = createApp();
    const denied = await request(app)
      .get("/api/v1/admin/storage")
      .set(sellerAuth());
    expect(denied.status).toBe(403);

    const overview = await request(app)
      .get("/api/v1/admin/storage")
      .set(adminAuth());
    expect(overview.status).toBe(200);
    expect(overview.body.data.ledger).toHaveProperty("uploads");
    expect(overview.body.data.bucketLive).toHaveProperty("objectCount");
    expect(Array.isArray(overview.body.data.stores)).toBe(true);

    const sweep = await request(app)
      .post("/api/v1/admin/storage/gc")
      .set(adminAuth());
    expect(sweep.status).toBe(200);

    // Every admin action lands in the audit log (invariant 9).
    const audit = await request(app)
      .get("/api/v1/admin/audit")
      .set(adminAuth());
    const actions = audit.body.data.entries.map((e: { action: string }) => e.action);
    expect(actions).toContain("media.gc");
  });
});
