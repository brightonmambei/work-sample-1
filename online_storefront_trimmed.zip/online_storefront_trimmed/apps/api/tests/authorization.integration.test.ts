/**
 * Authorization guard tests. The admin console surface is enumerated FROM
 * SOURCE (apps/api/src/modules/admin/routes.ts) so a newly added admin route
 * that forgets the platform_owner guard fails this suite instead of shipping.
 *
 * Every admin route must be 401 for anonymous callers and 403 for a plain
 * seller. Cross-tenant seller isolation is asserted separately in
 * mediamgmt.integration.test.ts (stranger store) and here for listings.
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";
import { signAccessToken } from "../src/lib/auth.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

const here = dirname(fileURLToPath(import.meta.url));
const suffix = randomBytes(4).toString("hex");
const EMAIL = `guard-${suffix}@storesnap.test`;
const SLUG = `guard-test-${suffix}`;

let sellerToken = "";
let listingId = "";
let categoryId = "";

/** Parse the admin router source for method + path pairs. */
function adminRoutes(): Array<{ method: string; path: string }> {
  const src = readFileSync(join(here, "../src/modules/admin/routes.ts"), "utf8");
  const re = /adminRouter\.(get|post|put|patch|delete)\(\s*"([^"]+)"/g;
  const out: Array<{ method: string; path: string }> = [];
  for (const m of src.matchAll(re)) {
    const method = m[1];
    const path = m[2];
    if (method !== undefined && path !== undefined) out.push({ method: method.toUpperCase(), path });
  }
  return out;
}

const concrete = (path: string): string =>
  path.replace(":id", "cmfake00000000000000000").replace(":key", "placeholder");

d("authorization guards", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Guard Seller", email: EMAIL, password: "Str0ng-pass!" });
    expect(reg.status).toBe(201);
    expect(reg.body.data.user.role).toBe("seller");
    sellerToken = reg.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set({ Authorization: `Bearer ${sellerToken}` })
      .send({ name: "Guard Test Store", slug: SLUG });
    categoryId = (await prisma.category.findFirstOrThrow({ where: { slug: "clothes" } })).id;
    const listing = await request(app)
      .post("/api/v1/seller/products")
      .set({ Authorization: `Bearer ${sellerToken}` })
      .send({
        title: "Guarded Item",
        priceKes: 900,
        categoryId,
        condition: "new",
        stock: 1,
        publishNow: true,
        media: [],
      });
    listingId = listing.body.data.listing.id;
  }, 90_000);

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: SLUG } });
    if (store) {
      // Store delete cascades listings and their listing_media rows.
      await prisma.listing.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const user = await prisma.user.findUnique({ where: { email: EMAIL } });
    if (user) await prisma.user.delete({ where: { id: user.id } });
    await prisma.$disconnect();
  });

  it("discovers the admin surface from source (sanity)", () => {
    const routes = adminRoutes();
    expect(routes.length).toBeGreaterThanOrEqual(16);
    expect(routes.some((r) => r.path === "/overview")).toBe(true);
  });

  it("401s every admin route for anonymous callers", async () => {
    const app = createApp();
    const offenders: string[] = [];
    for (const { method, path } of adminRoutes()) {
      const res = await request(app)
        [method.toLowerCase() as "get"](`/api/v1/admin${concrete(path)}`)
        .send({});
      if (res.status !== 401) offenders.push(`${method} ${path} -> ${res.status}`);
    }
    expect(offenders).toEqual([]);
  }, 60_000);

  it("403s every admin route for a plain seller", async () => {
    const app = createApp();
    const offenders: string[] = [];
    for (const { method, path } of adminRoutes()) {
      const req = request(app)
        [method.toLowerCase() as "get"](`/api/v1/admin${concrete(path)}`)
        .set({ Authorization: `Bearer ${sellerToken}` });
      const res = method === "GET" ? await req : await req.send({});
      if (res.status !== 403) offenders.push(`${method} ${path} -> ${res.status}`);
    }
    expect(offenders).toEqual([]);
  }, 60_000);

  it("rejects a tampered access token (role escalation attempt)", async () => {
    const app = createApp();
    const seller = await prisma.user.findUniqueOrThrow({ where: { email: EMAIL } });
    // A seller takes their own real token and rewrites the payload to claim
    // platform_owner, keeping the original signature: must be rejected.
    const original = signAccessToken({ id: seller.id, role: "seller" });
    const [header, , signature] = original.split(".");
    const forgedPayload = Buffer.from(
      JSON.stringify({ sub: seller.id, role: "platform_owner", iat: 0 }),
    ).toString("base64url");
    const forged = `${header}.${forgedPayload}.${signature}`;
    const res = await request(app)
      .get("/api/v1/admin/overview")
      .set({ Authorization: `Bearer ${forged}` });
    expect(res.status).toBe(401);
  });

  it("keeps sellers inside their own tenant", async () => {
    // A second seller cannot read or mutate the first seller's listing.
    const app = createApp();
    const otherEmail = `guard-other-${suffix}@storesnap.test`;
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Other Seller", email: otherEmail, password: "Str0ng-pass!" });
    const otherToken = reg.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set({ Authorization: `Bearer ${otherToken}` })
      .send({ name: "Other Store", slug: `guard-other-${suffix}` });

    const read = await request(app)
      .get(`/api/v1/seller/products/${listingId}`)
      .set({ Authorization: `Bearer ${otherToken}` });
    expect([403, 404]).toContain(read.status);

    const write = await request(app)
      .patch(`/api/v1/seller/products/${listingId}`)
      .set({ Authorization: `Bearer ${otherToken}` })
      .send({ priceKes: 1 });
    expect([403, 404]).toContain(write.status);

    const untouched = await prisma.listing.findUniqueOrThrow({ where: { id: listingId } });
    expect(untouched.priceKes).toBe(900);

    await prisma.store.deleteMany({ where: { slug: `guard-other-${suffix}` } });
    const other = await prisma.user.findUnique({ where: { email: otherEmail } });
    if (other) await prisma.user.delete({ where: { id: other.id } });
  }, 90_000);
});
