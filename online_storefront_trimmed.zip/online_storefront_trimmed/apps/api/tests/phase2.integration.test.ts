/**
 * Phase 2 integration tests: catalog, media upload contract, public listing
 * routes, share links. Real Postgres (+ only signed URL generation touched):
 * run with the dev stack up:
 *   RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

const suffix = randomBytes(4).toString("hex");
const EMAIL = `catalog-${suffix}@storesnap.test`;

let accessToken = "";
let storeSlug = "";

async function authHeader(): Promise<Record<string, string>> {
  return { Authorization: `Bearer ${accessToken}` };
}
d("catalog flow", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
  });

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: storeSlug } });
    if (store) {
      // Listing media cascades with listings; then uploads are safe to clear.
      await prisma.listingMedia.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.upload.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const user = await prisma.user.findUnique({ where: { email: EMAIL } });
    if (user) await prisma.user.delete({ where: { id: user.id } });
    const strangerStore = await prisma.store.findUnique({
      where: { slug: `share-stranger-${suffix}` },
    });
    if (strangerStore) await prisma.store.delete({ where: { id: strangerStore.id } });
    await prisma.user.deleteMany({
      where: { email: `share-stranger-${suffix}@storesnap.test` },
    });
    await prisma.$disconnect();
  });

  it("seeds the taxonomy", async () => {
    const app = createApp();
    const res = await request(app).get("/api/v1/market/categories");
    expect(res.status).toBe(200);
    expect(res.body.data.categories.length).toBeGreaterThan(5);
    const slugs = res.body.data.categories.map((c: { slug: string }) => c.slug);
    expect(slugs).toContain("sneakers");
  });

  it("registers, creates a store, and lists categories", async () => {
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Catalog Seller", email: EMAIL, password: "Str0ng-pass!" });
    expect(reg.status).toBe(201);
    accessToken = reg.body.data.accessToken;

    const store = await request(app)
      .post("/api/v1/seller/store")
      .set(await authHeader())
      .send({ name: "Catalog Test Store", slug: `catalog-test-${suffix}` });
    expect(store.status).toBe(201);
    storeSlug = store.body.data.store.slug;
  });

  it("presigns an upload and confirms it", async () => {
    const app = createApp();
    const presign = await request(app)
      .post("/api/v1/seller/media/presign")
      .set(await authHeader())
      .send({ mime: "image/jpeg", sizeBytes: 120_000 });
    expect(presign.status).toBe(201);
    expect(presign.body.data.uploadUrl).toContain("uploads/");
    expect(presign.body.data.uploadUrl).toContain("X-Amz-Signature");

    const confirm = await request(app)
      .post("/api/v1/seller/media/confirm")
      .set(await authHeader())
      .send({ key: presign.body.data.key, width: 1200, height: 1600 });
    expect(confirm.status).toBe(200);

    // Keep the upload for the create listing test.
    uploadSeed = presign.body.data;
  });

  let uploadSeed: { uploadId: string; key: string };

  it("rejects unsupported media types", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/v1/seller/media/presign")
      .set(await authHeader())
      .send({ mime: "application/pdf", sizeBytes: 100 });
    expect(res.status).toBe(422);
  });

  it("creates a listing with media and publishes it", async () => {
    const app = createApp();
    const category = await prisma.category.findUniqueOrThrow({
      where: { slug: "sneakers" },
    });

    const res = await request(app)
      .post("/api/v1/seller/products")
      .set(await authHeader())
      .send({
        title: "Court Sneaker, thrift grade A",
        priceKes: 3200,
        compareAtKes: 4000,
        categoryId: category.id,
        condition: "thrift",
        conditionGrade: 4,
        stock: 2,
        sizes: ["42", "43"],
        colors: ["Bone"],
        publishNow: true,
        media: [{ uploadId: uploadSeed.uploadId, sortOrder: 0, isHero: true }],
      });
    expect(res.status).toBe(201);
    expect(res.body.data.listing.code).toHaveLength(10);

    createdListing = res.body.data.listing;
  });

  let createdListing: { id: string; code: string };

  it("surfaces the listing on the public catalog", async () => {
    const app = createApp();
    const res = await request(app)
      .get("/api/v1/market/products")
      .set("Host", `${storeSlug}.shops.storesnap.co.ke`);
    expect(res.status).toBe(200);
    const items = res.body.data.items as Array<{ code: string; media: unknown[] }>;
    expect(items.some((i) => i.code === createdListing.code)).toBe(true);
  });

  it("hides drafts from buyers but shows them to the seller", async () => {
    const app = createApp();
    const draft = await request(app)
      .post("/api/v1/seller/products")
      .set(await authHeader())
      .send({
        title: "Draft only jacket",
        priceKes: 1500,
        categoryId: (await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } })).id,
        condition: "thrift",
        stock: 1,
        publishNow: false,
        media: [],
      });
    expect(draft.status).toBe(201);

    const publicRes = await request(app)
      .get("/api/v1/market/products")
      .set("Host", `${storeSlug}.shops.storesnap.co.ke`);
    const codes = (publicRes.body.data.items as Array<{ code: string }>).map((i) => i.code);
    expect(codes).not.toContain(draft.body.data.listing.code);

    const sellerRes = await request(app)
      .get("/api/v1/seller/products")
      .set(await authHeader());
    expect(
      (sellerRes.body.data.items as Array<{ id: string }>).some(
        (i) => i.id === draft.body.data.listing.id,
      ),
    ).toBe(true);
  });

  it("creates the share link and serves OG HTML to bots", async () => {
    const app = createApp();
    const link = await request(app)
      .get(`/api/v1/seller/share/links/${createdListing.id}`)
      .set(await authHeader());
    expect(link.status).toBe(200);
    // The copied link must be the bot-unfurl route: /p/{code}, never the SPA
    // path (scrapers do not run JS, so /s/{slug}/p/{code} unfurls bare).
    expect(new URL(link.body.data.shareUrl as string).pathname).toBe(
      `/p/${createdListing.code.toLowerCase()}`,
    );

    const share = await request(app)
      .get(`/api/v1/p/${createdListing.code}`)
      .set(
        "User-Agent",
        "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 WhatsApp/2.23.20.0",
      );
    expect(share.status).toBe(200);
    expect(share.headers["content-type"]).toContain("text/html");
    expect(share.text).toContain("og:title");
    expect(share.text).toContain("Court Sneaker");
    expect(share.text).toContain("3,200");

    // The unfurl card is versioned so WhatsApp cannot pin a stale preview.
    expect(share.text).toMatch(/og:image" content="[^"]+\?v=[a-z0-9]+"/);

    // Humans are redirected into the SPA route.
    const human = await request(app)
      .get(`/api/v1/p/${createdListing.code}`)
      .set("User-Agent", "Mozilla/5.0 (Windows NT 10.0) Safari/605 Chrome/120");
    expect(human.status).toBe(302);
  });

  it("composes a ready-to-paste caption with the canonical link", async () => {
    const app = createApp();
    const link = await request(app)
      .get(`/api/v1/seller/share/links/${createdListing.id}`)
      .set(await authHeader());
    expect(link.status).toBe(200);
    const caption = link.body.data.caption as string;
    expect(caption).toContain("Court Sneaker");
    expect(caption).toContain("KSh 3,200");
    // The fixture item is a graded thrift find with two left in stock, so the
    // caption carries the grade, the old price and the scarcity line.
    expect(caption).toContain("Thrift, grade 4/5");
    expect(caption).toContain("(was KSh 4,000)");
    expect(caption).toContain("Only 2 left");
    expect(caption).toContain(`Order: ${link.body.data.shareUrl}`);
    // Group-chat text only: no emojis, no em-dashes.
    expect(caption).not.toMatch(/[\u{1F300}-\u{1FAFF}\u{2014}]/u);
  });

  it("refreshes the unfurl version on demand", async () => {
    const app = createApp();
    const botHeaders = {
      "User-Agent": "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 WhatsApp/2.23.20.0",
    };
    const imageOf = async (): Promise<string> => {
      const res = await request(app).get(`/api/v1/p/${createdListing.code}`).set(botHeaders);
      const match = /og:image" content="([^"]+)"/.exec(res.text);
      expect(match).not.toBeNull();
      return match![1]!;
    };

    const before = await imageOf();

    // Someone else's item cannot be refreshed: the guard resolves the store
    // from the listing and compares it with the caller. The stranger needs a
    // store of their own first, otherwise the store guard answers 404.
    const strangerEmail = `share-stranger-${suffix}@storesnap.test`;
    const stranger = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Share Stranger", email: strangerEmail, password: "Str0ng-pass!" });
    expect(stranger.status).toBe(201);
    const strangerToken = stranger.body.data.accessToken as string;
    const strangerStore = await request(app)
      .post("/api/v1/seller/store")
      .set({ Authorization: `Bearer ${strangerToken}` })
      .send({ name: "Stranger Store", slug: `share-stranger-${suffix}` });
    expect(strangerStore.status).toBe(201);

    const denied = await request(app)
      .post("/api/v1/seller/share/refresh")
      .set({ Authorization: `Bearer ${strangerToken}` })
      .send({ listingId: createdListing.id });
    expect(denied.status).toBe(403);
    expect(denied.body.error.code).toBe("FORBIDDEN");

    // The stranger cannot read someone else's caption either.
    const deniedLinks = await request(app)
      .get(`/api/v1/seller/share/links/${createdListing.id}`)
      .set({ Authorization: `Bearer ${strangerToken}` });
    expect(deniedLinks.status).toBe(403);

    // An unknown item is a 404, never a 500.
    const missing = await request(app)
      .post("/api/v1/seller/share/refresh")
      .set(await authHeader())
      .send({ listingId: "does-not-exist" });
    expect(missing.status).toBe(404);

    const refreshed = await request(app)
      .post("/api/v1/seller/share/refresh")
      .set(await authHeader())
      .send({ listingId: createdListing.id });
    expect(refreshed.status).toBe(200);

    const after = await imageOf();
    expect(after).not.toBe(before);
    expect(new URL(after).pathname).toBe(new URL(before).pathname);
  });

  it("enforces the Grow plan 25-live-item quota", async () => {
    const app = createApp();
    const category = await prisma.category.findUniqueOrThrow({
      where: { slug: "thrift-clothes" },
    });
    const existing = await prisma.listing.count({
      where: { storeId: (await prisma.store.findUniqueOrThrow({ where: { slug: storeSlug } })).id, status: { in: ["active", "paused", "sold_out"] } },
    });

    let last = 0;
    for (let i = existing; i < 25; i += 1) {
      const res = await request(app)
        .post("/api/v1/seller/products")
        .set(await authHeader())
        .send({
          title: `Quota filler ${i}`,
          priceKes: 100,
          categoryId: category.id,
          condition: "thrift",
          stock: 1,
          publishNow: true,
          media: [],
        });
      last = res.status;
      expect(res.status).toBe(201);
    }

    const blocked = await request(app)
      .post("/api/v1/seller/products")
      .set(await authHeader())
      .send({
        title: "Quota breaker",
        priceKes: 100,
        categoryId: category.id,
        condition: "thrift",
        stock: 1,
        publishNow: true,
        media: [],
      });
    expect(last).toBe(201);
    expect(blocked.status).toBe(402);
    expect(blocked.body.error.code).toBe("QUOTA_REACHED");
  });
});
