/**
 * Theme editor (Phase 5): draft, preview, atomic publish, rollback.
 *
 * The contract being locked in: the public storefront NEVER renders a draft,
 * a draft preview only ever serves a theme to the store's own owner, and
 * publish/restore move whole validated theme specs atomically.
 *
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import { createApp } from "../src/app.js";
import { prisma } from "../src/lib/prisma.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

const suffix = randomBytes(4).toString("hex");
const EMAIL = `theme-${suffix}@storesnap.test`;
const STRANGER_EMAIL = `theme-stranger-${suffix}@storesnap.test`;
const SLUG = `theme-test-${suffix}`;

let token = "";
let strangerToken = "";

const draftSpec = {
  schemaVersion: 1 as const,
  preset: "pro-dark" as const,
  overrides: {
    palette: { accent: "#0f7a3d", accentHover: "#0b5c2d", accentSoft: "rgba(15, 122, 61, 0.1)" },
    font: "clean" as const,
    radius: "sharp" as const,
    density: "tight" as const,
  },
};

async function publicTheme(app: ReturnType<typeof createApp>, query = "") {
  const res = await request(app).get(
    `/api/v1/market/current-store?storeSlug=${SLUG}${query}`,
  );
  expect(res.status).toBe(200);
  return res.body.data as {
    store: { theme: { preset: string; overrides: { palette?: { accent?: string } } } };
    previewingDraft: boolean;
  };
}

d("theme editor: draft, preview, publish, rollback", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Theme Seller", email: EMAIL, password: "Str0ng-pass!" });
    expect(reg.status).toBe(201);
    token = reg.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set({ Authorization: `Bearer ${token}` })
      .send({ name: "Theme Test Store", slug: SLUG, themePreset: "pro-light" });

    const stranger = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "Theme Stranger", email: STRANGER_EMAIL, password: "Str0ng-pass!" });
    strangerToken = stranger.body.data.accessToken;
  }, 90_000);

  afterAll(async () => {
    const store = await prisma.store.findUnique({ where: { slug: SLUG } });
    if (store) {
      await prisma.listing.deleteMany({ where: { storeId: store.id } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const users = await prisma.user.findMany({
      where: { email: { in: [EMAIL, STRANGER_EMAIL] } },
      select: { id: true },
    });
    for (const u of users) await prisma.user.delete({ where: { id: u.id } }).catch(() => undefined);
    await prisma.$disconnect();
  });

  it("starts with no draft and no history", async () => {
    const app = createApp();
    const res = await request(app)
      .get("/api/v1/seller/store")
      .set({ Authorization: `Bearer ${token}` });
    expect(res.status).toBe(200);
    expect(res.body.data.store.theme.preset).toBe("pro-light");
    expect(res.body.data.store.themeDraft).toBeNull();
    expect(res.body.data.store.themePrevious).toBeNull();
  });

  it("keeps the storefront on the published theme while drafting", async () => {
    const app = createApp();
    const saved = await request(app)
      .patch("/api/v1/seller/store/theme")
      .set({ Authorization: `Bearer ${token}` })
      .send(draftSpec);
    expect(saved.status).toBe(200);
    expect(saved.body.data.store.themeDraft.preset).toBe("pro-dark");
    // Published theme untouched.
    expect(saved.body.data.store.theme.preset).toBe("pro-light");
    expect(saved.body.data.store.theme.overrides.palette).toBeUndefined();

    const live = await publicTheme(app);
    expect(live.previewingDraft).toBe(false);
    expect(live.store.theme.preset).toBe("pro-light");
    // No palette overrides published yet: the look comes from the preset.
    expect(live.store.theme.overrides.palette).toBeUndefined();
  });

  it("serves the draft only to the owner, and only when asked", async () => {
    const app = createApp();
    // Anonymous preview request: silently gets the published theme.
    const anon = await publicTheme(app, "&preview=draft");
    expect(anon.previewingDraft).toBe(false);
    expect(anon.store.theme.preset).toBe("pro-light");

    // A different seller cannot see someone else's draft either.
    const stranger = await request(app)
      .get(`/api/v1/market/current-store?storeSlug=${SLUG}&preview=draft`)
      .set({ Authorization: `Bearer ${strangerToken}` });
    expect(stranger.status).toBe(200);
    expect(stranger.body.data.previewingDraft).toBe(false);
    expect(stranger.body.data.store.theme.preset).toBe("pro-light");

    // The owner does.
    const owner = await request(app)
      .get(`/api/v1/market/current-store?storeSlug=${SLUG}&preview=draft`)
      .set({ Authorization: `Bearer ${token}` });
    expect(owner.status).toBe(200);
    expect(owner.body.data.previewingDraft).toBe(true);
    expect(owner.body.data.store.theme.preset).toBe("pro-dark");
    expect(owner.body.data.store.theme.overrides.palette.accent).toBe("#0f7a3d");
  });

  it("publishes atomically and keeps the previous theme for rollback", async () => {
    const app = createApp();
    const published = await request(app)
      .post("/api/v1/seller/store/theme/publish")
      .set({ Authorization: `Bearer ${token}` });
    expect(published.status).toBe(200);
    const store = published.body.data.store;
    expect(store.theme.preset).toBe("pro-dark");
    expect(store.theme.overrides.font).toBe("clean");
    expect(store.themeDraft).toBeNull();
    expect(store.themePrevious.preset).toBe("pro-light");

    const live = await publicTheme(app);
    expect(live.store.theme.preset).toBe("pro-dark");
    expect(live.store.theme.overrides.palette?.accent).toBe("#0f7a3d");

    // Nothing left to publish.
    const again = await request(app)
      .post("/api/v1/seller/store/theme/publish")
      .set({ Authorization: `Bearer ${token}` });
    expect(again.status).toBe(409);
    expect(again.body.error.code).toBe("NO_THEME_DRAFT");
  });

  it("rolls back to the previous theme in one step", async () => {
    const app = createApp();
    const restored = await request(app)
      .post("/api/v1/seller/store/theme/restore")
      .set({ Authorization: `Bearer ${token}` });
    expect(restored.status).toBe(200);
    expect(restored.body.data.store.theme.preset).toBe("pro-light");
    // Swapped, so pressing restore again returns to the other theme.
    expect(restored.body.data.store.themePrevious.preset).toBe("pro-dark");

    const live = await publicTheme(app);
    expect(live.store.theme.preset).toBe("pro-light");

    const back = await request(app)
      .post("/api/v1/seller/store/theme/restore")
      .set({ Authorization: `Bearer ${token}` });
    expect(back.body.data.store.theme.preset).toBe("pro-dark");
  });

  it("discards a draft without touching the published theme", async () => {
    const app = createApp();
    await request(app)
      .patch("/api/v1/seller/store/theme")
      .set({ Authorization: `Bearer ${token}` })
      .send({ ...draftSpec, preset: "pro-light" });
    const discarded = await request(app)
      .post("/api/v1/seller/store/theme/discard")
      .set({ Authorization: `Bearer ${token}` });
    expect(discarded.status).toBe(200);
    expect(discarded.body.data.store.themeDraft).toBeNull();
    expect(discarded.body.data.store.theme.preset).toBe("pro-dark");
  });

  it("rejects malformed themes instead of storing junk", async () => {
    const app = createApp();
    const res = await request(app)
      .patch("/api/v1/seller/store/theme")
      .set({ Authorization: `Bearer ${token}` })
      .send({ schemaVersion: 1, preset: "pro-light", overrides: { font: "comic-sans" } });
    expect(res.status).toBe(422);
  });

  it("requires ownership for every theme write", async () => {
    const app = createApp();
    const anon = await request(app).patch("/api/v1/seller/store/theme").send(draftSpec);
    expect(anon.status).toBe(401);
    // A stranger has no store of their own to save into here, and cannot
    // publish someone else's draft: the store is resolved from the caller.
    const strangerPublish = await request(app)
      .post("/api/v1/seller/store/theme/publish")
      .set({ Authorization: `Bearer ${strangerToken}` });
    expect(strangerPublish.status).toBe(404);
  });
});
