/**
 * Theme rendering contract (no database needed): the injected CSS must carry
 * the non-color tokens the storefront actually reads, and the editor's scoped
 * preview must render the same token block under a different selector.
 */
import { describe, expect, it } from "vitest";
import {
  defaultThemeSpec,
  resolveThemeTokens,
  themeFonts,
  themeRadii,
  themeToCss,
  type ThemeSpec,
} from "@storesnap/shared";

const themed: ThemeSpec = {
  schemaVersion: 1,
  preset: "pro-dark",
  overrides: {
    palette: { accent: "#0f7a3d" },
    font: "clean",
    radius: "sharp",
    density: "tight",
  },
};

describe("theme CSS injection", () => {
  it("emits palette overrides on top of the preset", () => {
    const css = themeToCss(themed);
    expect(css).toContain("--st-accent: #0f7a3d;");
    expect(css).toContain("--st-bg: #0B0E14;");
  });

  it("emits font, radius and density tokens, not just colors", () => {
    const css = themeToCss(themed);
    expect(css).toContain(`--st-font-sans: ${themeFonts.clean.sans};`);
    expect(css).toContain(`--st-font-display: ${themeFonts.clean.display};`);
    expect(css).toContain(`--st-radius: ${themeRadii.sharp.radius};`);
    expect(css).toContain("--st-card-gap: 8px;");
  });

  it("falls back to preset defaults when nothing is overridden", () => {
    const css = themeToCss(defaultThemeSpec);
    expect(css).toContain(`--st-font-display: ${themeFonts.editorial.display};`);
    expect(css).toContain(`--st-radius: ${themeRadii.soft.radius};`);
    expect(css).toContain("--st-card-gap: 14px;");
  });

  it("can scope the same block to a preview container", () => {
    const css = themeToCss(themed, "#theme-preview");
    expect(css.startsWith("#theme-preview {")).toBe(true);
  });

  it("resolves tokens with the override winning", () => {
    expect(resolveThemeTokens(themed).accent).toBe("#0f7a3d");
    expect(resolveThemeTokens(themed).surface).toBe("#12161F");
  });
});
