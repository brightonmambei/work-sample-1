/**
 * Phase 5 integration tests: item deep-link resolution /p/:code from any
 * host, ?storeSlug public browsing, the SPA checkout contract (checkout by
 * share code, not raw id), and the 9:16 status poster render+upload.
 * RUN_DB_TESTS=1 pnpm --filter @storesnap/api test
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { randomBytes } from "node:crypto";
import sharp from "sharp";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import { S3Client } from "@aws-sdk/client-s3";
import { prisma } from "../src/lib/prisma.js";
import { createApp } from "../src/app.js";
import { taxonomyService } from "../src/modules/catalog/taxonomy.js";

const RUN_DB = process.env.RUN_DB_TESTS === "1";
const d = RUN_DB ? describe : describe.skip;

process.env.S3_ACCESS_KEY ??= "storesnap";
process.env.S3_SECRET_KEY ??= "storesnap-secret";

const suffix = randomBytes(4).toString("hex");
const EMAIL = `p5-${suffix}@storesnap.test`;
const SLUG = `p5-test-${suffix}`;

let accessToken = "";
let listingA = ""; // live: checkout by code + sold-state flip + poster hero
let codeA = "";
let posterKey = "";

function auth(): Record<string, string> {
  return { Authorization: `Bearer ${accessToken}` };
}

function host(): Record<string, string> {
  return { Host: `${SLUG}.shops.storesnap.co.ke` };
}

function plainHost(): Record<string, string> {
  // Platform host (dev localhost), i.e. no tenant routing at all.
  return { Host: "localhost" };
}

function s3(): S3Client {
  return new S3Client({
    region: process.env.S3_REGION ?? "us-east-1",
    endpoint: process.env.S3_ENDPOINT,
    forcePathStyle: true,
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY!,
      secretAccessKey: process.env.S3_SECRET_KEY!,
    },
  });
}

d("phase 5: item deep link, store browsing, poster", () => {
  beforeAll(async () => {
    await taxonomyService.seedDefaults();
    const app = createApp();
    const reg = await request(app)
      .post("/api/v1/auth/register")
      .send({ name: "P5 Seller", email: EMAIL, password: "Str0ng-pass!" });
    accessToken = reg.body.data.accessToken;
    await request(app)
      .post("/api/v1/seller/store")
      .set(auth())
      .send({ name: "P5 Deep Link Store", slug: SLUG, whatsappNumber: "+254712345678" });
  });

  afterAll(async () => {
    // Delete in FK-dependency order; usage ledger rows too (this suite owns
    // every order it created).
    const store = await prisma.store.findUnique({ where: { slug: SLUG } });
    if (store) {
      await prisma.shareEvent.deleteMany({
        where: { shareLink: { listing: { storeId: store.id } } },
      });
      await prisma.shareLink.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.billingUsageEvent.deleteMany({ where: { storeId: store.id } });
      await prisma.orderItem.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.hold.deleteMany({ where: { listing: { storeId: store.id } } });
      await prisma.listing.deleteMany({ where: { storeId: store.id } });
      await prisma.order.deleteMany({ where: { storeId: store.id } });
      await prisma.upload.deleteMany({ where: { id: { startsWith: "up" + suffix } } });
      await prisma.store.delete({ where: { id: store.id } });
    }
    const user = await prisma.user.findUnique({ where: { email: EMAIL } });
    if (user) await prisma.user.delete({ where: { id: user.id } });
    await prisma.$disconnect();
  });

  it("creates a live listing without media", async () => {
    const app = createApp();
    const category = await prisma.category.findUniqueOrThrow({ where: { slug: "clothes" } });
    const res = await request(app)
      .post("/api/v1/seller/products")
      .set(auth())
      .send({
        title: "Linen Slip Dress",
        priceKes: 3400,
        compareAtKes: 4200,
        categoryId: category.id,
        condition: "new",
        stock: 3,
        publishNow: true,
        media: [],
      });
    expect(res.status).toBe(201);
    listingA = res.body.data.listing.id;
    codeA = res.body.data.listing.code;
  });

  it("checks out by share code, exactly what the storefront sends", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({
        buyerName: "Code Buyer",
        buyerPhone: "0712345678",
        fulfillment: "pickup",
        items: [{ listingId: codeA.toLowerCase(), quantity: 1 }],
      });
    expect(res.status).toBe(201);
    expect(res.body.data.order.totalKes).toBe(3400);
    expect(res.body.data.order.items[0].priceKes).toBe(3400);
  });

  it("still checks out by raw listing id (older clients)", async () => {
    const app = createApp();
    const res = await request(app)
      .post("/api/v1/market/orders")
      .set(host())
      .send({
        buyerName: "Id Buyer",
        buyerPhone: "0712345678",
        items: [{ listingId: listingA, quantity: 1 }],
      });
    expect(res.status).toBe(201);
    // stock 3 -> 2 (code checkout) -> 1 (id checkout), both paths decrement.
    const row = await prisma.listing.findUniqueOrThrow({ where: { id: listingA } });
    expect(row.stock).toBe(1);
  });

  it("resolves the item page data from the share code on any host", async () => {
    const app = createApp();
    // Platform host (no tenant routing): still resolves, globally by code.
    const res = await request(app)
      .get(`/api/v1/market/p/${codeA.toLowerCase()}`)
      .set(plainHost());
    expect(res.status).toBe(200);
    expect(res.body.data.state).toBe("live");
    expect(res.body.data.store.slug).toBe(SLUG);
    expect(res.body.data.store.whatsappNumber).toBe("+254712345678");
    expect(res.body.data.listing.title).toBe("Linen Slip Dress");
    expect(res.body.data.listing.priceKes).toBe(3400);
    // Every checkout-by-code + id left exactly one item; state stays live.
  });

  it("keeps sold links alive: sold state + storefront pointer", async () => {
    const app = createApp();
    await prisma.listing.update({
      where: { id: listingA },
      data: { status: "sold_out", stock: 0 },
    });
    const res = await request(app)
      .get(`/api/v1/market/p/${codeA.toLowerCase()}`)
      .set(plainHost());
    expect(res.status).toBe(200);
    expect(res.body.data.state).toBe("sold");
    expect(res.body.data.store.slug).toBe(SLUG);
  });

  it("404s an unknown share code and hides draft items", async () => {
    const app = createApp();
    const unknown = await request(app)
      .get("/api/v1/market/p/zzzzzzzzzz")
      .set(plainHost());
    expect(unknown.status).toBe(404);
    expect(unknown.body.error.code).toBe("LISTING_NOT_FOUND");

    await prisma.listing.update({
      where: { id: listingA },
      data: { status: "draft", stock: 3 },
    });
    const draft = await request(app)
      .get(`/api/v1/market/p/${codeA.toLowerCase()}`)
      .set(plainHost());
    expect(draft.status).toBe(200);
    expect(draft.body.data.state).toBe("gone");
  });

  it("browses any store by slug from a platform host", async () => {
    const app = createApp();
    const current = await request(app)
      .get(`/api/v1/market/current-store?storeSlug=${SLUG}`)
      .set(plainHost());
    expect(current.status).toBe(200);
    expect(current.body.data.mode).toBe("tenant");
    expect(current.body.data.store.slug).toBe(SLUG);

    const products = await request(app)
      .get(`/api/v1/market/products?storeSlug=${SLUG}`)
      .set(plainHost());
    expect(products.status).toBe(200);
    expect(Array.isArray(products.body.data.items)).toBe(true);
  });

  it("renders and uploads the 9:16 status poster for a listing with hero", async () => {
    const app = createApp();

    // Put a real (tiny) photo into the bucket, attach it as the hero media.
    const png = await sharp({
      create: { width: 96, height: 128, channels: 3, background: "#8a7d5c" },
    })
      .png()
      .toBuffer();
    posterKey = `p5/${suffix}/hero.png`;
    await s3().send(
      new PutObjectCommand({
        Bucket: process.env.S3_BUCKET ?? "storesnap-media",
        Key: posterKey,
        Body: png,
        ContentType: "image/png",
      }),
    );
    const upload = await prisma.upload.create({
      data: {
        id: "up" + suffix,
        storeId: listingA ? (await prisma.listing.findUniqueOrThrow({ where: { id: listingA } })).storeId : "",
        ownerUserId: "",
        key: posterKey,
        mime: "image/png",
        sizeBytes: png.length,
        width: 96,
        height: 128,
      },
    });
    const media = await prisma.listingMedia.create({
      data: {
        listingId: listingA,
        uploadId: upload.id,
        isHero: true,
        sortOrder: 0,
        thumbKey: posterKey,
        cardKey: posterKey,
        fullKey: posterKey,
        width: 96,
        height: 128,
      },
    });

    const poster = await request(app)
      .post("/api/v1/seller/share/poster")
      .set(auth())
      .send({ listingId: listingA });
    expect(poster.status).toBe(200);
    expect(poster.body.data.posterUrl).toContain("/poster/");
    expect(poster.body.data.posterUrl).toContain(".webp");

    // Fetch the poster: anonymous read must work (WhatsApp fetches like this).
    const url = new URL(poster.body.data.posterUrl as string);
    const got = await fetch(url);
    expect(got.status).toBe(200);
    expect(got.headers.get("content-type")).toContain("image/webp");
    const bytes = Buffer.from(await got.arrayBuffer());
    const meta = await sharp(bytes).metadata();
    expect(meta.width).toBe(1080);
    expect(meta.height).toBe(1920);

    // no-photo listing: honest 422, not a crash.
    await prisma.listingMedia.delete({ where: { id: media.id } });
    const none = await request(app)
      .post("/api/v1/seller/share/poster")
      .set(auth())
      .send({ listingId: listingA });
    expect(none.status).toBe(422);
  });
});

