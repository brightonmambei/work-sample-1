import { prisma } from "../../../../../infrastructure/database/prisma";

export const GUEST_ID_HEADER = "x-guest-id";

export function isGuestId(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

export async function ensureGuestIdentity(guestId: string) {
  return prisma.guestIdentity.upsert({
    where: { id: guestId },
    create: { id: guestId },
    update: {},
  });
}

export async function linkGuestIdentity(guestId: string | undefined, customerId: string) {
  if (!guestId || !isGuestId(guestId)) return;
  await prisma.guestIdentity.upsert({
    where: { id: guestId },
    create: { id: guestId, customerId },
    update: { customerId },
  });
}
