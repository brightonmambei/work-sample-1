import { Creditor, Debtor, Transaction } from "@/database/db";
import { buildMoneyLedger, buildTrialBalance, summarizeAccounting } from "../accounting";

const tx = (
  overrides?: Partial<Transaction>,
): Transaction => ({
  id: 1,
  business_day_id: 1,
  type: "sale",
  title: "Test Sale",
  description: "Test Description",
  amount: 1000,
  paymentMethod: "cash",
  date: "2024-03-20T10:00:00.000Z",
  createdBy: "Admin",
  createdAt: "2024-03-20T10:00:00.000Z",
  ...overrides,
});

describe("accounting trial balance", () => {
  it("consolidates debtors and creditors into control accounts", () => {
    const debtors: Debtor[] = [
      {
        id: 1,
        name: "Alice",
        totalOwed: 1000,
        totalPaid: 400,
        lastUpdated: "2026-01-01T08:00:00.000Z",
      },
    ];
    const creditors: Creditor[] = [
      {
        id: 1,
        name: "Fresh Foods",
        totalOwed: 750,
        totalPaid: 250,
        lastUpdated: "2026-01-01T08:00:00.000Z",
      },
    ];

    const rows = buildTrialBalance(
      [
        tx({ id: 1, type: "sale", amount: 1000, paymentMethod: "credit", referenceName: "Alice" }),
        tx({ id: 2, type: "debtor_payment", amount: 400, paymentMethod: "cash", referenceName: "Alice" }),
        tx({ id: 3, type: "purchase", amount: 750, paymentMethod: "credit", referenceName: "Fresh Foods" }),
        tx({ id: 4, type: "creditor_payment", amount: 250, paymentMethod: "cash", referenceName: "Fresh Foods" }),
      ],
      debtors,
      creditors,
    );

    expect(rows).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          account: "Accounts Receivable (Debtors)",
          type: "Asset",
          debitBalance: 600,
          creditBalance: 0,
        }),
        expect.objectContaining({
          account: "Accounts Payable (Creditors)",
          type: "Liability",
          debitBalance: 0,
          creditBalance: 500,
        }),
      ]),
    );
    expect(rows.some((row) => row.account.startsWith("Debtor:"))).toBe(false);
    expect(rows.some((row) => row.account.startsWith("Creditor:"))).toBe(false);
  });

  it("shows customer credits and supplier credits on the correct side", () => {
    const rows = buildTrialBalance(
      [],
      [
        {
          id: 1,
          name: "Alice",
          totalOwed: 0,
          totalPaid: 200,
          lastUpdated: "2026-01-01T08:00:00.000Z",
        },
      ],
      [
        {
          id: 1,
          name: "Fresh Foods",
          totalOwed: 0,
          totalPaid: 300,
          lastUpdated: "2026-01-01T08:00:00.000Z",
        },
      ],
    );

    expect(rows).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          account: "Accounts Receivable (Debtors)",
          type: "Liability",
          debitBalance: 0,
          creditBalance: 200,
        }),
        expect.objectContaining({
          account: "Accounts Payable (Creditors)",
          type: "Asset",
          debitBalance: 300,
          creditBalance: 0,
        }),
      ]),
    );
  });
});

describe("money-in-hand ledger", () => {
  it("includes M-Pesa movements in ledger and closing balance", () => {
    const transactions = [
      tx({ id: 1, type: "opening_balance", amount: 500, paymentMethod: "cash" }),
      tx({ id: 2, type: "sale", amount: 1200, paymentMethod: "mpesa" }),
      tx({ id: 3, type: "expense", amount: 200, paymentMethod: "cash" }),
    ];

    const ledger = buildMoneyLedger(transactions);
    const summary = summarizeAccounting(transactions, [], []);

    expect(ledger).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          transactionId: 2,
          account: "Mobile Money",
          debit: 1200,
          credit: 0,
        }),
      ]),
    );
    expect(summary.cashBalance).toBe(300);
    expect(summary.mpesaBalance).toBe(1200);
    expect(summary.closingBalance).toBe(1500);
  });
});
